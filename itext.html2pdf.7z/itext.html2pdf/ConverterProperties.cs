﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.ConverterProperties
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Actions.Contexts;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl;
using iText.Html2pdf.Css.Apply;
using iText.Kernel.Pdf;
using iText.Layout.Font;
using iText.StyledXmlParser.Css.Media;
using iText.StyledXmlParser.Resolver.Resource;

#nullable disable
namespace iText.Html2pdf
{
  public class ConverterProperties
  {
    private const int DEFAULT_LIMIT_OF_LAYOUTS = 10;
    private MediaDeviceDescription mediaDeviceDescription;
    private FontProvider fontProvider;
    private ITagWorkerFactory tagWorkerFactory;
    private ICssApplierFactory cssApplierFactory;
    private OutlineHandler outlineHandler;
    private string baseUri;
    private IResourceRetriever resourceRetriever;
    private bool createAcroForm;
    private string charset;
    private bool immediateFlush = true;
    private int limitOfLayouts = 10;
    private IMetaInfo metaInfo;
    private bool continuousContainerEnabled;
    private PdfOutputIntent outputIntent;
    private PdfAConformanceLevel conformanceLevel;

    public ConverterProperties()
    {
    }

    public ConverterProperties(ConverterProperties other)
    {
      this.mediaDeviceDescription = other.mediaDeviceDescription;
      this.fontProvider = other.fontProvider;
      this.tagWorkerFactory = other.tagWorkerFactory;
      this.cssApplierFactory = other.cssApplierFactory;
      this.baseUri = other.baseUri;
      this.resourceRetriever = other.resourceRetriever;
      this.createAcroForm = other.createAcroForm;
      this.outlineHandler = other.outlineHandler;
      this.charset = other.charset;
      this.metaInfo = other.metaInfo;
      this.limitOfLayouts = other.limitOfLayouts;
      this.immediateFlush = other.immediateFlush;
      this.continuousContainerEnabled = other.continuousContainerEnabled;
    }

    public virtual MediaDeviceDescription GetMediaDeviceDescription()
    {
      return this.mediaDeviceDescription;
    }

    public virtual ConverterProperties SetMediaDeviceDescription(
      MediaDeviceDescription mediaDeviceDescription)
    {
      this.mediaDeviceDescription = mediaDeviceDescription;
      return this;
    }

    public virtual FontProvider GetFontProvider() => this.fontProvider;

    public virtual ConverterProperties SetFontProvider(FontProvider fontProvider)
    {
      this.fontProvider = fontProvider;
      return this;
    }

    public virtual int GetLimitOfLayouts() => this.limitOfLayouts;

    public virtual ConverterProperties SetLimitOfLayouts(int limitOfLayouts)
    {
      this.limitOfLayouts = limitOfLayouts;
      return this;
    }

    public virtual ITagWorkerFactory GetTagWorkerFactory() => this.tagWorkerFactory;

    public virtual ConverterProperties SetTagWorkerFactory(ITagWorkerFactory tagWorkerFactory)
    {
      this.tagWorkerFactory = tagWorkerFactory;
      return this;
    }

    public virtual ICssApplierFactory GetCssApplierFactory() => this.cssApplierFactory;

    public virtual ConverterProperties SetCssApplierFactory(ICssApplierFactory cssApplierFactory)
    {
      this.cssApplierFactory = cssApplierFactory;
      return this;
    }

    public virtual string GetBaseUri() => this.baseUri;

    public virtual ConverterProperties SetBaseUri(string baseUri)
    {
      this.baseUri = baseUri;
      return this;
    }

    public virtual IResourceRetriever GetResourceRetriever() => this.resourceRetriever;

    public virtual ConverterProperties SetResourceRetriever(IResourceRetriever resourceRetriever)
    {
      this.resourceRetriever = resourceRetriever;
      return this;
    }

    public virtual bool IsCreateAcroForm() => this.createAcroForm;

    public virtual ConverterProperties SetCreateAcroForm(bool createAcroForm)
    {
      this.createAcroForm = createAcroForm;
      return this;
    }

    public virtual OutlineHandler GetOutlineHandler() => this.outlineHandler;

    public virtual ConverterProperties SetOutlineHandler(OutlineHandler outlineHandler)
    {
      this.outlineHandler = outlineHandler;
      return this;
    }

    public virtual string GetCharset() => this.charset;

    public virtual ConverterProperties SetCharset(string charset)
    {
      this.charset = charset;
      return this;
    }

    public virtual ConverterProperties SetDocumentOutputIntent(PdfOutputIntent outputIntent)
    {
      this.outputIntent = outputIntent;
      return this;
    }

    public virtual ConverterProperties SetPdfAConformanceLevel(PdfAConformanceLevel conformanceLevel)
    {
      this.conformanceLevel = conformanceLevel;
      return this;
    }

    public virtual PdfOutputIntent GetDocumentOutputIntent() => this.outputIntent;

    public virtual PdfAConformanceLevel GetConformanceLevel() => this.conformanceLevel;

    public virtual bool IsImmediateFlush() => this.immediateFlush;

    public virtual ConverterProperties SetImmediateFlush(bool immediateFlush)
    {
      this.immediateFlush = immediateFlush;
      return this;
    }

    internal virtual IMetaInfo GetEventMetaInfo()
    {
      return this.metaInfo != null ? this.metaInfo : HtmlConverter.CreatePdf2HtmlMetaInfo();
    }

    public virtual ConverterProperties SetEventMetaInfo(IMetaInfo metaInfo)
    {
      this.metaInfo = metaInfo;
      return this;
    }

    public virtual bool IsContinuousContainerEnabled() => this.continuousContainerEnabled;

    public virtual ConverterProperties SetContinuousContainerEnabled(bool value)
    {
      this.continuousContainerEnabled = value;
      return this;
    }
  }
}
