﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.ByteBuffer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System;

#nullable disable
namespace iText.Html2pdf
{
  internal class ByteBuffer
  {
    internal byte[] buffer;
    internal int position;
    internal int mark = -1;

    private ByteBuffer(byte[] bytes) => this.buffer = bytes;

    public ByteBuffer Position(int index)
    {
      this.position = index;
      if (this.mark >= this.position)
        this.mark = -1;
      return this;
    }

    public ByteBuffer Mark()
    {
      this.mark = this.position;
      return this;
    }

    public ByteBuffer Rewind()
    {
      this.position = 0;
      this.mark = -1;
      return this;
    }

    public byte[] Array() => this.buffer;

    private byte Get() => this.buffer[this.position++];

    public ByteBuffer Get(byte[] dest)
    {
      if (dest.Length > this.Remaining())
        throw new Exception("BufferUnderflowException");
      for (int index = 0; index < dest.Length; ++index)
        dest[index] = this.Get();
      return this;
    }

    public ByteBuffer Peek(byte[] dest)
    {
      int position = this.position;
      this.Get(dest);
      return this.Position(position);
    }

    public int Remaining() => this.buffer.Length - this.position;

    public static ByteBuffer Wrap(byte[] bytes) => new ByteBuffer(bytes);

    public static ByteBuffer EmptyByteBuffer() => new ByteBuffer(new byte[0]);
  }
}
