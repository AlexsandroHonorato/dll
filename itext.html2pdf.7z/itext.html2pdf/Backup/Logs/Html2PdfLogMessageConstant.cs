﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Logs.Html2PdfLogMessageConstant
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System;

#nullable disable
namespace iText.Html2pdf.Logs
{
  public sealed class Html2PdfLogMessageConstant
  {
    public const string CANNOT_RESOLVE_TARGET_COUNTER_VALUE = "Cannot resolve target-counter value with given target \"{0}\"";
    public const string CUSTOM_RENDERER_IS_SET_FOR_HTML_DOCUMENT = "A custom renderer which doesn't extend HtmlDocumentRenderer is set for HtmlDocument. Counters and target-counters may be displayed incorrectly.";
    public const string ANCHOR_LINK_NOT_HANDLED = "The anchor link was not handled. Could not create a destination for element \"{0}\" with ID \"{1}\", which is processed by \"{2}\" tag worker class.";
    public const string CONTENT_PROPERTY_INVALID = "Content property \"{0}\" is either invalid or uses unsupported function.";
    public const string CSS_PROPERTY_IN_PERCENTS_NOT_SUPPORTED = "Css property {0} in percents is not supported";
    public const string DEFAULT_VALUE_OF_CSS_PROPERTY_UNKNOWN = "Default value of the css property \"{0}\" is unknown.";
    public const string ERROR_LOADING_FONT = "Error while loading font";
    public const string ERROR_PARSING_CSS_SELECTOR = "Error while parsing css selector: {0}";
    public const string ERROR_RESOLVING_PARENT_STYLES = "Element parent styles are not resolved. Styles for current element might be incorrect.";
    public const string EXCEEDED_THE_MAXIMUM_NUMBER_OF_RELAYOUTS = "Exceeded the maximum number of relayouts. The resultant document may look not as expected. Because of the content being dynamic iText performs several relayouts to produce correct document.";
    public const string FLEX_PROPERTY_IS_NOT_SUPPORTED_YET = "Flex related property {0}: {1} is not supported yet.";
    public const string INPUT_TYPE_IS_INVALID = "Input type {0} is invalid. The default text type will be used instead.";
    public const string INPUT_TYPE_IS_NOT_SUPPORTED = "Input type {0} is not supported";
    public const string INVALID_CSS_PROPERTY_DECLARATION = "Invalid css property declaration: {0}";
    public const string INVALID_GRADIENT_DECLARATION = "Invalid gradient declaration: {0}";
    public const string MARGIN_VALUE_IN_PERCENT_NOT_SUPPORTED = "Margin value in percents not supported";
    public const string NOT_SUPPORTED_LIST_STYLE_TYPE = "Not supported list style type: {0}";
    public const string NOT_SUPPORTED_TH_SCOPE_TYPE = "Not supported th scope type: {0}. Document may not be compliant with PDF/UA standards.";
    public const string NO_CONSUMER_FOUND_FOR_CONTENT = "No consumer found for content";
    public const string NO_CSS_APPLIER_FOUND_FOR_TAG = "No css applier found for tag {0}";
    public const string NO_IPROPERTYCONTAINER_RESULT_FOR_THE_TAG = "Tag worker does not produce IPropertyContainer for \"{0}\" tag. An outline for \"{0}\" tag will not be created.";
    public const string NO_WORKER_FOUND_FOR_TAG = "No worker found for tag {0}";
    public const string PADDING_VALUE_IN_PERCENT_NOT_SUPPORTED = "Padding value in percents not supported";
    public const string PAGE_MARGIN_BOX_CONTENT_CANNOT_BE_DRAWN = "Page margin box {0} content cannot be drawn.";
    public const string PAGE_MARGIN_BOX_SOME_PROPERTIES_NOT_PROCESSED = "Page margin box margin, padding, height and width properties are not processed. Passed styles container shall be of PageMarginBoxContextNode type.";
    public const string PAGE_SIZE_VALUE_IS_INVALID = "Page size value {0} is invalid.";
    [Obsolete]
    public const string PDF_DOCUMENT_NOT_PRESENT = "PdfDocument is not present";
    public const string QUOTES_PROPERTY_INVALID = "Quote property \"{0}\" is invalid. It should contain even number of <string> values.";
    public const string TEXT_DECORATION_BLINK_NOT_SUPPORTED = "text-decoration: blink not supported";
    public const string HSL_COLOR_NOT_SUPPORTED = "Hsl colors are not supported";
    public const string UNABLE_TO_PROCESS_EXTERNAL_CSS_FILE = "Unable to process external css file";
    public const string UNABLE_TO_PROCESS_SVG_ELEMENT = "Unable to process an SVG element";
    public const string UNABLE_TO_RESOLVE_COUNTER = "Unable to resolve counter \"{0}\"";
    public const string UNABLE_TO_RETRIEVE_FONT = "Unable to retrieve font:\n {0}";
    public const string UNABLE_TO_RETRIEVE_IMAGE_WITH_GIVEN_BASE_URI = "Unable to retrieve image with given base URI ({0}) and image source path ({1})";
    public const string UNABLE_TO_RETRIEVE_STREAM_WITH_GIVEN_BASE_URI = "Unable to retrieve stream with given base URI ({0}) and source path ({1})";
    public const string UNEXPECTED_VALUE_OF_OBJECT_FIT = "Unexpected value of object-fit property: {0}. Will be processed as default";
    public const string UNKNOWN_MARGIN_BOX_CHILD = "Unknown margin box child";
    public const string WORKER_UNABLE_TO_PROCESS_IT_S_TEXT_CONTENT = "Worker of type {0} unable to process it`s text content";
    public const string WORKER_UNABLE_TO_PROCESS_OTHER_WORKER = "Worker of type {0} unable to process {1}";
    public const string ELEMENT_DOES_NOT_FIT_CURRENT_AREA = "Element does not fit current area";
    public const string OPTGROUP_NOT_SUPPORTED_IN_INTERACTIVE_SELECT = "Option groups are not supported in interactive mode";
    public const string IMMEDIATE_FLUSH_DISABLED = "Setting createAcroForm disables immediateFlush property";

    private Html2PdfLogMessageConstant()
    {
    }
  }
}
