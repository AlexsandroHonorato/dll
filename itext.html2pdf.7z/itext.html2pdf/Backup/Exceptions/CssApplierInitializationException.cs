﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Exceptions.CssApplierInitializationException
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Exceptions;
using iText.Commons.Utils;

#nullable disable
namespace iText.Html2pdf.Exceptions
{
  public class CssApplierInitializationException : ITextException
  {
    public const string REFLECTION_FAILED = "Could not instantiate CssApplier-class {0} for tag {1}.";

    public CssApplierInitializationException(string message, string className, string tag)
      : base(MessageFormatUtil.Format(message, new object[2]
      {
        (object) className,
        (object) tag
      }))
    {
    }
  }
}
