﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Exceptions.Html2PdfException
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Exceptions;

#nullable disable
namespace iText.Html2pdf.Exceptions
{
  public class Html2PdfException : ITextException
  {
    public const string PDF_DOCUMENT_SHOULD_BE_IN_WRITING_MODE = "PdfDocument should be created in writing mode. Reading and stamping is not allowed";
    public const string FONT_PROVIDER_CONTAINS_ZERO_FONTS = "Font Provider contains zero fonts. At least one font shall be present";
    public const string UNSUPPORTED_ENCODING_EXCEPTION = "Unsupported encoding exception.";

    public Html2PdfException(string message)
      : base(message)
    {
    }
  }
}
