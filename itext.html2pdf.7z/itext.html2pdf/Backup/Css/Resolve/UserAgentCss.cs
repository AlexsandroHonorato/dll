﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.UserAgentCss
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.IO.Util;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Media;
using iText.StyledXmlParser.Css.Parse;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  internal class UserAgentCss
  {
    private const string DEFAULT_CSS_PATH = "iText.Html2Pdf.default.css";
    private static readonly CssStyleSheet defaultCss;

    static UserAgentCss()
    {
      CssStyleSheet cssStyleSheet = new CssStyleSheet();
      try
      {
        cssStyleSheet = CssStyleSheetParser.Parse(ResourceUtil.GetResourceStream("iText.Html2Pdf.default.css"));
      }
      catch (Exception ex)
      {
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (UserAgentCss)), ex, "Error parsing default.css", Array.Empty<object>());
      }
      finally
      {
        UserAgentCss.defaultCss = cssStyleSheet;
      }
    }

    public static IList<CssDeclaration> GetStyles(INode node)
    {
      return UserAgentCss.defaultCss.GetCssDeclarations(node, MediaDeviceDescription.CreateDefault());
    }
  }
}
