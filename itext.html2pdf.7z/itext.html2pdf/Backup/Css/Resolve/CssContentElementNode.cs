﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.CssContentElementNode
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Pseudo;
using iText.StyledXmlParser.Node;
using System;
using System.Collections;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  public class CssContentElementNode : 
    CssContextNode,
    IElementNode,
    INode,
    IStylesContainer,
    ICustomElementNode
  {
    private CssContentElementNode.Attributes attributes;
    private string tagName;

    public CssContentElementNode(
      INode parentNode,
      string pseudoElementName,
      IDictionary<string, string> attributes)
      : base(parentNode)
    {
      this.tagName = CssPseudoElementUtil.CreatePseudoElementTagName(pseudoElementName);
      this.attributes = new CssContentElementNode.Attributes(attributes);
    }

    public virtual string Name() => this.tagName;

    public virtual IAttributes GetAttributes() => (IAttributes) this.attributes;

    public virtual string GetAttribute(string key) => this.attributes.GetAttribute(key);

    public virtual IList<IDictionary<string, string>> GetAdditionalHtmlStyles()
    {
      return (IList<IDictionary<string, string>>) null;
    }

    public virtual void AddAdditionalHtmlStyles(IDictionary<string, string> styles)
    {
      throw new NotSupportedException("addAdditionalHtmlStyles");
    }

    public virtual string GetLang() => (string) null;

    private class Attributes : IAttributes, IEnumerable<IAttribute>, IEnumerable
    {
      private IDictionary<string, string> attributes;

      public Attributes(IDictionary<string, string> attributes) => this.attributes = attributes;

      public virtual string GetAttribute(string key) => this.attributes.Get<string, string>(key);

      public virtual void SetAttribute(string key, string value)
      {
        throw new NotSupportedException("setAttribute");
      }

      public virtual int Size() => this.attributes.Count;

      public IEnumerator<IAttribute> GetEnumerator()
      {
        return (IEnumerator<IAttribute>) new CssContentElementNode.AttributeIterator(this.attributes.GetEnumerator());
      }

      IEnumerator IEnumerable.GetEnumerator() => (IEnumerator) this.GetEnumerator();
    }

    private class Attribute : IAttribute
    {
      private KeyValuePair<string, string> entry;

      public Attribute(KeyValuePair<string, string> entry) => this.entry = entry;

      public virtual string GetKey() => this.entry.Key;

      public virtual string GetValue() => this.entry.Value;
    }

    private class AttributeIterator : IEnumerator<IAttribute>, IEnumerator, IDisposable
    {
      private IEnumerator<KeyValuePair<string, string>> iterator;

      public AttributeIterator(IEnumerator<KeyValuePair<string, string>> iterator)
      {
        this.iterator = iterator;
      }

      public void Dispose() => this.iterator.Dispose();

      public bool MoveNext() => this.iterator.MoveNext();

      public void Reset() => this.iterator.Reset();

      public IAttribute Current
      {
        get => (IAttribute) new CssContentElementNode.Attribute(this.iterator.Current);
      }

      object IEnumerator.Current => (object) this.Current;
    }
  }
}
