﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.Func.Counter.CounterDigitsGlyphStyle
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

#nullable disable
namespace iText.Html2pdf.Css.Resolve.Func.Counter
{
  public enum CounterDigitsGlyphStyle
  {
    DEFAULT,
    NONE,
    DISC,
    SQUARE,
    CIRCLE,
    UPPER_ALPHA_AND_LATIN,
    LOWER_ALPHA_AND_LATIN,
    LOWER_GREEK,
    LOWER_ROMAN,
    UPPER_ROMAN,
    GEORGIAN,
    ARMENIAN,
    DECIMAL_LEADING_ZERO,
  }
}
