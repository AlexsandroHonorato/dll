﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.Func.Counter.PageCountElementNode
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser.Jsoup.Nodes;
using iText.StyledXmlParser.Jsoup.Parser;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Node.Impl.Jsoup.Node;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Resolve.Func.Counter
{
  public class PageCountElementNode : 
    JsoupElementNode,
    ICustomElementNode,
    IElementNode,
    INode,
    IStylesContainer
  {
    public const string PAGE_COUNTER_TAG = "_e0d00a6_page-counter";
    private readonly INode parent;
    private CounterDigitsGlyphStyle digitsGlyphStyle;
    private bool totalPageCount;

    public PageCountElementNode(bool totalPageCount, INode parent)
      : base(new Element(Tag.ValueOf("_e0d00a6_page-counter"), ""))
    {
      this.totalPageCount = totalPageCount;
      this.parent = parent;
    }

    public virtual IList<INode> ChildNodes() => JavaCollectionsUtil.EmptyList<INode>();

    public virtual void AddChild(INode node) => throw new NotSupportedException();

    public virtual INode ParentNode() => this.parent;

    public virtual bool IsTotalPageCount() => this.totalPageCount;

    public virtual CounterDigitsGlyphStyle GetDigitsGlyphStyle() => this.digitsGlyphStyle;

    public virtual PageCountElementNode SetDigitsGlyphStyle(CounterDigitsGlyphStyle digitsGlyphStyle)
    {
      this.digitsGlyphStyle = digitsGlyphStyle;
      return this;
    }
  }
}
