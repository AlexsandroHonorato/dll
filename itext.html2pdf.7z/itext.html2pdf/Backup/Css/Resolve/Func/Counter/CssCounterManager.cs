﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.Func.Counter.CssCounterManager
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Html;
using iText.StyledXmlParser.Node;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Text;

#nullable disable
namespace iText.Html2pdf.Css.Resolve.Func.Counter
{
  public class CssCounterManager
  {
    private const int DEFAULT_COUNTER_VALUE = 0;
    private const int DEFAULT_INCREMENT_VALUE = 1;
    private readonly IDictionary<string, IDictionary<string, int?>> targetCounterMap = (IDictionary<string, IDictionary<string, int?>>) new Dictionary<string, IDictionary<string, int?>>();
    private readonly IDictionary<string, IDictionary<string, string>> targetCountersMap = (IDictionary<string, IDictionary<string, string>>) new Dictionary<string, IDictionary<string, string>>();
    private readonly IDictionary<string, LinkedList<int>> counters = (IDictionary<string, LinkedList<int>>) new Dictionary<string, LinkedList<int>>();
    private readonly IDictionary<string, int?> counterValues = (IDictionary<string, int?>) new Dictionary<string, int?>();
    private readonly IDictionary<IElementNode, IList<string>> pushedCountersMap = (IDictionary<IElementNode, IList<string>>) new Dictionary<IElementNode, IList<string>>();

    public virtual void ClearManager() => this.counters.Clear();

    public virtual void PushEveryCounterToCounters(IElementNode element)
    {
      IList<string> stringList = (IList<string>) new List<string>();
      foreach (KeyValuePair<string, int?> keyValuePair in new HashSet<KeyValuePair<string, int?>>((IEnumerable<KeyValuePair<string, int?>>) this.counterValues))
      {
        int? nullable1 = keyValuePair.Value;
        if (nullable1.HasValue)
        {
          this.PushCounter(keyValuePair.Key, keyValuePair.Value);
          stringList.Add(keyValuePair.Key);
          IDictionary<string, int?> counterValues = this.counterValues;
          string key = keyValuePair.Key;
          nullable1 = new int?();
          int? nullable2 = nullable1;
          counterValues.Put<string, int?>(key, nullable2);
        }
      }
      this.pushedCountersMap.Put<IElementNode, IList<string>>(element, stringList);
    }

    public virtual void PopEveryCounterFromCounters(IElementNode element)
    {
      this.counterValues.Clear();
      if (this.pushedCountersMap.Get<IElementNode, IList<string>>(element) == null)
        return;
      foreach (string str in (IEnumerable<string>) this.pushedCountersMap.Get<IElementNode, IList<string>>(element))
        this.counterValues.Put<string, int?>(str, this.PopCounter(str));
      this.pushedCountersMap.JRemove<IElementNode, IList<string>>(element);
    }

    public virtual string ResolveTargetCounter(
      string id,
      string counterName,
      CounterDigitsGlyphStyle listSymbolType)
    {
      int? nullable = new int?();
      if (this.targetCounterMap.ContainsKey(id))
      {
        IDictionary<string, int?> col = this.targetCounterMap.Get<string, IDictionary<string, int?>>(id);
        if (col.ContainsKey(counterName))
          nullable = col.Get<string, int?>(counterName);
        else
          col.Put<string, int?>(counterName, new int?());
      }
      else
      {
        this.targetCounterMap.Put<string, IDictionary<string, int?>>(id, (IDictionary<string, int?>) new Dictionary<string, int?>());
        this.targetCounterMap.Get<string, IDictionary<string, int?>>(id).Put<string, int?>(counterName, new int?());
      }
      return nullable.HasValue ? HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, nullable.Value) : (string) null;
    }

    public virtual string ResolveTargetCounters(
      string id,
      string counterName,
      string counterSeparatorStr,
      CounterDigitsGlyphStyle listSymbolType)
    {
      string str1 = (string) null;
      if (this.targetCountersMap.ContainsKey(id))
      {
        IDictionary<string, string> col = this.targetCountersMap.Get<string, IDictionary<string, string>>(id);
        if (col.ContainsKey(counterName))
          str1 = col.Get<string, string>(counterName);
        else
          col.Put<string, string>(counterName, (string) null);
      }
      else
      {
        this.targetCountersMap.Put<string, IDictionary<string, string>>(id, (IDictionary<string, string>) new Dictionary<string, string>());
        this.targetCountersMap.Get<string, IDictionary<string, string>>(id).Put<string, string>(counterName, (string) null);
      }
      if (str1 == null)
        return (string) null;
      string[] strArray = StringUtil.Split(str1, "\\.");
      IList<string> resolvedCounters = (IList<string>) new List<string>();
      foreach (string str2 in strArray)
        resolvedCounters.Add(HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, Convert.ToInt32(str2, (IFormatProvider) CultureInfo.InvariantCulture)));
      return CssCounterManager.BuildCountersStringFromList(resolvedCounters, counterSeparatorStr);
    }

    public virtual void AddTargetCounterIfRequired(IElementNode node)
    {
      string attribute = node.GetAttribute("id");
      if (attribute == null || !this.targetCounterMap.ContainsKey(attribute))
        return;
      foreach (KeyValuePair<string, int?> keyValuePair in new HashSet<KeyValuePair<string, int?>>((IEnumerable<KeyValuePair<string, int?>>) this.targetCounterMap.Get<string, IDictionary<string, int?>>(attribute)))
      {
        string key = keyValuePair.Key;
        string str = this.ResolveCounter(key, CounterDigitsGlyphStyle.DEFAULT);
        if (str != null)
          this.targetCounterMap.Get<string, IDictionary<string, int?>>(attribute).Put<string, int?>(key, new int?(Convert.ToInt32(str, (IFormatProvider) CultureInfo.InvariantCulture)));
      }
    }

    public virtual void AddTargetCountersIfRequired(IElementNode node)
    {
      string attribute = node.GetAttribute("id");
      if (attribute == null || !this.targetCountersMap.ContainsKey(attribute))
        return;
      foreach (KeyValuePair<string, string> keyValuePair in new HashSet<KeyValuePair<string, string>>((IEnumerable<KeyValuePair<string, string>>) this.targetCountersMap.Get<string, IDictionary<string, string>>(attribute)))
      {
        string key = keyValuePair.Key;
        string str = this.ResolveCounters(key, ".", CounterDigitsGlyphStyle.DEFAULT);
        if (str != null)
          this.targetCountersMap.Get<string, IDictionary<string, string>>(attribute).Put<string, string>(key, str);
      }
    }

    public virtual string ResolveCounter(string counterName, CounterDigitsGlyphStyle listSymbolType)
    {
      int? nullable = this.counterValues.Get<string, int?>(counterName);
      if (!nullable.HasValue)
        nullable = !this.counters.ContainsKey(counterName) || this.counters.Get<string, LinkedList<int>>(counterName).IsEmpty<int>() ? new int?(0) : new int?(this.counters.Get<string, LinkedList<int>>(counterName).JGetLast<int>());
      return HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, nullable.Value);
    }

    public virtual string ResolveCounters(
      string counterName,
      string counterSeparatorStr,
      CounterDigitsGlyphStyle listSymbolType)
    {
      IList<string> stringList = (IList<string>) new List<string>();
      if (this.counters.ContainsKey(counterName))
      {
        foreach (int num in this.counters.Get<string, LinkedList<int>>(counterName))
        {
          int? nullable = new int?(num);
          stringList.Add(HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, nullable.Value));
        }
      }
      int? nullable1 = this.counterValues.Get<string, int?>(counterName);
      if (nullable1.HasValue)
        stringList.Add(HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, nullable1.Value));
      return stringList.IsEmpty<string>() ? HtmlUtils.ConvertNumberAccordingToGlyphStyle(listSymbolType, 0) : CssCounterManager.BuildCountersStringFromList(stringList, counterSeparatorStr);
    }

    public virtual void ResetCounter(string counterName) => this.ResetCounter(counterName, 0);

    public virtual void ResetCounter(string counterName, int value)
    {
      this.counterValues.Put<string, int?>(counterName, new int?(value));
    }

    public virtual void IncrementCounter(string counterName)
    {
      this.IncrementCounter(counterName, 1);
    }

    public virtual void IncrementCounter(string counterName, int incrementValue)
    {
      int? nullable1 = this.counterValues.Get<string, int?>(counterName);
      if (!nullable1.HasValue)
      {
        LinkedList<int> linkedList1 = this.counters.Get<string, LinkedList<int>>(counterName);
        if (linkedList1 == null || linkedList1.IsEmpty<int>())
        {
          nullable1 = new int?(0);
          this.ResetCounter(counterName, nullable1.Value);
          IDictionary<string, int?> counterValues = this.counterValues;
          string key = counterName;
          int? nullable2 = nullable1;
          int num = incrementValue;
          int? nullable3 = nullable2.HasValue ? new int?(nullable2.GetValueOrDefault() + num) : new int?();
          counterValues.Put<string, int?>(key, nullable3);
        }
        else
        {
          nullable1 = new int?(linkedList1.JGetLast<int>());
          linkedList1.RemoveLast();
          LinkedList<int> linkedList2 = linkedList1;
          int? nullable4 = nullable1;
          int num1 = incrementValue;
          int num2 = (nullable4.HasValue ? new int?(nullable4.GetValueOrDefault() + num1) : new int?()).Value;
          linkedList2.AddLast(num2);
        }
      }
      else
      {
        IDictionary<string, int?> counterValues = this.counterValues;
        string key = counterName;
        int? nullable5 = nullable1;
        int num = incrementValue;
        int? nullable6 = nullable5.HasValue ? new int?(nullable5.GetValueOrDefault() + num) : new int?();
        counterValues.Put<string, int?>(key, nullable6);
      }
    }

    private int? PopCounter(string counterName)
    {
      if (!this.counters.ContainsKey(counterName) || this.counters.Get<string, LinkedList<int>>(counterName).IsEmpty<int>())
        return new int?();
      int? nullable = new int?(this.counters.Get<string, LinkedList<int>>(counterName).JGetLast<int>());
      this.counters.Get<string, LinkedList<int>>(counterName).RemoveLast();
      return nullable;
    }

    private void PushCounter(string counterName, int? value)
    {
      if (!this.counters.ContainsKey(counterName))
        this.counters.Put<string, LinkedList<int>>(counterName, new LinkedList<int>());
      this.counters.Get<string, LinkedList<int>>(counterName).AddLast(value.Value);
    }

    private static string BuildCountersStringFromList(
      IList<string> resolvedCounters,
      string counterSeparatorStr)
    {
      StringBuilder stringBuilder = new StringBuilder();
      for (int index = 0; index < resolvedCounters.Count; ++index)
      {
        stringBuilder.Append(resolvedCounters[index]);
        if (index != resolvedCounters.Count - 1)
          stringBuilder.Append(counterSeparatorStr);
      }
      return stringBuilder.ToString();
    }
  }
}
