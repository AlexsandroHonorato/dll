﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.Func.Counter.PageTargetCountElementNode
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Css.Resolve.Func.Counter
{
  public class PageTargetCountElementNode : PageCountElementNode
  {
    private readonly string target;

    public PageTargetCountElementNode(INode parent, string target)
      : base(false, parent)
    {
      this.target = target;
    }

    public virtual string GetTarget() => this.target;
  }
}
