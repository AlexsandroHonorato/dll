﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.CssContentPropertyResolver
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Css.Page;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Html2pdf.Html;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Parse;
using iText.StyledXmlParser.Css.Pseudo;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  internal class CssContentPropertyResolver
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (CssContentPropertyResolver));
    private static readonly EscapeGroup[] ALLOWED_ESCAPE_CHARACTERS = new EscapeGroup[2]
    {
      new EscapeGroup('\''),
      new EscapeGroup('"')
    };
    private const int COUNTERS_MIN_PARAMS_SIZE = 2;
    private const int COUNTER_MIN_PARAMS_SIZE = 1;
    private const int TARGET_COUNTERS_MIN_PARAMS_SIZE = 3;
    private const int TARGET_COUNTER_MIN_PARAMS_SIZE = 2;

    internal static IList<INode> ResolveContent(
      IDictionary<string, string> styles,
      INode contentContainer,
      CssContext context)
    {
      string contentStr = styles.Get<string, string>("content");
      IList<INode> inodeList = (IList<INode>) new List<INode>();
      if (contentStr == null || "none".Equals(contentStr) || "normal".Equals(contentStr))
        return (IList<INode>) null;
      CssDeclarationValueTokenizer declarationValueTokenizer = new CssDeclarationValueTokenizer(contentStr);
      CssQuotes cssQuotes = (CssQuotes) null;
      CssDeclarationValueTokenizer.Token nextValidToken;
      while ((nextValidToken = declarationValueTokenizer.GetNextValidToken()) != null)
      {
        if (nextValidToken.IsString())
          inodeList.Add((INode) new CssContentPropertyResolver.ContentTextNode(contentContainer, nextValidToken.GetValue()));
        else if (nextValidToken.GetValue().StartsWith("counters("))
        {
          IList<string> stringList = CssUtils.SplitString(nextValidToken.GetValue().JSubstring("counters".Length + 1, nextValidToken.GetValue().Length - 1), ',', CssContentPropertyResolver.ALLOWED_ESCAPE_CHARACTERS);
          if (stringList.Count < 2)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string counterName = stringList[0].Trim();
          string str = stringList[1].Trim();
          string counterSeparatorStr = str.JSubstring(1, str.Length - 1);
          CounterDigitsGlyphStyle digitsGlyphStyle = HtmlUtils.ConvertStringCounterGlyphStyleToEnum(stringList.Count > 2 ? stringList[2].Trim() : (string) null);
          CssCounterManager counterManager = context.GetCounterManager();
          INode parent = contentContainer;
          if ("page".Equals(counterName))
            inodeList.Add((INode) new PageCountElementNode(false, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          else if ("pages".Equals(counterName))
          {
            inodeList.Add((INode) new PageCountElementNode(true, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          }
          else
          {
            string content = counterManager.ResolveCounters(counterName, counterSeparatorStr, digitsGlyphStyle);
            inodeList.Add((INode) new CssContentPropertyResolver.ContentTextNode(parent, content));
          }
        }
        else if (nextValidToken.GetValue().StartsWith("counter("))
        {
          IList<string> stringList = CssUtils.SplitString(nextValidToken.GetValue().JSubstring("counter".Length + 1, nextValidToken.GetValue().Length - 1), ',', CssContentPropertyResolver.ALLOWED_ESCAPE_CHARACTERS);
          if (stringList.Count < 1)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string counterName = stringList[0].Trim();
          CounterDigitsGlyphStyle digitsGlyphStyle = HtmlUtils.ConvertStringCounterGlyphStyleToEnum(stringList.Count > 1 ? stringList[1].Trim() : (string) null);
          CssCounterManager counterManager = context.GetCounterManager();
          INode parent = contentContainer;
          if ("page".Equals(counterName))
            inodeList.Add((INode) new PageCountElementNode(false, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          else if ("pages".Equals(counterName))
          {
            inodeList.Add((INode) new PageCountElementNode(true, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          }
          else
          {
            string content = counterManager.ResolveCounter(counterName, digitsGlyphStyle);
            inodeList.Add((INode) new CssContentPropertyResolver.ContentTextNode(parent, content));
          }
        }
        else if (nextValidToken.GetValue().StartsWith("target-counter("))
        {
          IList<string> stringList = CssUtils.SplitString(nextValidToken.GetValue().JSubstring("target-counter".Length + 1, nextValidToken.GetValue().Length - 1), ',', CssContentPropertyResolver.ALLOWED_ESCAPE_CHARACTERS);
          if (stringList.Count < 2)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string target = stringList[0].StartsWith("attr(") ? CssUtils.ExtractAttributeValue(stringList[0], (IElementNode) contentContainer.ParentNode()) : CssUtils.ExtractUrl(stringList[0]);
          if (target == null)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string counterName = stringList[1].Trim();
          CounterDigitsGlyphStyle digitsGlyphStyle = HtmlUtils.ConvertStringCounterGlyphStyleToEnum(stringList.Count > 2 ? stringList[2].Trim() : (string) null);
          if ("page".Equals(counterName))
            inodeList.Add((INode) new PageTargetCountElementNode(contentContainer, target).SetDigitsGlyphStyle(digitsGlyphStyle));
          else if ("pages".Equals(counterName))
          {
            inodeList.Add((INode) new PageCountElementNode(true, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          }
          else
          {
            string str = context.GetCounterManager().ResolveTargetCounter(target.Replace("'", "").Replace("#", ""), counterName, digitsGlyphStyle);
            CssContentPropertyResolver.ContentTextNode contentTextNode = new CssContentPropertyResolver.ContentTextNode(contentContainer, str == null ? "0" : str);
            inodeList.Add((INode) contentTextNode);
          }
        }
        else if (nextValidToken.GetValue().StartsWith("target-counters("))
        {
          IList<string> stringList = CssUtils.SplitString(nextValidToken.GetValue().JSubstring("target-counters".Length + 1, nextValidToken.GetValue().Length - 1), ',', CssContentPropertyResolver.ALLOWED_ESCAPE_CHARACTERS);
          if (stringList.Count < 3)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string target = stringList[0].StartsWith("attr(") ? CssUtils.ExtractAttributeValue(stringList[0], (IElementNode) contentContainer.ParentNode()) : CssUtils.ExtractUrl(stringList[0]);
          if (target == null)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string counterName = stringList[1].Trim();
          string str1 = stringList[2].Trim();
          string counterSeparatorStr = str1.JSubstring(1, str1.Length - 1);
          CounterDigitsGlyphStyle digitsGlyphStyle = HtmlUtils.ConvertStringCounterGlyphStyleToEnum(stringList.Count > 3 ? stringList[3].Trim() : (string) null);
          if ("page".Equals(counterName))
            inodeList.Add((INode) new PageTargetCountElementNode(contentContainer, target).SetDigitsGlyphStyle(digitsGlyphStyle));
          else if ("pages".Equals(counterName))
          {
            inodeList.Add((INode) new PageCountElementNode(true, contentContainer).SetDigitsGlyphStyle(digitsGlyphStyle));
          }
          else
          {
            string str2 = context.GetCounterManager().ResolveTargetCounters(target.Replace(",", "").Replace("#", ""), counterName, counterSeparatorStr, digitsGlyphStyle);
            CssContentPropertyResolver.ContentTextNode contentTextNode = new CssContentPropertyResolver.ContentTextNode(contentContainer, str2 == null ? "0" : str2);
            inodeList.Add((INode) contentTextNode);
          }
        }
        else if (nextValidToken.GetValue().StartsWith("url("))
        {
          IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>();
          dictionary.Put<string, string>("src", CssUtils.ExtractUrl(nextValidToken.GetValue()));
          dictionary.Put<string, string>("style", "display:inline-block");
          inodeList.Add((INode) new CssContentElementNode(contentContainer, "img", dictionary));
        }
        else if (CssGradientUtil.IsCssLinearGradientValue(nextValidToken.GetValue()))
        {
          IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>();
          dictionary.Put<string, string>("style", "background-image:" + nextValidToken.GetValue() + ";height:inherit;width:inherit;");
          inodeList.Add((INode) new CssContentElementNode(contentContainer, "div", dictionary));
        }
        else if (nextValidToken.GetValue().StartsWith("attr(") && contentContainer is CssPseudoElementNode)
        {
          string attributeValue = CssUtils.ExtractAttributeValue(nextValidToken.GetValue(), (IElementNode) contentContainer.ParentNode());
          if (attributeValue == null)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          inodeList.Add((INode) new CssContentPropertyResolver.ContentTextNode(contentContainer, attributeValue));
        }
        else if (nextValidToken.GetValue().EndsWith("quote") && contentContainer is IStylesContainer)
        {
          if (cssQuotes == null)
            cssQuotes = CssQuotes.CreateQuotes(styles.Get<string, string>("quotes"), true);
          string content = cssQuotes.ResolveQuote(nextValidToken.GetValue(), (AbstractCssContext) context);
          if (content == null)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          inodeList.Add((INode) new CssContentPropertyResolver.ContentTextNode(contentContainer, content));
        }
        else
        {
          if (!nextValidToken.GetValue().StartsWith("element(") || !(contentContainer is PageMarginBoxContextNode))
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string[] strArray = StringUtil.Split(nextValidToken.GetValue().JSubstring("element".Length + 1, nextValidToken.GetValue().Length - 1), ",");
          if (strArray.Length == 0)
            return CssContentPropertyResolver.ErrorFallback(contentStr);
          string runningElementName = strArray[0].Trim();
          string runningElementOccurrence = (string) null;
          if (strArray.Length > 1)
            runningElementOccurrence = strArray[1].Trim();
          inodeList.Add((INode) new PageMarginRunningElementNode(runningElementName, runningElementOccurrence));
        }
      }
      return inodeList;
    }

    private static IList<INode> ErrorFallback(string contentStr)
    {
      int endIndex = 100;
      if (contentStr.Length > endIndex)
        contentStr = contentStr.JSubstring(0, endIndex) + ".....";
      LoggerExtensions.LogError(CssContentPropertyResolver.LOGGER, MessageFormatUtil.Format("Content property \"{0}\" is either invalid or uses unsupported function.", new object[1]
      {
        (object) contentStr
      }), Array.Empty<object>());
      return (IList<INode>) null;
    }

    private class ContentTextNode : ITextNode, INode
    {
      private readonly INode parent;
      private string content;

      internal ContentTextNode(INode parent, string content)
      {
        this.parent = parent;
        this.content = content;
      }

      public virtual IList<INode> ChildNodes() => JavaCollectionsUtil.EmptyList<INode>();

      public virtual void AddChild(INode node) => throw new NotSupportedException();

      public virtual INode ParentNode() => this.parent;

      public virtual string WholeText() => this.content;
    }
  }
}
