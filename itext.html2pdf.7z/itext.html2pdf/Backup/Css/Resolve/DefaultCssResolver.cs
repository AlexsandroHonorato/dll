﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.DefaultCssResolver
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Html2pdf.Css.Util;
using iText.Html2pdf.Exceptions;
using iText.IO.Util;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Media;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Parse;
using iText.StyledXmlParser.Css.Pseudo;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Selector;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Resolver.Resource;
using iText.StyledXmlParser.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  public class DefaultCssResolver : ICssResolver
  {
    private CssStyleSheet cssStyleSheet;
    private MediaDeviceDescription deviceDescription;
    private IStyleInheritance cssInheritance = (IStyleInheritance) new CssInheritance();
    private IList<CssFontFaceRule> fonts = (IList<CssFontFaceRule>) new List<CssFontFaceRule>();

    public DefaultCssResolver(
      INode treeRoot,
      MediaDeviceDescription mediaDeviceDescription,
      ResourceResolver resourceResolver)
    {
      this.deviceDescription = mediaDeviceDescription;
      this.CollectCssDeclarations(treeRoot, resourceResolver, (CssContext) null);
      this.CollectFonts();
    }

    public DefaultCssResolver(INode treeRoot, ProcessorContext context)
    {
      this.deviceDescription = context.GetDeviceDescription();
      this.CollectCssDeclarations(treeRoot, context.GetResourceResolver(), context.GetCssContext());
      this.CollectFonts();
    }

    public virtual IList<CssFontFaceRule> GetFonts() => this.fonts;

    public virtual void ResolveContentAndCountersStyles(INode node, CssContext context)
    {
      IDictionary<string, string> dictionary = this.ResolveElementsStyles(node);
      CounterProcessorUtil.ProcessCounters(dictionary, context);
      this.ResolveContentProperty(dictionary, node, context);
    }

    public virtual IDictionary<string, string> ResolveStyles(
      INode element,
      AbstractCssContext context)
    {
      return context is CssContext ? this.ResolveStyles(element, (CssContext) context) : throw new Html2PdfException("custom AbstractCssContext implementations are not supported yet");
    }

    private IDictionary<string, string> ResolveStyles(INode element, CssContext context)
    {
      IDictionary<string, string> dictionary = this.ResolveElementsStyles(element);
      if ("currentcolor".Equals(dictionary.Get<string, string>("color")))
        dictionary.Put<string, string>("color", "inherit");
      string str1 = (string) null;
      if (element.ParentNode() is IStylesContainer)
      {
        IDictionary<string, string> styles = ((IStylesContainer) element.ParentNode()).GetStyles();
        if (styles == null && !(element.ParentNode() is IDocumentNode))
          LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (DefaultCssResolver)), "Element parent styles are not resolved. Styles for current element might be incorrect.", Array.Empty<object>());
        if (styles != null)
        {
          ICollection<IStyleInheritance> istyleInheritances = (ICollection<IStyleInheritance>) new HashSet<IStyleInheritance>();
          istyleInheritances.Add(this.cssInheritance);
          foreach (KeyValuePair<string, string> parentEntry in (IEnumerable<KeyValuePair<string, string>>) styles)
          {
            dictionary = StyleUtil.MergeParentStyleDeclaration(dictionary, parentEntry.Key, parentEntry.Value, styles.Get<string, string>("font-size"), istyleInheritances);
            string currentElementDisplay = dictionary.Get<string, string>("display");
            if (DefaultCssResolver.IsFlexItem(parentEntry, currentElementDisplay) && !"none".Equals(currentElementDisplay))
              dictionary.Put<string, string>("display", "block");
          }
          str1 = styles.Get<string, string>("font-size");
        }
      }
      string str2 = dictionary.Get<string, string>("font-size");
      if (CssTypesValidationUtils.IsRelativeValue(str2) || "larger".Equals(str2) || "smaller".Equals(str2))
      {
        float num = !CssTypesValidationUtils.IsRemValue(str2) ? (str1 != null ? CssDimensionParsingUtils.ParseAbsoluteLength(str1) : CssDimensionParsingUtils.ParseAbsoluteFontSize(CssDefaults.GetDefaultValue("font-size"))) : context.GetRootFontSize();
        float relativeFontSize = CssDimensionParsingUtils.ParseRelativeFontSize(str2, num);
        dictionary.Put<string, string>("font-size", DecimalFormatUtil.FormatNumber((double) relativeFontSize, "0.####") + "pt");
      }
      else
        dictionary.Put<string, string>("font-size", Convert.ToString(CssDimensionParsingUtils.ParseAbsoluteFontSize(str2), (IFormatProvider) CultureInfo.InvariantCulture) + "pt");
      if (element is IElementNode && "html".Equals(((IElementNode) element).Name()))
        context.SetRootFontSize(dictionary.Get<string, string>("font-size"));
      ICollection<string> strings = (ICollection<string>) new HashSet<string>();
      foreach (KeyValuePair<string, string> keyValuePair in (IEnumerable<KeyValuePair<string, string>>) dictionary)
      {
        if ("initial".Equals(keyValuePair.Value) || "inherit".Equals(keyValuePair.Value))
          strings.Add(keyValuePair.Key);
      }
      foreach (string key in (IEnumerable<string>) strings)
        dictionary.Put<string, string>(key, CssDefaults.GetDefaultValue(key));
      CounterProcessorUtil.ProcessCounters(dictionary, context);
      this.ResolveContentProperty(dictionary, element, context);
      return dictionary;
    }

    private IDictionary<string, string> ResolveElementsStyles(INode element)
    {
      IList<CssRuleSet> c = (IList<CssRuleSet>) new List<CssRuleSet>();
      c.Add(new CssRuleSet((ICssSelector) null, UserAgentCss.GetStyles(element)));
      if (element is IElementNode)
        c.Add(new CssRuleSet((ICssSelector) null, HtmlStylesToCssConverter.Convert((IElementNode) element)));
      c.AddAll<CssRuleSet>((IEnumerable<CssRuleSet>) this.cssStyleSheet.GetCssRuleSets(element, this.deviceDescription));
      if (element is IElementNode)
      {
        string attribute = ((IElementNode) element).GetAttribute("style");
        if (attribute != null)
          c.Add(new CssRuleSet((ICssSelector) null, CssRuleSetParser.ParsePropertyDeclarations(attribute)));
      }
      return CssStyleSheet.ExtractStylesFromRuleSets(c);
    }

    private void ResolveContentProperty(
      IDictionary<string, string> styles,
      INode contentContainer,
      CssContext context)
    {
      if (contentContainer is CssPseudoElementNode || contentContainer is PageMarginBoxContextNode)
      {
        IList<INode> inodeList = CssContentPropertyResolver.ResolveContent(styles, contentContainer, context);
        if (inodeList != null)
        {
          foreach (INode inode in (IEnumerable<INode>) inodeList)
            contentContainer.AddChild(inode);
        }
      }
      if (!(contentContainer is IElementNode))
        return;
      context.GetCounterManager().AddTargetCounterIfRequired((IElementNode) contentContainer);
      context.GetCounterManager().AddTargetCountersIfRequired((IElementNode) contentContainer);
    }

    private void CollectCssDeclarations(
      INode rootNode,
      ResourceResolver resourceResolver,
      CssContext cssContext)
    {
      this.cssStyleSheet = new CssStyleSheet();
      LinkedList<INode> linkedList = new LinkedList<INode>();
      linkedList.Add<INode>(rootNode);
      while (!linkedList.IsEmpty<INode>())
      {
        INode inode = linkedList.JGetFirst<INode>();
        linkedList.RemoveFirst();
        if (inode is IElementNode)
        {
          IElementNode headChildElement = (IElementNode) inode;
          if ("style".Equals(headChildElement.Name()))
          {
            if (inode.ChildNodes().Count > 0 && inode.ChildNodes()[0] is IDataNode)
            {
              CssStyleSheet styleSheet = CssStyleSheetParser.Parse(((IDataNode) inode.ChildNodes()[0]).GetWholeData());
              this.cssStyleSheet.AppendCssStyleSheet(this.WrapStyleSheetInMediaQueryIfNecessary(headChildElement, styleSheet));
            }
          }
          else if (CssUtils.IsStyleSheetLink(headChildElement))
          {
            string attribute = headChildElement.GetAttribute("href");
            try
            {
              using (Stream stream = resourceResolver.RetrieveResourceAsInputStream(attribute))
              {
                if (stream != null)
                {
                  CssStyleSheet styleSheet = CssStyleSheetParser.Parse(stream, resourceResolver.ResolveAgainstBaseUri(attribute).ToExternalForm());
                  this.cssStyleSheet.AppendCssStyleSheet(this.WrapStyleSheetInMediaQueryIfNecessary(headChildElement, styleSheet));
                }
              }
            }
            catch (Exception ex)
            {
              LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (DefaultCssResolver)), ex, "Unable to process external css file", Array.Empty<object>());
            }
          }
        }
        foreach (INode childNode in (IEnumerable<INode>) inode.ChildNodes())
        {
          if (childNode is IElementNode)
            linkedList.Add<INode>(childNode);
        }
      }
      DefaultCssResolver.EnablePagesCounterIfMentioned(this.cssStyleSheet, cssContext);
      DefaultCssResolver.EnableNonPageTargetCounterIfMentioned(this.cssStyleSheet, cssContext);
    }

    private static bool IsFlexItem(
      KeyValuePair<string, string> parentEntry,
      string currentElementDisplay)
    {
      return "display".Equals(parentEntry.Key) && "flex".Equals(parentEntry.Value) && !"flex".Equals(currentElementDisplay);
    }

    private static void EnableNonPageTargetCounterIfMentioned(
      CssStyleSheet styleSheet,
      CssContext cssContext)
    {
      if (!CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence(styleSheet))
        return;
      cssContext.SetNonPagesTargetCounterPresent(true);
    }

    private static void EnablePagesCounterIfMentioned(
      CssStyleSheet styleSheet,
      CssContext cssContext)
    {
      if (!CssStyleSheetAnalyzer.CheckPagesCounterPresence(styleSheet))
        return;
      cssContext.SetPagesCounterPresent(true);
    }

    private CssStyleSheet WrapStyleSheetInMediaQueryIfNecessary(
      IElementNode headChildElement,
      CssStyleSheet styleSheet)
    {
      string attribute = headChildElement.GetAttribute("media");
      if (attribute != null && attribute.Length > 0)
      {
        CssMediaRule cssMediaRule = new CssMediaRule(attribute);
        ((CssNestedAtRule) cssMediaRule).AddStatementsToBody((ICollection<CssStatement>) styleSheet.GetStatements());
        styleSheet = new CssStyleSheet();
        styleSheet.AddStatement((CssStatement) cssMediaRule);
      }
      return styleSheet;
    }

    private void CollectFonts()
    {
      foreach (CssStatement statement in (IEnumerable<CssStatement>) this.cssStyleSheet.GetStatements())
        this.CollectFonts(statement);
    }

    private void CollectFonts(CssStatement cssStatement)
    {
      switch (cssStatement)
      {
        case CssFontFaceRule _:
          this.fonts.Add((CssFontFaceRule) cssStatement);
          break;
        case CssMediaRule _:
          if (!((CssMediaRule) cssStatement).MatchMediaDevice(this.deviceDescription))
            break;
          using (IEnumerator<CssStatement> enumerator = ((CssNestedAtRule) cssStatement).GetStatements().GetEnumerator())
          {
            while (enumerator.MoveNext())
              this.CollectFonts(enumerator.Current);
            break;
          }
      }
    }
  }
}
