﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.CssContext
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Css.Page;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Util;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  public class CssContext : AbstractCssContext
  {
    private float rootFontSize = CssDimensionParsingUtils.ParseAbsoluteFontSize(CssDefaults.GetDefaultValue("font-size"));
    private CssCounterManager counterManager = new CssCounterManager();
    private bool pagesCounterOrTargetCounterPresent;
    private bool nonPagesTargetCounterPresent;
    private CssRunningManager runningManager = new CssRunningManager();

    public virtual float GetRootFontSize() => this.rootFontSize;

    public virtual void SetRootFontSize(float fontSize) => this.rootFontSize = fontSize;

    public virtual void SetRootFontSize(string fontSizeStr)
    {
      this.rootFontSize = CssDimensionParsingUtils.ParseAbsoluteFontSize(fontSizeStr);
    }

    public virtual CssCounterManager GetCounterManager() => this.counterManager;

    public virtual void SetPagesCounterPresent(bool pagesCounterOrTargetCounterPresent)
    {
      this.pagesCounterOrTargetCounterPresent = pagesCounterOrTargetCounterPresent;
    }

    public virtual bool IsPagesCounterPresent() => this.pagesCounterOrTargetCounterPresent;

    public virtual void SetNonPagesTargetCounterPresent(bool nonPagesTargetCounterPresent)
    {
      this.nonPagesTargetCounterPresent = nonPagesTargetCounterPresent;
    }

    public virtual bool IsNonPagesTargetCounterPresent() => this.nonPagesTargetCounterPresent;

    public virtual CssRunningManager GetRunningManager() => this.runningManager;
  }
}
