﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Resolve.HtmlStylesToCssConverter
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Resolve.Shorthand.Impl;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System;
using System.Collections.Generic;
using System.Globalization;

#nullable disable
namespace iText.Html2pdf.Css.Resolve
{
  internal class HtmlStylesToCssConverter
  {
    private static readonly IDictionary<string, HtmlStylesToCssConverter.IAttributeConverter> htmlAttributeConverters = (IDictionary<string, HtmlStylesToCssConverter.IAttributeConverter>) new Dictionary<string, HtmlStylesToCssConverter.IAttributeConverter>();

    static HtmlStylesToCssConverter()
    {
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("align", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.AlignAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("border", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.BorderAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("bgcolor", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.BgColorAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("cellpadding", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.CellPaddingAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("cellspacing", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.CellSpacingAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("color", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.FontColorAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("dir", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.DirAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("size", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.SizeAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("face", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.FontFaceAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("noshade", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.NoShadeAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("nowrap", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.NoWrapAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("type", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.TypeAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("width", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.WidthAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("height", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.HeightAttributeConverter());
      HtmlStylesToCssConverter.htmlAttributeConverters.Put<string, HtmlStylesToCssConverter.IAttributeConverter>("valign", (HtmlStylesToCssConverter.IAttributeConverter) new HtmlStylesToCssConverter.VAlignAttributeConverter());
    }

    public static IList<CssDeclaration> Convert(IElementNode element)
    {
      List<CssDeclaration> cssDeclarationList = new List<CssDeclaration>();
      if (element.GetAdditionalHtmlStyles() != null)
      {
        Dictionary<string, string> c = new Dictionary<string, string>();
        foreach (IDictionary<string, string> additionalHtmlStyle in (IEnumerable<IDictionary<string, string>>) element.GetAdditionalHtmlStyles())
          c.AddAll<string, string>(additionalHtmlStyle);
        cssDeclarationList.EnsureCapacity<CssDeclaration>(cssDeclarationList.Count + c.Count);
        foreach (KeyValuePair<string, string> keyValuePair in c)
          cssDeclarationList.Add(new CssDeclaration(keyValuePair.Key, keyValuePair.Value));
      }
      foreach (IAttribute attribute in (IEnumerable<IAttribute>) element.GetAttributes())
      {
        HtmlStylesToCssConverter.IAttributeConverter attributeConverter = HtmlStylesToCssConverter.htmlAttributeConverters.Get<string, HtmlStylesToCssConverter.IAttributeConverter>(attribute.GetKey());
        if (attributeConverter != null && attributeConverter.IsSupportedForElement(element.Name()))
          cssDeclarationList.AddAll<CssDeclaration>((IEnumerable<CssDeclaration>) attributeConverter.Convert(element, attribute.GetValue()));
      }
      return (IList<CssDeclaration>) cssDeclarationList;
    }

    private interface IAttributeConverter
    {
      bool IsSupportedForElement(string elementName);

      IList<CssDeclaration> Convert(IElementNode element, string value);
    }

    private class BorderAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      private static void ApplyBordersToTableCells(
        INode node,
        IDictionary<string, string> borderStyles)
      {
        foreach (INode childNode in (IEnumerable<INode>) node.ChildNodes())
        {
          if (childNode is IElementNode)
          {
            IElementNode ielementNode = (IElementNode) childNode;
            if ("td".Equals(ielementNode.Name()) || "th".Equals(ielementNode.Name()))
              ielementNode.AddAdditionalHtmlStyles(borderStyles);
            else
              HtmlStylesToCssConverter.BorderAttributeConverter.ApplyBordersToTableCells(childNode, borderStyles);
          }
        }
      }

      public virtual bool IsSupportedForElement(string elementName)
      {
        return "img".Equals(elementName) || "table".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        float? nullable1 = CssDimensionParsingUtils.ParseFloat(value);
        if (nullable1.HasValue)
        {
          if ("table".Equals(element.Name()))
          {
            float? nullable2 = nullable1;
            float num = 0.0f;
            if (!((double) nullable2.GetValueOrDefault() == (double) num & nullable2.HasValue))
            {
              IList<CssDeclaration> cssDeclarationList = ((AbstractBorderShorthandResolver) new BorderShorthandResolver()).ResolveShorthand("1px solid");
              IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>(cssDeclarationList.Count);
              foreach (CssDeclaration cssDeclaration in (IEnumerable<CssDeclaration>) cssDeclarationList)
                dictionary.Put<string, string>(cssDeclaration.GetProperty(), cssDeclaration.GetExpression());
              HtmlStylesToCssConverter.BorderAttributeConverter.ApplyBordersToTableCells((INode) element, dictionary);
            }
          }
          float? nullable3 = nullable1;
          float num1 = 0.0f;
          if ((double) nullable3.GetValueOrDefault() >= (double) num1 & nullable3.HasValue)
            return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
            {
              new CssDeclaration("border", value + "px solid")
            });
        }
        return JavaCollectionsUtil.EmptyList<CssDeclaration>();
      }
    }

    private class CellPaddingAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      private static void ApplyPaddingsToTableCells(
        INode node,
        IDictionary<string, string> paddingStyle)
      {
        foreach (INode childNode in (IEnumerable<INode>) node.ChildNodes())
        {
          if (childNode is IElementNode)
          {
            IElementNode ielementNode = (IElementNode) childNode;
            if ("td".Equals(ielementNode.Name()) || "th".Equals(ielementNode.Name()))
              ielementNode.AddAdditionalHtmlStyles(paddingStyle);
            else
              HtmlStylesToCssConverter.CellPaddingAttributeConverter.ApplyPaddingsToTableCells(childNode, paddingStyle);
          }
        }
      }

      public virtual bool IsSupportedForElement(string elementName) => "table".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        if (CssDimensionParsingUtils.ParseFloat(value).HasValue && "table".Equals(element.Name()))
        {
          IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>();
          dictionary.Put<string, string>("padding", value + "px");
          HtmlStylesToCssConverter.CellPaddingAttributeConverter.ApplyPaddingsToTableCells((INode) element, dictionary);
        }
        return JavaCollectionsUtil.EmptyList<CssDeclaration>();
      }
    }

    private class CellSpacingAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => "table".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("border-spacing", value)
        });
      }
    }

    private class BgColorAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      private static ICollection<string> supportedTags = (ICollection<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[10]
      {
        "body",
        "col",
        "colgroup",
        "marquee",
        "table",
        "tbody",
        "tfoot",
        "td",
        "th",
        "tr"
      }));

      public virtual bool IsSupportedForElement(string elementName)
      {
        return HtmlStylesToCssConverter.BgColorAttributeConverter.supportedTags.Contains(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("background-color", value)
        });
      }
    }

    private class FontColorAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => "font".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("color", value)
        });
      }
    }

    private class SizeAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "font".Equals(elementName) || "hr".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        string str1 = (string) null;
        string str2 = (string) null;
        string str3 = element.Name();
        if ("font".Equals(str3))
        {
          str2 = "font-size";
          try
          {
            int num1 = value.Contains("-") ? 1 : (value.Contains("+") ? 1 : 0);
            int num2 = System.Convert.ToInt32(value, (IFormatProvider) CultureInfo.InvariantCulture);
            if (num1 != 0)
              num2 = 3 + num2;
            if (num2 < 2)
              str1 = "x-small";
            else if (num2 > 6)
            {
              str1 = "48px";
            }
            else
            {
              switch (num2)
              {
                case 2:
                  str1 = "small";
                  break;
                case 3:
                  str1 = "medium";
                  break;
                case 4:
                  str1 = "large";
                  break;
                case 5:
                  str1 = "x-large";
                  break;
                case 6:
                  str1 = "xx-large";
                  break;
              }
            }
          }
          catch (FormatException ex)
          {
            str1 = "medium";
          }
        }
        else if ("hr".Equals(str3))
        {
          str2 = "height";
          str1 = value + "px";
        }
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration(str2, str1)
        });
      }
    }

    private class FontFaceAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => "font".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("font-family", value)
        });
      }
    }

    private class TypeAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => "ol".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        string str = (string) null;
        switch (value)
        {
          case "1":
            str = "decimal";
            break;
          case "A":
            str = "upper-alpha";
            break;
          case "a":
            str = "lower-alpha";
            break;
          case "I":
            str = "upper-roman";
            break;
          case "i":
            str = "lower-roman";
            break;
        }
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("list-style-type", str)
        });
      }
    }

    private class DirAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => true;

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("direction", value)
        });
      }
    }

    private class WidthAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "hr".Equals(elementName) || "img".Equals(elementName) || "table".Equals(elementName) || "td".Equals(elementName) || "th".Equals(elementName) || "colgroup".Equals(elementName) || "col".Equals(elementName) || "object".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        string str = StringUtil.ReplaceAll(value, ";+$", "");
        if (!CssTypesValidationUtils.IsMetricValue(str) && !str.EndsWith("%"))
          str += "px";
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("width", str)
        });
      }
    }

    private class HeightAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "img".Equals(elementName) || "td".Equals(elementName) || "object".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        string str = StringUtil.ReplaceAll(value, ";+$", "");
        if (!CssTypesValidationUtils.IsMetricValue(str) && !str.EndsWith("%"))
          str += "px";
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("height", str)
        });
      }
    }

    private class AlignAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "hr".Equals(elementName) || "table".Equals(elementName) || "img".Equals(elementName) || "td".Equals(elementName) || "div".Equals(elementName) || "p".Equals(elementName) || "caption".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        IList<CssDeclaration> cssDeclarationList = (IList<CssDeclaration>) new List<CssDeclaration>(2);
        if ("hr".Equals(element.Name()) || "table".Equals(element.Name()) && "center".Equals(value))
        {
          string str1 = (string) null;
          string str2 = (string) null;
          if ("right".Equals(value))
          {
            str1 = "auto";
            str2 = "0";
          }
          else if ("left".Equals(value))
          {
            str1 = "0";
            str2 = "auto";
          }
          else if ("center".Equals(value))
          {
            str1 = "auto";
            str2 = "auto";
          }
          if (str1 != null)
          {
            cssDeclarationList.Add(new CssDeclaration("margin-left", str1));
            cssDeclarationList.Add(new CssDeclaration("margin-right", str2));
          }
        }
        else if ("table".Equals(element.Name()) || "img".Equals(element.Name()))
        {
          if ("img".Equals(element.Name()) && ("top".Equals(value) || "middle".Equals(value)))
            cssDeclarationList.Add(new CssDeclaration("vertical-align", value));
          else if ("left".Equals(value) || "right".Equals(value))
            cssDeclarationList.Add(new CssDeclaration("float", value));
        }
        else if ("caption".Equals(element.Name()))
          cssDeclarationList.Add(new CssDeclaration("caption-side", value));
        else
          cssDeclarationList.Add(new CssDeclaration("text-align", value));
        return cssDeclarationList;
      }
    }

    private class NoShadeAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName) => "hr".Equals(elementName);

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[3]
        {
          new CssDeclaration("height", "2px"),
          new CssDeclaration("border-width", "0"),
          new CssDeclaration("background-color", "gray")
        });
      }
    }

    private class NoWrapAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "td".Equals(elementName) || "th".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaCollectionsUtil.SingletonList<CssDeclaration>(new CssDeclaration("white-space", "nowrap"));
      }
    }

    private class VAlignAttributeConverter : HtmlStylesToCssConverter.IAttributeConverter
    {
      public virtual bool IsSupportedForElement(string elementName)
      {
        return "td".Equals(elementName) || "th".Equals(elementName) || "tr".Equals(elementName);
      }

      public virtual IList<CssDeclaration> Convert(IElementNode element, string value)
      {
        return JavaUtil.ArraysAsList<CssDeclaration>(new CssDeclaration[1]
        {
          new CssDeclaration("vertical-align", value)
        });
      }
    }
  }
}
