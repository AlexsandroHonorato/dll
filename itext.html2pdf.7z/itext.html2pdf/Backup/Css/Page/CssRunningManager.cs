﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Page.CssRunningManager
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach.Impl.Layout;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Page
{
  public class CssRunningManager
  {
    private IDictionary<string, LinkedHashSet<RunningElementContainer>> runningElements = (IDictionary<string, LinkedHashSet<RunningElementContainer>>) new Dictionary<string, LinkedHashSet<RunningElementContainer>>();

    public virtual void AddRunningElement(string runningElemName, RunningElementContainer container)
    {
      LinkedHashSet<RunningElementContainer> linkedHashSet = this.runningElements.Get<string, LinkedHashSet<RunningElementContainer>>(runningElemName);
      if (linkedHashSet == null)
      {
        linkedHashSet = new LinkedHashSet<RunningElementContainer>();
        this.runningElements.Put<string, LinkedHashSet<RunningElementContainer>>(runningElemName, linkedHashSet);
      }
      linkedHashSet.Add(container);
    }

    public virtual RunningElementContainer GetRunningElement(
      string runningElemName,
      string occurrenceOption,
      int pageNum)
    {
      LinkedHashSet<RunningElementContainer> c = this.runningElements.Get<string, LinkedHashSet<RunningElementContainer>>(runningElemName);
      if (c == null || ((ICollection<RunningElementContainer>) c).IsEmpty<RunningElementContainer>())
        return (RunningElementContainer) null;
      bool flag1 = "last".Equals(occurrenceOption);
      bool flag2 = "first-except".Equals(occurrenceOption);
      bool flag3 = "start".Equals(occurrenceOption);
      RunningElementContainer runningElement = (RunningElementContainer) null;
      foreach (RunningElementContainer elementContainer in c)
      {
        if (elementContainer.GetOccurrencePage() != 0 && elementContainer.GetOccurrencePage() <= pageNum)
        {
          if (elementContainer.GetOccurrencePage() < pageNum)
            runningElement = elementContainer;
          if (elementContainer.GetOccurrencePage() == pageNum)
          {
            if (flag2)
              return (RunningElementContainer) null;
            if (!flag3 || elementContainer.IsFirstOnPage())
              runningElement = elementContainer;
            if (!flag1)
              break;
          }
        }
      }
      return runningElement;
    }
  }
}
