﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Page.PageMarginRunningElementNode
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Node;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Page
{
  public class PageMarginRunningElementNode : INode
  {
    private string runningElementName;
    private string runningElementOccurrence;

    public PageMarginRunningElementNode(string runningElementName, string runningElementOccurrence)
    {
      this.runningElementName = runningElementName;
      this.runningElementOccurrence = runningElementOccurrence;
    }

    public virtual IList<INode> ChildNodes() => throw new NotSupportedException();

    public virtual void AddChild(INode node) => throw new NotSupportedException();

    public virtual INode ParentNode() => throw new NotSupportedException();

    public virtual string GetRunningElementName() => this.runningElementName;

    public virtual string GetRunningElementOccurrence() => this.runningElementOccurrence;
  }
}
