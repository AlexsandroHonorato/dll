﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Util.CssStyleSheetAnalyzer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Media;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Parse;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Util
{
  public class CssStyleSheetAnalyzer
  {
    private const int TARGET_COUNTER_MIN_PARAMS_SIZE = 2;
    private const int TARGET_COUNTERS_MIN_PARAMS_SIZE = 3;

    private CssStyleSheetAnalyzer()
    {
    }

    public static bool CheckNonPagesTargetCounterPresence(CssStyleSheet styleSheet)
    {
      return CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence((ICollection<CssStatement>) styleSheet.GetStatements());
    }

    private static bool CheckNonPagesTargetCounterPresence(ICollection<CssStatement> statements)
    {
      bool flag1 = false;
      foreach (CssStatement statement in (IEnumerable<CssStatement>) statements)
      {
        bool flag2 = false;
        switch (statement)
        {
          case CssMarginRule _:
            flag2 = CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            break;
          case CssMediaRule _:
            flag2 = CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            break;
          case CssPageRule _:
            flag2 = CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            break;
          case CssRuleSet _:
            flag2 = CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence((CssRuleSet) statement);
            break;
        }
        flag1 |= flag2;
      }
      return flag1;
    }

    private static bool CheckNonPagesTargetCounterPresence(CssRuleSet ruleSet)
    {
      bool flag = false;
      foreach (CssDeclaration importantDeclaration in (IEnumerable<CssDeclaration>) ruleSet.GetImportantDeclarations())
        flag = flag || CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence(importantDeclaration);
      foreach (CssDeclaration normalDeclaration in (IEnumerable<CssDeclaration>) ruleSet.GetNormalDeclarations())
        flag = flag || CssStyleSheetAnalyzer.CheckNonPagesTargetCounterPresence(normalDeclaration);
      return flag;
    }

    private static bool CheckNonPagesTargetCounterPresence(CssDeclaration declaration)
    {
      bool flag = false;
      if ("content".Equals(declaration.GetProperty()))
      {
        CssDeclarationValueTokenizer declarationValueTokenizer = new CssDeclarationValueTokenizer(declaration.GetExpression());
        CssDeclarationValueTokenizer.Token nextValidToken;
        while ((nextValidToken = declarationValueTokenizer.GetNextValidToken()) != null)
        {
          if (!nextValidToken.IsString())
          {
            if (nextValidToken.GetValue().StartsWith("target-counter("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("target-counter".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || @params.Length >= 2 && !CssStyleSheetAnalyzer.CheckTargetCounterParamsForPageOrPagesReferencePresence(@params);
            }
            else if (nextValidToken.GetValue().StartsWith("target-counters("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("target-counters".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || @params.Length >= 3 && !CssStyleSheetAnalyzer.CheckTargetCounterParamsForPageOrPagesReferencePresence(@params);
            }
          }
        }
      }
      return flag;
    }

    public static bool CheckPagesCounterPresence(CssStyleSheet styleSheet)
    {
      return CssStyleSheetAnalyzer.CheckPagesCounterPresence((ICollection<CssStatement>) styleSheet.GetStatements());
    }

    private static bool CheckPagesCounterPresence(ICollection<CssStatement> statements)
    {
      bool flag = false;
      foreach (CssStatement statement in (IEnumerable<CssStatement>) statements)
      {
        switch (statement)
        {
          case CssMarginRule _:
            flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            continue;
          case CssMediaRule _:
            flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            continue;
          case CssPageRule _:
            flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence((ICollection<CssStatement>) ((CssNestedAtRule) statement).GetStatements());
            continue;
          case CssRuleSet _:
            flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence((CssRuleSet) statement);
            continue;
          default:
            continue;
        }
      }
      return flag;
    }

    private static bool CheckPagesCounterPresence(CssRuleSet ruleSet)
    {
      bool flag = false;
      foreach (CssDeclaration importantDeclaration in (IEnumerable<CssDeclaration>) ruleSet.GetImportantDeclarations())
        flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence(importantDeclaration);
      foreach (CssDeclaration normalDeclaration in (IEnumerable<CssDeclaration>) ruleSet.GetNormalDeclarations())
        flag = flag || CssStyleSheetAnalyzer.CheckPagesCounterPresence(normalDeclaration);
      return flag;
    }

    private static bool CheckPagesCounterPresence(CssDeclaration declaration)
    {
      bool flag = false;
      if ("content".Equals(declaration.GetProperty()))
      {
        CssDeclarationValueTokenizer declarationValueTokenizer = new CssDeclarationValueTokenizer(declaration.GetExpression());
        CssDeclarationValueTokenizer.Token nextValidToken;
        while ((nextValidToken = declarationValueTokenizer.GetNextValidToken()) != null)
        {
          if (!nextValidToken.IsString())
          {
            if (nextValidToken.GetValue().StartsWith("counters("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("counters".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || CssStyleSheetAnalyzer.CheckCounterFunctionParamsForPagesReferencePresence(@params);
            }
            else if (nextValidToken.GetValue().StartsWith("counter("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("counter".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || CssStyleSheetAnalyzer.CheckCounterFunctionParamsForPagesReferencePresence(@params);
            }
            else if (nextValidToken.GetValue().StartsWith("target-counter("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("target-counter".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || @params.Length >= 2 && CssStyleSheetAnalyzer.CheckTargetCounterParamsForPageOrPagesReferencePresence(@params);
            }
            else if (nextValidToken.GetValue().StartsWith("target-counters("))
            {
              string[] @params = StringUtil.Split(nextValidToken.GetValue().JSubstring("target-counters".Length + 1, nextValidToken.GetValue().Length - 1), ",");
              flag = flag || @params.Length >= 3 && CssStyleSheetAnalyzer.CheckTargetCounterParamsForPageOrPagesReferencePresence(@params);
            }
          }
        }
      }
      return flag;
    }

    private static bool CheckCounterFunctionParamsForPagesReferencePresence(string[] @params)
    {
      return @params.Length != 0 && "pages".Equals(@params[0].Trim());
    }

    private static bool CheckTargetCounterParamsForPageOrPagesReferencePresence(string[] @params)
    {
      return "page".Equals(@params[1].Trim()) || "pages".Equals(@params[1].Trim());
    }
  }
}
