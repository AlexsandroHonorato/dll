﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.WidthHeightApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class WidthHeightApplierUtil
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (WidthHeightApplierUtil));

    private WidthHeightApplierUtil()
    {
    }

    public static void ApplyWidthHeight(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      string str1 = cssProps.Get<string, string>("width");
      if (!"auto".Equals(str1) && str1 != null)
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str1, absoluteLength, rootFontSize);
        element.SetProperty(77, (object) lengthValueToPt);
      }
      string str2 = cssProps.Get<string, string>("min-width");
      if (!"auto".Equals(str2) && str2 != null)
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str2, absoluteLength, rootFontSize);
        element.SetProperty(80, (object) lengthValueToPt);
      }
      string str3 = cssProps.Get<string, string>("max-width");
      if (!"auto".Equals(str3) && str3 != null)
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str3, absoluteLength, rootFontSize);
        element.SetProperty(79, (object) lengthValueToPt);
      }
      bool flag1 = element is Table;
      bool flag2 = element is Cell;
      UnitValue unitValue1 = (UnitValue) null;
      string str4 = cssProps.Get<string, string>("height");
      if (str4 != null && !"auto".Equals(str4))
      {
        unitValue1 = CssDimensionParsingUtils.ParseLengthValueToPt(str4, absoluteLength, rootFontSize);
        if (unitValue1 != null && !flag1 && !flag2)
          element.SetProperty(27, (object) unitValue1);
      }
      string str5 = cssProps.Get<string, string>("max-height");
      float num1 = 0.0f;
      UnitValue unitValue2 = new UnitValue(1, 0.0f);
      if (str5 != null)
      {
        unitValue2 = CssDimensionParsingUtils.ParseLengthValueToPt(str5, absoluteLength, rootFontSize);
        if (unitValue2 != null && !flag1 && !flag2)
          num1 = unitValue2.GetValue();
      }
      if ((double) num1 > 0.0)
        element.SetProperty(84, (object) unitValue2);
      string str6 = cssProps.Get<string, string>("min-height");
      float num2 = 0.0f;
      UnitValue unitValue3 = new UnitValue(1, 0.0f);
      if (str6 != null)
      {
        unitValue3 = CssDimensionParsingUtils.ParseLengthValueToPt(str6, absoluteLength, rootFontSize);
        if (unitValue3 != null && !flag2)
          num2 = unitValue3.GetValue();
      }
      if (flag1 | flag2 && unitValue1 != null && (double) unitValue1.GetValue() > (double) num2)
      {
        if ((double) unitValue1.GetValue() > 0.0)
          element.SetProperty(85, (object) unitValue1);
      }
      else if ((double) num2 > 0.0)
        element.SetProperty(85, (object) unitValue3);
      if (!"border-box".Equals(cssProps.Get<string, string>("box-sizing")))
        return;
      element.SetProperty(105, (object) BoxSizingPropertyValue.BORDER_BOX);
    }
  }
}
