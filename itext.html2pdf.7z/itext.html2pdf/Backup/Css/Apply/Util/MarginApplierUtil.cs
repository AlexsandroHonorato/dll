﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.MarginApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Globalization;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class MarginApplierUtil
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (MarginApplierUtil));

    private MarginApplierUtil()
    {
    }

    public static void ApplyMargins(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      MarginApplierUtil.ApplyMargins(cssProps, context, element, 0.0f, 0.0f);
    }

    public static void ApplyMargins(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element,
      float baseValueVertical,
      float baseValueHorizontal)
    {
      string marginValue1 = cssProps.Get<string, string>("margin-top");
      string marginValue2 = cssProps.Get<string, string>("margin-bottom");
      string marginValue3 = cssProps.Get<string, string>("margin-left");
      string marginValue4 = cssProps.Get<string, string>("margin-right");
      int num = element is IBlockElement ? 1 : ("block".Equals(cssProps.Get<string, string>("display")) ? 1 : 0);
      bool flag1 = element is Image;
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      if ((num | (flag1 ? 1 : 0)) != 0)
      {
        MarginApplierUtil.TrySetMarginIfNotAuto(46, marginValue1, element, absoluteLength, rootFontSize, baseValueVertical);
        MarginApplierUtil.TrySetMarginIfNotAuto(43, marginValue2, element, absoluteLength, rootFontSize, baseValueVertical);
      }
      bool flag2 = !MarginApplierUtil.TrySetMarginIfNotAuto(44, marginValue3, element, absoluteLength, rootFontSize, baseValueHorizontal);
      bool flag3 = !MarginApplierUtil.TrySetMarginIfNotAuto(45, marginValue4, element, absoluteLength, rootFontSize, baseValueHorizontal);
      if (num == 0)
        return;
      if (flag2 & flag3)
        element.SetProperty(28, (object) HorizontalAlignment.CENTER);
      else if (flag2)
      {
        element.SetProperty(28, (object) HorizontalAlignment.RIGHT);
      }
      else
      {
        if (!flag3)
          return;
        element.SetProperty(28, (object) HorizontalAlignment.LEFT);
      }
    }

    private static bool TrySetMarginIfNotAuto(
      int marginProperty,
      string marginValue,
      IPropertyContainer element,
      float em,
      float rem,
      float baseValue)
    {
      if ("auto".Equals(marginValue))
        return false;
      float? marginValue1 = MarginApplierUtil.ParseMarginValue(marginValue, em, rem, baseValue);
      if (marginValue1.HasValue)
        element.SetProperty(marginProperty, (object) UnitValue.CreatePointValue(marginValue1.Value));
      return true;
    }

    private static float? ParseMarginValue(
      string marginValString,
      float em,
      float rem,
      float baseValue)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(marginValString, em, rem);
      if (lengthValueToPt == null)
        return new float?();
      if (lengthValueToPt.IsPointValue())
        return new float?(lengthValueToPt.GetValue());
      if ((double) baseValue != 0.0)
        return new float?(Convert.ToSingle((object) ((double) baseValue * (double) lengthValueToPt.GetValue() * 0.01), (IFormatProvider) CultureInfo.InvariantCulture));
      LoggerExtensions.LogError(MarginApplierUtil.logger, "Margin value in percents not supported", Array.Empty<object>());
      return new float?();
    }
  }
}
