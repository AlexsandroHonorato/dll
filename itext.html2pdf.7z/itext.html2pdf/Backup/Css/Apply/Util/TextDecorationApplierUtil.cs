﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.TextDecorationApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;
using System.Text;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class TextDecorationApplierUtil
  {
    private const string IGNORED = "__ignored__";
    private static readonly TextDecorationApplierUtil.SupportedTextDecoration[] SUPPORTED_TEXT_DECORATION_PROPERTIES = new TextDecorationApplierUtil.SupportedTextDecoration[3]
    {
      new TextDecorationApplierUtil.SupportedTextDecoration("text-decoration-line", "__ignored__"),
      new TextDecorationApplierUtil.SupportedTextDecoration("text-decoration-style", "solid"),
      new TextDecorationApplierUtil.SupportedTextDecoration("text-decoration-color", "currentcolor")
    };
    private static readonly int AMOUNT = TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES.Length;

    private TextDecorationApplierUtil()
    {
    }

    public static void PropagateTextDecorationProperties(IElementNode currentNode)
    {
      TextDecorationApplierUtil.ExpandTextDecorationProperties(currentNode);
      if (!TextDecorationApplierUtil.ShouldPropagateTextDecorationProperties(currentNode))
        return;
      TextDecorationApplierUtil.MergeProperties(currentNode);
    }

    private static bool ShouldOnlyKeepParentProperties(IElementNode currentNode)
    {
      return ((IStylesContainer) currentNode).GetStyles().Get<string, string>("text-decoration-line") != null && ((IStylesContainer) currentNode).GetStyles().Get<string, string>("text-decoration-line").Contains("none");
    }

    private static bool ShouldPropagateTextDecorationProperties(IElementNode currentNode)
    {
      IElementNode node = (IElementNode) ((INode) currentNode).ParentNode();
      return node != null && ((IStylesContainer) node).GetStyles() != null && (!TextDecorationApplierUtil.DoesNotHaveTextDecorationKey(currentNode) || !TextDecorationApplierUtil.DoesNotHaveTextDecorationKey(node)) && !"inline-block".Equals(((IStylesContainer) currentNode).GetStyles().Get<string, string>("display"));
    }

    private static IList<string> ParseTokenIntoList(IElementNode node, string propertyName)
    {
      string str = ((IStylesContainer) node).GetStyles().Get<string, string>(propertyName);
      return str != null ? JavaUtil.ArraysAsList<string>(StringUtil.Split(str, "\\s+")) : (IList<string>) new List<string>();
    }

    private static void MergeProperties(IElementNode node)
    {
      bool flag = TextDecorationApplierUtil.ShouldOnlyKeepParentProperties(node);
      IList<IList<string>> stringListList = (IList<IList<string>>) new List<IList<string>>();
      foreach (TextDecorationApplierUtil.SupportedTextDecoration supportedTextDecoration in TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES)
      {
        IList<string> tokenIntoList = TextDecorationApplierUtil.ParseTokenIntoList(node, supportedTextDecoration.GetPropertyName());
        IList<string> c = (IList<string>) new List<string>((IEnumerable<string>) TextDecorationApplierUtil.ParseTokenIntoList((IElementNode) ((INode) node).ParentNode(), supportedTextDecoration.GetPropertyName()));
        stringListList.Add(c);
        if (!(tokenIntoList.IsEmpty<string>() | flag))
          c.AddAll<string>((IEnumerable<string>) tokenIntoList);
      }
      int count = stringListList[0].Count;
      ICollection<string> strings = (ICollection<string>) new LinkedHashSet<string>();
      IList<int> intList = (IList<int>) new List<int>();
      for (int index1 = 0; index1 < count; ++index1)
      {
        StringBuilder stringBuilder = new StringBuilder();
        for (int index2 = 0; index2 < TextDecorationApplierUtil.AMOUNT; ++index2)
          stringBuilder.Append(stringListList[index2][index1]);
        string str = stringBuilder.ToString();
        if (!str.Contains("__ignored__") && !strings.Contains(str))
        {
          intList.Add(index1);
          strings.Add(stringBuilder.ToString());
        }
      }
      for (int index3 = 0; index3 < TextDecorationApplierUtil.AMOUNT; ++index3)
      {
        StringBuilder stringBuilder = new StringBuilder();
        foreach (int num in (IEnumerable<int>) intList)
        {
          int index4 = new int?(num).Value;
          stringBuilder.Append(stringListList[index3][index4]).Append(' ');
        }
        ((IStylesContainer) node).GetStyles().Put<string, string>(TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES[index3].GetPropertyName(), stringBuilder.ToString().Trim());
      }
    }

    private static bool DoesNotHaveTextDecorationKey(IElementNode node)
    {
      for (int index = 0; index < TextDecorationApplierUtil.AMOUNT; ++index)
      {
        if (((IStylesContainer) node).GetStyles().ContainsKey(TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES[index].GetPropertyName()))
          return false;
      }
      return true;
    }

    private static void ExpandTextDecorationProperties(IElementNode node)
    {
      if (TextDecorationApplierUtil.DoesNotHaveTextDecorationKey(node))
        return;
      IList<string[]> currentValuesParsed = (IList<string[]>) new List<string[]>(TextDecorationApplierUtil.AMOUNT);
      foreach (TextDecorationApplierUtil.SupportedTextDecoration supportedTextDecoration in TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES)
      {
        string str = ((IStylesContainer) node).GetStyles().Get<string, string>(supportedTextDecoration.GetPropertyName());
        string[] strArray = supportedTextDecoration.GetDefaultValue();
        if (str != null)
          strArray = StringUtil.Split(str, "\\s+");
        currentValuesParsed.Add(strArray);
      }
      int length = currentValuesParsed[0].Length;
      foreach (string[] strArray in (IEnumerable<string[]>) currentValuesParsed)
      {
        if (strArray.Length > length)
          length = strArray.Length;
      }
      IList<StringBuilder> stringBuilderList = (IList<StringBuilder>) new List<StringBuilder>(TextDecorationApplierUtil.AMOUNT);
      for (int index = 0; index < TextDecorationApplierUtil.AMOUNT; ++index)
        stringBuilderList.Add(new StringBuilder());
      for (int i = 0; i < length; ++i)
      {
        for (int index = 0; index < TextDecorationApplierUtil.AMOUNT; ++index)
          stringBuilderList[index].Append(TextDecorationApplierUtil.GetValueAtIndexOrLast(currentValuesParsed, i, index)).Append(' ');
      }
      for (int index = 0; index < TextDecorationApplierUtil.AMOUNT; ++index)
        ((IStylesContainer) node).GetStyles().Put<string, string>(TextDecorationApplierUtil.SUPPORTED_TEXT_DECORATION_PROPERTIES[index].GetPropertyName(), stringBuilderList[index].ToString().Trim());
    }

    private static string GetValueAtIndexOrLast(
      IList<string[]> currentValuesParsed,
      int i,
      int indexProperty)
    {
      return currentValuesParsed[indexProperty].Length - 1 <= i ? currentValuesParsed[indexProperty][currentValuesParsed[indexProperty].Length - 1] : currentValuesParsed[indexProperty][i];
    }

    private sealed class SupportedTextDecoration
    {
      private readonly string propertyName;
      private readonly string[] defaultValue;

      public SupportedTextDecoration(string propertyName, string defaultValue)
      {
        this.propertyName = propertyName;
        this.defaultValue = new string[1]{ defaultValue };
      }

      public string GetPropertyName() => this.propertyName;

      public string[] GetDefaultValue() => (string[]) this.defaultValue.Clone();
    }
  }
}
