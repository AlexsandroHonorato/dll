﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.ListStyleApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Kernel.Colors;
using iText.Kernel.Colors.Gradients;
using iText.Kernel.Geom;
using iText.Kernel.Numbering;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Xobject;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Exceptions;
using iText.StyledXmlParser.Node;
using iText.Svg.Element;
using iText.Svg.Xobject;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class ListStyleApplierUtil
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (ListStyleApplierUtil));
    private const float LIST_ITEM_MARKER_SIZE_COEFFICIENT = 0.4f;
    private const int GREEK_ALPHABET_LENGTH = 24;
    private static readonly char[] GREEK_LOWERCASE = new char[24];
    private const string DISC_SYMBOL = "•";
    private const string CIRCLE_SYMBOL = "○";
    private const string SQUARE_SYMBOL = "■";

    static ListStyleApplierUtil()
    {
      for (int index = 0; index < 24; ++index)
        ListStyleApplierUtil.GREEK_LOWERCASE[index] = (char) (945 + index + (index > 16 ? 1 : 0));
    }

    private ListStyleApplierUtil()
    {
    }

    public static void ApplyListStyleImageProperty(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("list-style-image");
      PdfXObject xObject = (PdfXObject) null;
      if (str == null || "none".Equals(str))
        return;
      if (CssGradientUtil.IsCssLinearGradientValue(str))
      {
        float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
        float rootFontSize = context.GetCssContext().GetRootFontSize();
        try
        {
          StrategyBasedLinearGradientBuilder cssLinearGradient = CssGradientUtil.ParseCssLinearGradient(str, absoluteLength, rootFontSize);
          if (cssLinearGradient != null)
          {
            Rectangle rectangle = new Rectangle(0.0f, 0.0f, absoluteLength * 0.4f, absoluteLength * 0.4f);
            PdfDocument pdfDocument = context.GetPdfDocument();
            Color color = ((AbstractLinearGradientBuilder) cssLinearGradient).BuildColor(rectangle, (AffineTransform) null, pdfDocument);
            if (color != null)
            {
              xObject = (PdfXObject) new PdfFormXObject(rectangle);
              new PdfCanvas((PdfFormXObject) xObject, context.GetPdfDocument()).SetColor(color, true).Rectangle(rectangle).Fill();
            }
          }
        }
        catch (StyledXMLParserException ex)
        {
          LoggerExtensions.LogWarning(ListStyleApplierUtil.LOGGER, MessageFormatUtil.Format("Invalid gradient declaration: {0}", new object[1]
          {
            (object) str
          }), Array.Empty<object>());
        }
      }
      else
        xObject = context.GetResourceResolver().RetrieveImage(CssUtils.ExtractUrl(str));
      if (xObject == null)
        return;
      Image image;
      if (xObject is PdfImageXObject)
        image = new Image((PdfImageXObject) xObject);
      else if (xObject is SvgImageXObject)
        image = (Image) new SvgImage((SvgImageXObject) xObject);
      else
        image = xObject is PdfFormXObject ? new Image((PdfFormXObject) xObject) : throw new InvalidOperationException();
      element.SetProperty(37, (object) image);
      element.SetProperty(39, (object) 5);
    }

    public static void ApplyListStyleTypeProperty(
      IStylesContainer stylesContainer,
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      string str1 = cssProps.Get<string, string>("list-style-type");
      if ("disc".Equals(str1))
        ListStyleApplierUtil.SetDiscStyle(element, absoluteLength);
      else if ("circle".Equals(str1))
        ListStyleApplierUtil.SetCircleStyle(element, absoluteLength);
      else if ("square".Equals(str1))
        ListStyleApplierUtil.SetSquareStyle(element, absoluteLength);
      else if ("decimal".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.DECIMAL);
      else if ("decimal-leading-zero".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.DECIMAL_LEADING_ZERO);
      else if ("upper-alpha".Equals(str1) || "upper-latin".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.ENGLISH_UPPER);
      else if ("lower-alpha".Equals(str1) || "lower-latin".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.ENGLISH_LOWER);
      else if ("upper-roman".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.ROMAN_UPPER);
      else if ("lower-roman".Equals(str1))
        ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.ROMAN_LOWER);
      else if ("lower-greek".Equals(str1))
        element.SetProperty(37, (object) new ListStyleApplierUtil.HtmlAlphabetSymbolFactory(ListStyleApplierUtil.GREEK_LOWERCASE));
      else if ("none".Equals(str1))
      {
        ListStyleApplierUtil.SetListSymbol(element, new Text(""));
      }
      else
      {
        if (str1 != null)
          LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (ListStyleApplierUtil)), MessageFormatUtil.Format("Not supported list style type: {0}", new object[1]
          {
            (object) str1
          }), Array.Empty<object>());
        if (!(stylesContainer is IElementNode))
          return;
        string str2 = ((IElementNode) stylesContainer).Name();
        if ("ul".Equals(str2))
        {
          ListStyleApplierUtil.SetDiscStyle(element, absoluteLength);
        }
        else
        {
          if (!"ol".Equals(str2))
            return;
          ListStyleApplierUtil.SetListSymbol(element, ListNumberingType.DECIMAL);
        }
      }
    }

    public static void SetDiscStyle(IPropertyContainer element, float em)
    {
      Text text = new Text("•");
      element.SetProperty(37, (object) text);
      ListStyleApplierUtil.SetListSymbolIndent(element, em);
    }

    private static void SetListSymbol(IPropertyContainer container, Text text)
    {
      switch (container)
      {
        case List _:
          ((List) container).SetListSymbol(text);
          break;
        case ListItem _:
          ((ListItem) container).SetListSymbol(text);
          break;
      }
    }

    private static void SetListSymbol(
      IPropertyContainer container,
      ListNumberingType listNumberingType)
    {
      switch (container)
      {
        case List _:
          ((List) container).SetListSymbol(listNumberingType);
          break;
        case ListItem _:
          ((ListItem) container).SetListSymbol(listNumberingType);
          break;
      }
    }

    private static void SetSquareStyle(IPropertyContainer element, float em)
    {
      Text text = new Text("■");
      text.SetTextRise((float) (1.5 * (double) em / 12.0));
      text.SetFontSize((float) (4.5 * (double) em / 12.0));
      element.SetProperty(37, (object) text);
      ListStyleApplierUtil.SetListSymbolIndent(element, em);
    }

    private static void SetCircleStyle(IPropertyContainer element, float em)
    {
      Text text = new Text("○");
      text.SetTextRise((float) (1.5 * (double) em / 12.0));
      text.SetFontSize((float) (4.5 * (double) em / 12.0));
      element.SetProperty(37, (object) text);
      ListStyleApplierUtil.SetListSymbolIndent(element, em);
    }

    private static void SetListSymbolIndent(IPropertyContainer element, float em)
    {
      ListSymbolPosition? property = element.GetProperty<ListSymbolPosition?>(83);
      if (1 == (int) property.GetValueOrDefault() & property.HasValue)
        element.SetProperty(39, (object) (float) (1.5 * (double) em));
      else
        element.SetProperty(39, (object) 7.75f);
    }

    private class HtmlAlphabetSymbolFactory : IListSymbolFactory
    {
      private readonly char[] alphabet;

      public HtmlAlphabetSymbolFactory(char[] alphabet) => this.alphabet = alphabet;

      public virtual IElement CreateSymbol(
        int index,
        IPropertyContainer list,
        IPropertyContainer listItem)
      {
        object itemOrListProperty1 = ListStyleApplierUtil.HtmlAlphabetSymbolFactory.GetListItemOrListProperty(listItem, list, 41);
        object itemOrListProperty2 = ListStyleApplierUtil.HtmlAlphabetSymbolFactory.GetListItemOrListProperty(listItem, list, 42);
        return (IElement) new Text(itemOrListProperty1?.ToString() + AlphabetNumbering.ToAlphabetNumber(index, this.alphabet) + itemOrListProperty2?.ToString());
      }

      private static object GetListItemOrListProperty(
        IPropertyContainer listItem,
        IPropertyContainer list,
        int propertyId)
      {
        return !listItem.HasProperty(propertyId) ? list.GetProperty<object>(propertyId) : listItem.GetProperty<object>(propertyId);
      }
    }
  }
}
