﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.TransformationApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.IO.Util;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using System;
using System.Collections.Generic;
using System.Globalization;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class TransformationApplierUtil
  {
    private TransformationApplierUtil()
    {
    }

    public static void ApplyTransformation(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      if (cssProps.Get<string, string>("transform") == null)
        return;
      string[] strArray = StringUtil.Split(cssProps.Get<string, string>("transform").ToLowerInvariant(), "\\)");
      Transform transform = new Transform(strArray.Length);
      foreach (string transformationFunction in strArray)
        transform.AddSingleTransform(TransformationApplierUtil.ParseSingleFunction(transformationFunction));
      element.SetProperty(53, (object) transform);
    }

    private static Transform.SingleTransform ParseSingleFunction(string transformationFunction)
    {
      if ("none".Equals(transformationFunction))
        return TransformationApplierUtil.GetSingleTransform(1f, 0.0f, 0.0f, 1f, 0.0f, 0.0f);
      string str1 = transformationFunction.JSubstring(0, transformationFunction.IndexOf('(')).Trim();
      string str2 = transformationFunction.Substring(transformationFunction.IndexOf('(') + 1);
      if ("matrix".Equals(str1))
      {
        string[] strArray = StringUtil.Split(str2, ",");
        if (strArray.Length == 6)
        {
          float[] floats = new float[6];
          for (int index = 0; index < 6; ++index)
          {
            floats[index] = index == 4 || index == 5 ? CssDimensionParsingUtils.ParseAbsoluteLength(strArray[index].Trim()) : float.Parse(strArray[index].Trim(), (IFormatProvider) CultureInfo.InvariantCulture);
            if (index == 1 || index == 2 || index == 5)
              floats[index] *= -1f;
          }
          return TransformationApplierUtil.GetSingleTransform(floats);
        }
      }
      if ("translate".Equals(str1))
      {
        string[] strArray = StringUtil.Split(str2, ",");
        bool yPoint = true;
        float ty = 0.0f;
        bool xPoint = strArray[0].IndexOf('%') < 0;
        float tx = xPoint ? CssDimensionParsingUtils.ParseAbsoluteLength(strArray[0].Trim()) : float.Parse(strArray[0].Trim().JSubstring(0, strArray[0].IndexOf('%')), (IFormatProvider) CultureInfo.InvariantCulture);
        if (strArray.Length == 2)
        {
          yPoint = strArray[1].IndexOf('%') < 0;
          ty = (float) (-1.0 * (yPoint ? (double) CssDimensionParsingUtils.ParseAbsoluteLength(strArray[1].Trim()) : (double) float.Parse(strArray[1].Trim().JSubstring(0, strArray[1].IndexOf('%')), (IFormatProvider) CultureInfo.InvariantCulture)));
        }
        return TransformationApplierUtil.GetSingleTransformTranslate(1f, 0.0f, 0.0f, 1f, tx, ty, xPoint, yPoint);
      }
      if ("translatex".Equals(str1))
      {
        bool xPoint = str2.IndexOf('%') < 0;
        return TransformationApplierUtil.GetSingleTransformTranslate(1f, 0.0f, 0.0f, 1f, xPoint ? CssDimensionParsingUtils.ParseAbsoluteLength(str2.Trim()) : float.Parse(str2.Trim().JSubstring(0, str2.IndexOf('%')), (IFormatProvider) CultureInfo.InvariantCulture), 0.0f, xPoint, true);
      }
      if ("translatey".Equals(str1))
      {
        bool yPoint = str2.IndexOf('%') < 0;
        return TransformationApplierUtil.GetSingleTransformTranslate(1f, 0.0f, 0.0f, 1f, 0.0f, (float) (-1.0 * (yPoint ? (double) CssDimensionParsingUtils.ParseAbsoluteLength(str2.Trim()) : (double) float.Parse(str2.Trim().JSubstring(0, str2.IndexOf('%')), (IFormatProvider) CultureInfo.InvariantCulture))), true, yPoint);
      }
      if ("rotate".Equals(str1))
      {
        double angleToRadians = TransformationApplierUtil.ParseAngleToRadians(str2);
        float num = (float) Math.Cos(angleToRadians);
        float b = (float) Math.Sin(angleToRadians);
        return TransformationApplierUtil.GetSingleTransform(num, b, -1f * b, num, 0.0f, 0.0f);
      }
      if ("skew".Equals(str1))
      {
        string[] strArray = StringUtil.Split(str2, ",");
        double angleToRadians = TransformationApplierUtil.ParseAngleToRadians(strArray[0]);
        double a = strArray.Length == 2 ? TransformationApplierUtil.ParseAngleToRadians(strArray[1]) : 0.0;
        float c = (float) Math.Tan(angleToRadians);
        return TransformationApplierUtil.GetSingleTransform(1f, (float) Math.Tan(a), c, 1f, 0.0f, 0.0f);
      }
      if ("skewx".Equals(str1))
        return TransformationApplierUtil.GetSingleTransform(1f, 0.0f, (float) Math.Tan(TransformationApplierUtil.ParseAngleToRadians(str2)), 1f, 0.0f, 0.0f);
      if ("skewy".Equals(str1))
        return TransformationApplierUtil.GetSingleTransform(1f, (float) Math.Tan(TransformationApplierUtil.ParseAngleToRadians(str2)), 0.0f, 1f, 0.0f, 0.0f);
      if ("scale".Equals(str1))
      {
        string[] strArray = StringUtil.Split(str2, ",");
        float a;
        float d;
        if (strArray.Length == 2)
        {
          a = float.Parse(strArray[0].Trim(), (IFormatProvider) CultureInfo.InvariantCulture);
          d = float.Parse(strArray[1].Trim(), (IFormatProvider) CultureInfo.InvariantCulture);
        }
        else
        {
          a = float.Parse(strArray[0].Trim(), (IFormatProvider) CultureInfo.InvariantCulture);
          d = a;
        }
        return TransformationApplierUtil.GetSingleTransform(a, 0.0f, 0.0f, d, 0.0f, 0.0f);
      }
      if ("scalex".Equals(str1))
        return TransformationApplierUtil.GetSingleTransform(float.Parse(str2.Trim(), (IFormatProvider) CultureInfo.InvariantCulture), 0.0f, 0.0f, 1f, 0.0f, 0.0f);
      return "scaley".Equals(str1) ? TransformationApplierUtil.GetSingleTransform(1f, 0.0f, 0.0f, float.Parse(str2.Trim(), (IFormatProvider) CultureInfo.InvariantCulture), 0.0f, 0.0f) : new Transform.SingleTransform();
    }

    private static double ParseAngleToRadians(string value)
    {
      if (value.IndexOf('d') < 0)
        return 0.0;
      return value.IndexOf('r') > 0 ? -1.0 * double.Parse(value.Trim().JSubstring(0, value.IndexOf('r')), (IFormatProvider) CultureInfo.InvariantCulture) : MathUtil.ToRadians(-1.0 * double.Parse(value.Trim().JSubstring(0, value.IndexOf('d')), (IFormatProvider) CultureInfo.InvariantCulture));
    }

    private static Transform.SingleTransform GetSingleTransformTranslate(
      float a,
      float b,
      float c,
      float d,
      float tx,
      float ty,
      bool xPoint,
      bool yPoint)
    {
      return new Transform.SingleTransform(a, b, c, d, new UnitValue(xPoint ? 1 : 2, tx), new UnitValue(yPoint ? 1 : 2, ty));
    }

    private static Transform.SingleTransform GetSingleTransform(
      float a,
      float b,
      float c,
      float d,
      float tx,
      float ty)
    {
      return new Transform.SingleTransform(a, b, c, d, new UnitValue(1, tx), new UnitValue(1, ty));
    }

    private static Transform.SingleTransform GetSingleTransform(float[] floats)
    {
      return new Transform.SingleTransform(floats[0], floats[1], floats[2], floats[3], new UnitValue(1, floats[4]), new UnitValue(1, floats[5]));
    }
  }
}
