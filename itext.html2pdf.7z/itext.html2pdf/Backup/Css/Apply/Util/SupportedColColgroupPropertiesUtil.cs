﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.SupportedColColgroupPropertiesUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class SupportedColColgroupPropertiesUtil
  {
    private static readonly ICollection<string> CELL_CSS_PROPERTIES = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[9]
    {
      "background-color",
      "background-image",
      "background-position-x",
      "background-position-y",
      "background-size",
      "background-repeat",
      "background-origin",
      "background-clip",
      "background-attachment"
    })));
    private static readonly ICollection<string> OWN_CSS_PROPERTIES = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[13]
    {
      "border-bottom-color",
      "border-bottom-style",
      "border-bottom-width",
      "border-left-color",
      "border-left-style",
      "border-left-width",
      "border-right-color",
      "border-right-style",
      "border-right-width",
      "border-top-color",
      "border-top-style",
      "border-top-width",
      "visibility"
    })));

    public static UnitValue GetWidth(
      IDictionary<string, string> resolvedCssProps,
      ProcessorContext context)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(resolvedCssProps.Get<string, string>("font-size"));
      string str = resolvedCssProps.Get<string, string>("width");
      return str == null ? (UnitValue) null : CssDimensionParsingUtils.ParseLengthValueToPt(str, absoluteLength, context.GetCssContext().GetRootFontSize());
    }

    public static IDictionary<string, string> GetCellProperties(
      IDictionary<string, string> resolvedCssProps)
    {
      return SupportedColColgroupPropertiesUtil.GetFilteredMap(resolvedCssProps, SupportedColColgroupPropertiesUtil.CELL_CSS_PROPERTIES);
    }

    public static IDictionary<string, string> GetOwnProperties(
      IDictionary<string, string> resolvedCssProps)
    {
      return SupportedColColgroupPropertiesUtil.GetFilteredMap(resolvedCssProps, SupportedColColgroupPropertiesUtil.OWN_CSS_PROPERTIES);
    }

    private static IDictionary<string, string> GetFilteredMap(
      IDictionary<string, string> map,
      ICollection<string> supportedKeys)
    {
      IDictionary<string, string> col = (IDictionary<string, string>) new Dictionary<string, string>();
      if (map != null)
      {
        foreach (string supportedKey in (IEnumerable<string>) supportedKeys)
        {
          string str = map.Get<string, string>(supportedKey);
          if (str != null)
            col.Put<string, string>(supportedKey, str);
        }
      }
      return col.Count <= 0 ? (IDictionary<string, string>) null : col;
    }
  }
}
