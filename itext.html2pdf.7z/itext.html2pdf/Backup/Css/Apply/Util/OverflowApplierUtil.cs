﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.OverflowApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class OverflowApplierUtil
  {
    private OverflowApplierUtil()
    {
    }

    public static void ApplyOverflow(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      string str1 = cssProps == null || !CssConstants.OVERFLOW_VALUES.Contains(cssProps.Get<string, string>("overflow")) ? (string) null : cssProps.Get<string, string>("overflow");
      string str2 = cssProps == null || !CssConstants.OVERFLOW_VALUES.Contains(cssProps.Get<string, string>("overflow-x")) ? str1 : cssProps.Get<string, string>("overflow-x");
      if ("hidden".Equals(str2) || "auto".Equals(str2) || "scroll".Equals(str2))
        element.SetProperty(103, (object) OverflowPropertyValue.HIDDEN);
      else
        element.SetProperty(103, (object) OverflowPropertyValue.VISIBLE);
      string str3 = cssProps == null || !CssConstants.OVERFLOW_VALUES.Contains(cssProps.Get<string, string>("overflow-y")) ? str1 : cssProps.Get<string, string>("overflow-y");
      if ("hidden".Equals(str3) || "auto".Equals(str3) || "scroll".Equals(str3))
        element.SetProperty(104, (object) OverflowPropertyValue.HIDDEN);
      else
        element.SetProperty(104, (object) OverflowPropertyValue.VISIBLE);
    }
  }
}
