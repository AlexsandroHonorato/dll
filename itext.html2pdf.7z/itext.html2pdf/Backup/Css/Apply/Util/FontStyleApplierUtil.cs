﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.FontStyleApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Properties;
using iText.Layout.Splitting;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class FontStyleApplierUtil
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (FontStyleApplierUtil));
    private const float DEFAULT_LINE_HEIGHT = 1.2f;
    private const float TEXT_DECORATION_LINE_DEFAULT_THICKNESS = 0.75f;
    private const float TEXT_DECORATION_LINE_THROUGH_Y_POS = 0.25f;
    private const float TEXT_DECORATION_LINE_OVER_Y_POS = 0.9f;
    private const float TEXT_DECORATION_LIN_UNDER_Y_POS = -0.1f;

    private FontStyleApplierUtil()
    {
    }

    public static void ApplyFontStyles(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IStylesContainer stylesContainer,
      IPropertyContainer element)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      if ((double) absoluteLength != 0.0)
        element.SetProperty(24, (object) UnitValue.CreatePointValue(absoluteLength));
      if (cssProps.Get<string, string>("font-family") != null)
      {
        IList<string> col = FontFamilySplitterUtil.SplitFontFamily(cssProps.Get<string, string>("font-family"));
        element.SetProperty(20, (object) col.ToArray<string>(new string[col.Count]));
      }
      if (cssProps.Get<string, string>("font-weight") != null)
        element.SetProperty(95, (object) cssProps.Get<string, string>("font-weight"));
      if (cssProps.Get<string, string>("font-style") != null)
        element.SetProperty(94, (object) cssProps.Get<string, string>("font-style"));
      string str1 = cssProps.Get<string, string>("color");
      if (str1 != null)
      {
        TransparentColor transparentColor;
        if (!"transparent".Equals(str1))
        {
          TransparentColor color = CssDimensionParsingUtils.ParseColor(str1);
          transparentColor = new TransparentColor(color.GetColor(), color.GetOpacity());
        }
        else
          transparentColor = new TransparentColor(ColorConstants.BLACK, 0.0f);
        element.SetProperty(21, (object) transparentColor);
      }
      string str2 = cssProps.Get<string, string>("direction");
      if ("rtl".Equals(str2))
      {
        element.SetProperty(7, (object) BaseDirection.RIGHT_TO_LEFT);
        if (!"list-item".Equals(cssProps.Get<string, string>("display")))
          element.SetProperty(70, (object) TextAlignment.RIGHT);
      }
      else if ("ltr".Equals(str2))
      {
        element.SetProperty(7, (object) BaseDirection.LEFT_TO_RIGHT);
        if (!"list-item".Equals(cssProps.Get<string, string>("display")))
          element.SetProperty(70, (object) TextAlignment.LEFT);
      }
      if (stylesContainer is IElementNode && ((INode) stylesContainer).ParentNode() is IElementNode && "rtl".Equals(((IStylesContainer) ((INode) stylesContainer).ParentNode()).GetStyles().Get<string, string>("direction")) && !element.HasProperty(28))
        element.SetProperty(28, (object) HorizontalAlignment.RIGHT);
      string str3 = cssProps.Get<string, string>("text-align");
      if ("left".Equals(str3))
        element.SetProperty(70, (object) TextAlignment.LEFT);
      else if ("right".Equals(str3))
        element.SetProperty(70, (object) TextAlignment.RIGHT);
      else if ("center".Equals(str3))
        element.SetProperty(70, (object) TextAlignment.CENTER);
      else if ("justify".Equals(str3))
      {
        element.SetProperty(70, (object) TextAlignment.JUSTIFIED);
        element.SetProperty(61, (object) 1f);
      }
      string str4 = cssProps.Get<string, string>("white-space");
      bool flag = "nowrap".Equals(str4) || "pre".Equals(str4);
      element.SetProperty(118, (object) flag);
      if (!flag)
      {
        string str5 = cssProps.Get<string, string>("overflow-wrap");
        if ("anywhere".Equals(str5))
          element.SetProperty(102, (object) OverflowWrapPropertyValue.ANYWHERE);
        else if ("break-word".Equals(str5))
          element.SetProperty(102, (object) OverflowWrapPropertyValue.BREAK_WORD);
        else
          element.SetProperty(102, (object) OverflowWrapPropertyValue.NORMAL);
        string str6 = cssProps.Get<string, string>("word-break");
        if ("break-all".Equals(str6))
          element.SetProperty(62, (object) new BreakAllSplitCharacters());
        else if ("keep-all".Equals(str6))
          element.SetProperty(62, (object) new KeepAllSplitCharacters());
        else if ("break-word".Equals(str6))
        {
          element.SetProperty(102, (object) OverflowWrapPropertyValue.ANYWHERE);
          element.SetProperty(62, (object) new DefaultSplitCharacters());
        }
        else
          element.SetProperty(62, (object) new DefaultSplitCharacters());
      }
      FontStyleApplierUtil.SetTextDecoration(element, cssProps);
      string str7 = cssProps.Get<string, string>("text-indent");
      if (str7 != null)
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str7, absoluteLength, rootFontSize);
        if (lengthValueToPt != null)
        {
          if (lengthValueToPt.IsPointValue())
            element.SetProperty(18, (object) lengthValueToPt.GetValue());
          else
            LoggerExtensions.LogError(FontStyleApplierUtil.logger, MessageFormatUtil.Format("Css property {0} in percents is not supported", new object[1]
            {
              (object) "text-indent"
            }), Array.Empty<object>());
        }
      }
      string str8 = cssProps.Get<string, string>("letter-spacing");
      if (str8 != null && !"normal".Equals(str8))
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str8, absoluteLength, rootFontSize);
        if (lengthValueToPt.IsPointValue())
          element.SetProperty(15, (object) lengthValueToPt.GetValue());
      }
      string str9 = cssProps.Get<string, string>("word-spacing");
      if (str9 != null)
      {
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str9, absoluteLength, rootFontSize);
        if (lengthValueToPt != null && lengthValueToPt.IsPointValue())
          element.SetProperty(78, (object) lengthValueToPt.GetValue());
      }
      string lineHeight = cssProps.Get<string, string>("line-height");
      FontStyleApplierUtil.SetLineHeight(element, lineHeight, absoluteLength, rootFontSize);
      FontStyleApplierUtil.SetLineHeightByLeading(element, lineHeight, absoluteLength, rootFontSize);
    }

    private static void SetTextDecoration(
      IPropertyContainer element,
      IDictionary<string, string> cssProps)
    {
      string[] strArray1 = new string[1];
      string str1 = cssProps.Get<string, string>("text-decoration-color");
      if (str1 != null && !string.IsNullOrEmpty(str1.Trim()))
        strArray1 = StringUtil.Split(cssProps.Get<string, string>("text-decoration-color"), "\\s+");
      IList<float> floatList = (IList<float>) new List<float>(strArray1.Length);
      IList<Color> colorList = (IList<Color>) new List<Color>(strArray1.Length);
      foreach (string str2 in strArray1)
      {
        float num = 1f;
        Color color1;
        if (str2 == null || "currentcolor".Equals(str2))
        {
          if (element.GetProperty<TransparentColor>(21) != null)
          {
            TransparentColor property = element.GetProperty<TransparentColor>(21);
            color1 = property.GetColor();
            num = property.GetOpacity();
          }
          else
            color1 = ColorConstants.BLACK;
        }
        else if (str2.StartsWith("hsl"))
        {
          LoggerExtensions.LogError(FontStyleApplierUtil.logger, "Hsl colors are not supported", Array.Empty<object>());
          color1 = ColorConstants.BLACK;
        }
        else
        {
          TransparentColor color2 = CssDimensionParsingUtils.ParseColor(str2);
          color1 = color2.GetColor();
          num = color2.GetOpacity();
        }
        floatList.Add(num);
        colorList.Add(color1);
      }
      string str3 = cssProps.Get<string, string>("text-decoration-line");
      if (str3 == null)
        return;
      string[] strArray2 = StringUtil.Split(str3, "\\s+");
      IList<Underline> underlineList = (IList<Underline>) new List<Underline>();
      for (int index = 0; index < strArray2.Length; ++index)
      {
        float opacity = floatList.Count - 1 > index ? floatList[index] : floatList[floatList.Count - 1];
        Color color = colorList.Count - 1 > index ? colorList[index] : colorList[colorList.Count - 1];
        string str4 = strArray2[index];
        if ("blink".Equals(str4))
          LoggerExtensions.LogError(FontStyleApplierUtil.logger, "text-decoration: blink not supported", Array.Empty<object>());
        else if ("line-through".Equals(str4))
          underlineList.Add(new Underline(color, opacity, 0.75f, 0.0f, 0.0f, 0.25f, 0));
        else if ("overline".Equals(str4))
          underlineList.Add(new Underline(color, opacity, 0.75f, 0.0f, 0.0f, 0.9f, 0));
        else if ("underline".Equals(str4))
          underlineList.Add(new Underline(color, opacity, 0.75f, 0.0f, 0.0f, -0.1f, 0));
        else if ("none".Equals(str4))
        {
          underlineList = (IList<Underline>) null;
          break;
        }
      }
      element.SetProperty(74, (object) underlineList);
    }

    private static void SetLineHeight(
      IPropertyContainer elementToSet,
      string lineHeight,
      float em,
      float rem)
    {
      if (lineHeight != null && !"normal".Equals(lineHeight) && !"auto".Equals(lineHeight))
      {
        if (CssTypesValidationUtils.IsNumber(lineHeight))
        {
          float? nullable = CssDimensionParsingUtils.ParseFloat(lineHeight);
          if (nullable.HasValue)
            elementToSet.SetProperty(124, (object) LineHeight.CreateMultipliedValue(nullable.Value));
          else
            elementToSet.SetProperty(124, (object) LineHeight.CreateNormalValue());
        }
        else
        {
          UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(lineHeight, em, rem);
          if (lengthValueToPt != null && lengthValueToPt.IsPointValue())
            elementToSet.SetProperty(124, (object) LineHeight.CreateFixedValue(lengthValueToPt.GetValue()));
          else if (lengthValueToPt != null)
            elementToSet.SetProperty(124, (object) LineHeight.CreateMultipliedValue(lengthValueToPt.GetValue() / 100f));
          else
            elementToSet.SetProperty(124, (object) LineHeight.CreateNormalValue());
        }
      }
      else
        elementToSet.SetProperty(124, (object) LineHeight.CreateNormalValue());
    }

    private static void SetLineHeightByLeading(
      IPropertyContainer element,
      string lineHeight,
      float em,
      float rem)
    {
      if (lineHeight != null && !"normal".Equals(lineHeight) && !"auto".Equals(lineHeight))
      {
        if (CssTypesValidationUtils.IsNumber(lineHeight))
        {
          float? nullable = CssDimensionParsingUtils.ParseFloat(lineHeight);
          if (!nullable.HasValue)
            return;
          element.SetProperty(33, (object) new Leading(2, nullable.Value));
        }
        else
        {
          UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(lineHeight, em, rem);
          if (lengthValueToPt != null && lengthValueToPt.IsPointValue())
          {
            element.SetProperty(33, (object) new Leading(1, lengthValueToPt.GetValue()));
          }
          else
          {
            if (lengthValueToPt == null)
              return;
            element.SetProperty(33, (object) new Leading(2, lengthValueToPt.GetValue() / 100f));
          }
        }
      }
      else
        element.SetProperty(33, (object) new Leading(2, 1.2f));
    }
  }
}
