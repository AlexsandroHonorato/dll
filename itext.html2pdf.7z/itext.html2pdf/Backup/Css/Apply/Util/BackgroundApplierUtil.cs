﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.BackgroundApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Kernel.Colors.Gradients;
using iText.Kernel.Pdf.Xobject;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Exceptions;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class BackgroundApplierUtil
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (BackgroundApplierUtil));

    private BackgroundApplierUtil()
    {
    }

    public static void ApplyBackground(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string backgroundColorStr = cssProps.Get<string, string>("background-color");
      string str1 = cssProps.Get<string, string>("background-image");
      string str2 = cssProps.Get<string, string>("background-repeat");
      string str3 = cssProps.Get<string, string>("background-size");
      string str4 = cssProps.Get<string, string>("background-position-x");
      string str5 = cssProps.Get<string, string>("background-position-y");
      string str6 = cssProps.Get<string, string>("background-blend-mode");
      string str7 = cssProps.Get<string, string>("background-clip");
      string str8 = cssProps.Get<string, string>("background-origin");
      IList<string> stringList1 = CssUtils.SplitStringWithComma(str1);
      IList<string> backgroundRepeatArray = CssUtils.SplitStringWithComma(str2);
      IList<IList<string>> shorthandProperties = str3 == null ? (IList<IList<string>>) null : CssUtils.ExtractShorthandProperties(str3);
      IList<string> backgroundPositionXArray = CssUtils.SplitStringWithComma(str4);
      IList<string> backgroundPositionYArray = CssUtils.SplitStringWithComma(str5);
      IList<string> backgroundBlendModeArray = CssUtils.SplitStringWithComma(str6);
      string str9 = cssProps.Get<string, string>("font-size");
      float em = str9 == null ? 0.0f : CssDimensionParsingUtils.ParseAbsoluteLength(str9);
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      IList<string> stringList2 = CssUtils.SplitStringWithComma(str7);
      IList<string> backgroundOriginArray = CssUtils.SplitStringWithComma(str8);
      BackgroundBox backgroundBoxProperty = BackgroundApplierUtil.GetBackgroundBoxProperty(stringList2, stringList1.IsEmpty<string>() ? 0 : stringList1.Count - 1, BackgroundBox.BORDER_BOX);
      IPropertyContainer element1 = element;
      int clip = (int) backgroundBoxProperty;
      BackgroundApplierUtil.ApplyBackgroundColor(backgroundColorStr, element1, (BackgroundBox) clip);
      IList<BackgroundImage> backgroundImagesList = BackgroundApplierUtil.GetBackgroundImagesList(stringList1, context, em, rootFontSize, backgroundPositionXArray, backgroundPositionYArray, shorthandProperties, backgroundBlendModeArray, backgroundRepeatArray, stringList2, backgroundOriginArray);
      if (backgroundImagesList.IsEmpty<BackgroundImage>())
        return;
      element.SetProperty(90, (object) backgroundImagesList);
    }

    private static IList<BackgroundImage> GetBackgroundImagesList(
      IList<string> backgroundImagesArray,
      ProcessorContext context,
      float em,
      float rem,
      IList<string> backgroundPositionXArray,
      IList<string> backgroundPositionYArray,
      IList<IList<string>> backgroundSizeArray,
      IList<string> backgroundBlendModeArray,
      IList<string> backgroundRepeatArray,
      IList<string> backgroundClipArray,
      IList<string> backgroundOriginArray)
    {
      IList<BackgroundImage> backgroundImagesList = (IList<BackgroundImage>) new List<BackgroundImage>();
      for (int index = 0; index < backgroundImagesArray.Count; ++index)
      {
        string backgroundImages = backgroundImagesArray[index];
        if (backgroundImages != null && !"none".Equals(backgroundImages))
        {
          BackgroundPosition position = BackgroundApplierUtil.ApplyBackgroundPosition(backgroundPositionXArray, backgroundPositionYArray, index, em, rem);
          BlendMode blendMode = BackgroundApplierUtil.ApplyBackgroundBlendMode(backgroundBlendModeArray, index);
          BackgroundRepeat repeat = BackgroundApplierUtil.ApplyBackgroundRepeat(backgroundRepeatArray, index);
          BackgroundBox backgroundBoxProperty1 = BackgroundApplierUtil.GetBackgroundBoxProperty(backgroundClipArray, index, BackgroundBox.BORDER_BOX);
          BackgroundBox backgroundBoxProperty2 = BackgroundApplierUtil.GetBackgroundBoxProperty(backgroundOriginArray, index, BackgroundBox.PADDING_BOX);
          if (!CssGradientUtil.IsCssLinearGradientValue(backgroundImages) ? BackgroundApplierUtil.ApplyBackgroundImage(context.GetResourceResolver().RetrieveImage(CssUtils.ExtractUrl(backgroundImages)), backgroundImagesList, repeat, blendMode, position, backgroundBoxProperty1, backgroundBoxProperty2) : BackgroundApplierUtil.ApplyLinearGradient(backgroundImages, backgroundImagesList, blendMode, position, em, rem, repeat, backgroundBoxProperty1, backgroundBoxProperty2))
            BackgroundApplierUtil.ApplyBackgroundSize(backgroundSizeArray, em, rem, index, backgroundImagesList[backgroundImagesList.Count - 1]);
        }
      }
      return backgroundImagesList;
    }

    private static BackgroundBox GetBackgroundBoxProperty(
      IList<string> propertyArray,
      int iteration,
      BackgroundBox defaultValue)
    {
      int sidePropertyIndex = BackgroundApplierUtil.GetBackgroundSidePropertyIndex(propertyArray.Count, iteration);
      return sidePropertyIndex == -1 ? defaultValue : BackgroundApplierUtil.GetBackgroundBoxPropertyByString(propertyArray[sidePropertyIndex]);
    }

    private static BackgroundBox GetBackgroundBoxPropertyByString(string box)
    {
      if ("padding-box".Equals(box))
        return BackgroundBox.PADDING_BOX;
      return "content-box".Equals(box) ? BackgroundBox.CONTENT_BOX : BackgroundBox.BORDER_BOX;
    }

    private static BlendMode ApplyBackgroundBlendMode(
      IList<string> backgroundBlendModeArray,
      int iteration)
    {
      string str = (string) null;
      if (backgroundBlendModeArray != null && !backgroundBlendModeArray.IsEmpty<string>())
      {
        int index = Math.Min(iteration, backgroundBlendModeArray.Count - 1);
        str = backgroundBlendModeArray[index];
      }
      return CssUtils.ParseBlendMode(str);
    }

    private static BackgroundPosition ApplyBackgroundPosition(
      IList<string> backgroundPositionXArray,
      IList<string> backgroundPositionYArray,
      int i,
      float em,
      float rem)
    {
      BackgroundPosition position = new BackgroundPosition();
      int sidePropertyIndex1 = BackgroundApplierUtil.GetBackgroundSidePropertyIndex(backgroundPositionXArray.Count, i);
      if (sidePropertyIndex1 != -1)
        BackgroundApplierUtil.ApplyBackgroundPositionX(position, backgroundPositionXArray[sidePropertyIndex1], em, rem);
      int sidePropertyIndex2 = BackgroundApplierUtil.GetBackgroundSidePropertyIndex(backgroundPositionYArray.Count, i);
      if (sidePropertyIndex2 != -1)
        BackgroundApplierUtil.ApplyBackgroundPositionY(position, backgroundPositionYArray[sidePropertyIndex2], em, rem);
      return position;
    }

    private static void ApplyBackgroundPositionX(
      BackgroundPosition position,
      string xPosition,
      float em,
      float rem)
    {
      foreach (string str in StringUtil.Split(xPosition, " "))
      {
        switch (str)
        {
          case "left":
            position.SetPositionX(BackgroundPosition.PositionX.LEFT);
            break;
          case "right":
            position.SetPositionX(BackgroundPosition.PositionX.RIGHT);
            break;
          case "center":
            position.SetPositionX(BackgroundPosition.PositionX.CENTER);
            break;
          default:
            UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str, em, rem);
            if (lengthValueToPt != null)
            {
              position.SetXShift(lengthValueToPt);
              break;
            }
            break;
        }
      }
    }

    private static void ApplyBackgroundPositionY(
      BackgroundPosition position,
      string yPosition,
      float em,
      float rem)
    {
      foreach (string str in StringUtil.Split(yPosition, " "))
      {
        switch (str)
        {
          case "top":
            position.SetPositionY(BackgroundPosition.PositionY.TOP);
            break;
          case "bottom":
            position.SetPositionY(BackgroundPosition.PositionY.BOTTOM);
            break;
          case "center":
            position.SetPositionY(BackgroundPosition.PositionY.CENTER);
            break;
          default:
            UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str, em, rem);
            if (lengthValueToPt != null)
            {
              position.SetYShift(lengthValueToPt);
              break;
            }
            break;
        }
      }
    }

    private static BackgroundRepeat ApplyBackgroundRepeat(
      IList<string> backgroundRepeatArray,
      int iteration)
    {
      int sidePropertyIndex = BackgroundApplierUtil.GetBackgroundSidePropertyIndex(backgroundRepeatArray.Count, iteration);
      if (sidePropertyIndex != -1)
      {
        string[] strArray = StringUtil.Split(backgroundRepeatArray[sidePropertyIndex], " ");
        if (strArray.Length == 1)
        {
          if ("repeat-x".Equals(strArray[0]))
            return new BackgroundRepeat(BackgroundRepeat.BackgroundRepeatValue.REPEAT, BackgroundRepeat.BackgroundRepeatValue.NO_REPEAT);
          return "repeat-y".Equals(strArray[0]) ? new BackgroundRepeat(BackgroundRepeat.BackgroundRepeatValue.NO_REPEAT, BackgroundRepeat.BackgroundRepeatValue.REPEAT) : new BackgroundRepeat(CssBackgroundUtils.ParseBackgroundRepeat(strArray[0]));
        }
        if (strArray.Length == 2)
          return new BackgroundRepeat(CssBackgroundUtils.ParseBackgroundRepeat(strArray[0]), CssBackgroundUtils.ParseBackgroundRepeat(strArray[1]));
      }
      return new BackgroundRepeat();
    }

    private static int GetBackgroundSidePropertyIndex(int propertiesNumber, int iteration)
    {
      return propertiesNumber > 0 ? iteration % propertiesNumber : -1;
    }

    private static void ApplyBackgroundColor(
      string backgroundColorStr,
      IPropertyContainer element,
      BackgroundBox clip)
    {
      if (backgroundColorStr == null || "transparent".Equals(backgroundColorStr))
        return;
      TransparentColor color = CssDimensionParsingUtils.ParseColor(backgroundColorStr);
      Background background = new Background(color.GetColor(), color.GetOpacity(), clip);
      element.SetProperty(6, (object) background);
    }

    private static bool ApplyBackgroundImage(
      PdfXObject image,
      IList<BackgroundImage> backgroundImagesList,
      BackgroundRepeat repeat,
      BlendMode backgroundBlendMode,
      BackgroundPosition position,
      BackgroundBox clip,
      BackgroundBox origin)
    {
      switch (image)
      {
        case null:
          return false;
        case PdfImageXObject _:
          backgroundImagesList.Add((BackgroundImage) new BackgroundApplierUtil.HtmlBackgroundImage((PdfImageXObject) image, repeat, position, backgroundBlendMode, clip, origin));
          return true;
        case PdfFormXObject _:
          backgroundImagesList.Add((BackgroundImage) new BackgroundApplierUtil.HtmlBackgroundImage((PdfFormXObject) image, repeat, position, backgroundBlendMode, clip, origin));
          return true;
        default:
          throw new InvalidOperationException();
      }
    }

    private static bool ApplyLinearGradient(
      string image,
      IList<BackgroundImage> backgroundImagesList,
      BlendMode blendMode,
      BackgroundPosition position,
      float em,
      float rem,
      BackgroundRepeat repeat,
      BackgroundBox clip,
      BackgroundBox origin)
    {
      try
      {
        StrategyBasedLinearGradientBuilder cssLinearGradient = CssGradientUtil.ParseCssLinearGradient(image, em, rem);
        if (cssLinearGradient != null)
        {
          backgroundImagesList.Add(new BackgroundImage.Builder().SetLinearGradientBuilder((AbstractLinearGradientBuilder) cssLinearGradient).SetBackgroundBlendMode(blendMode).SetBackgroundPosition(position).SetBackgroundRepeat(repeat).SetBackgroundClip(clip).SetBackgroundOrigin(origin).Build());
          return true;
        }
      }
      catch (StyledXMLParserException ex)
      {
        LoggerExtensions.LogWarning(BackgroundApplierUtil.LOGGER, MessageFormatUtil.Format("Invalid gradient declaration: {0}", new object[1]
        {
          (object) image
        }), Array.Empty<object>());
      }
      return false;
    }

    private static void ApplyBackgroundSize(
      IList<IList<string>> backgroundProperties,
      float em,
      float rem,
      int imageIndex,
      BackgroundImage image)
    {
      if (backgroundProperties == null || backgroundProperties.IsEmpty<IList<string>>() || image.GetForm() != null && ((double) image.GetImageHeight() == 0.0 || (double) image.GetImageWidth() == 0.0))
        return;
      IList<string> backgroundProperty = backgroundProperties[BackgroundApplierUtil.GetBackgroundSidePropertyIndex(backgroundProperties.Count, imageIndex)];
      if (backgroundProperty.Count == 2 && "auto".Equals(backgroundProperty[1]))
        backgroundProperty.JRemoveAt<string>(1);
      if (backgroundProperty.Count == 1)
        BackgroundApplierUtil.ApplyBackgroundWidth(backgroundProperty[0], image, em, rem);
      if (backgroundProperty.Count != 2)
        return;
      BackgroundApplierUtil.ApplyBackgroundWidthHeight(backgroundProperty, image, em, rem);
    }

    private static void ApplyBackgroundWidth(
      string widthValue,
      BackgroundImage image,
      float em,
      float rem)
    {
      if (CommonCssConstants.BACKGROUND_SIZE_VALUES.Contains(widthValue))
      {
        if (widthValue.Equals("contain"))
          image.GetBackgroundSize().SetBackgroundSizeToContain();
        if (!widthValue.Equals("cover"))
          return;
        image.GetBackgroundSize().SetBackgroundSizeToCover();
      }
      else
        image.GetBackgroundSize().SetBackgroundSizeToValues(CssDimensionParsingUtils.ParseLengthValueToPt(widthValue, em, rem), (UnitValue) null);
    }

    private static void ApplyBackgroundWidthHeight(
      IList<string> backgroundSizeValues,
      BackgroundImage image,
      float em,
      float rem)
    {
      string backgroundSizeValue = backgroundSizeValues[0];
      if (CommonCssConstants.BACKGROUND_SIZE_VALUES.Contains(backgroundSizeValue))
      {
        if (!backgroundSizeValue.Equals("auto"))
          return;
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(backgroundSizeValues[1], em, rem);
        if (lengthValueToPt == null)
          return;
        image.GetBackgroundSize().SetBackgroundSizeToValues((UnitValue) null, lengthValueToPt);
      }
      else
        image.GetBackgroundSize().SetBackgroundSizeToValues(CssDimensionParsingUtils.ParseLengthValueToPt(backgroundSizeValues[0], em, rem), CssDimensionParsingUtils.ParseLengthValueToPt(backgroundSizeValues[1], em, rem));
    }

    private class HtmlBackgroundImage : BackgroundImage
    {
      private const double PX_TO_PT_MULTIPLIER = 0.75;
      private double dimensionMultiplier = 1.0;

      public HtmlBackgroundImage(
        PdfImageXObject xObject,
        BackgroundRepeat repeat,
        BackgroundPosition position,
        BlendMode blendMode,
        BackgroundBox clip,
        BackgroundBox origin)
        : base(new BackgroundImage.Builder().SetImage((PdfXObject) xObject).SetBackgroundRepeat(repeat).SetBackgroundPosition(position).SetBackgroundBlendMode(blendMode).SetBackgroundClip(clip).SetBackgroundOrigin(origin).Build())
      {
        this.dimensionMultiplier = 0.75;
      }

      public HtmlBackgroundImage(
        PdfFormXObject xObject,
        BackgroundRepeat repeat,
        BackgroundPosition position,
        BlendMode blendMode,
        BackgroundBox clip,
        BackgroundBox origin)
        : base(new BackgroundImage.Builder().SetImage((PdfXObject) xObject).SetBackgroundRepeat(repeat).SetBackgroundPosition(position).SetBackgroundBlendMode(blendMode).SetBackgroundClip(clip).SetBackgroundOrigin(origin).Build())
      {
      }

      public override float GetImageWidth()
      {
        return this.image.GetWidth() * (float) this.dimensionMultiplier;
      }

      public override float GetImageHeight()
      {
        return this.image.GetHeight() * (float) this.dimensionMultiplier;
      }
    }
  }
}
