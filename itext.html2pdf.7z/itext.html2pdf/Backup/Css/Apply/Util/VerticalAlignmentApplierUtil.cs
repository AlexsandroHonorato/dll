﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.VerticalAlignmentApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class VerticalAlignmentApplierUtil
  {
    private const double ASCENDER_COEFFICIENT = 0.8;
    private const double DESCENDER_COEFFICIENT = 0.2;

    private VerticalAlignmentApplierUtil()
    {
    }

    public static void ApplyVerticalAlignmentForCells(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("vertical-align");
      if (str == null)
        return;
      if ("middle".Equals(str))
      {
        element.SetProperty(75, (object) VerticalAlignment.MIDDLE);
      }
      else
      {
        if (!"bottom".Equals(str))
          return;
        element.SetProperty(75, (object) VerticalAlignment.BOTTOM);
      }
    }

    public static void ApplyVerticalAlignmentForBlocks(
      IDictionary<string, string> cssProps,
      IPropertyContainer element,
      bool isInlineTag)
    {
      string str1 = cssProps.Get<string, string>("display");
      if (!isInlineTag && !"inline-block".Equals(str1))
        return;
      string str2 = cssProps.Get<string, string>("vertical-align");
      if ("middle".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.MIDDLE)));
      else if ("bottom".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.BOTTOM)));
      else if ("top".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.TOP)));
      else if ("text-bottom".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.TEXT_BOTTOM)));
      else if ("text-top".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.TEXT_TOP)));
      else if ("super".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.SUPER)));
      else if ("sub".Equals(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.SUB)));
      else if (CssTypesValidationUtils.IsPercentageValue(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.FRACTION), CssDimensionParsingUtils.ParseRelativeValue(str2, 1f)));
      else if (CssTypesValidationUtils.IsValidNumericValue(str2))
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.FIXED), CssDimensionParsingUtils.ParseAbsoluteLength(str2)));
      else
        element.SetProperty(136, (object) new InlineVerticalAlignment(new InlineVerticalAlignmentType?(InlineVerticalAlignmentType.BASELINE)));
    }

    public static void ApplyVerticalAlignmentForInlines(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IStylesContainer stylesContainer,
      IList<IPropertyContainer> childElements)
    {
      string vAlignVal = cssProps.Get<string, string>("vertical-align");
      if (vAlignVal == null)
        return;
      float num1 = 0.0f;
      if ("sub".Equals(vAlignVal) || "super".Equals(vAlignVal))
        num1 = VerticalAlignmentApplierUtil.CalcTextRiseForSupSub(stylesContainer, vAlignVal);
      else if ("middle".Equals(vAlignVal))
        num1 = VerticalAlignmentApplierUtil.CalcTextRiseForMiddle(stylesContainer);
      else if ("text-top".Equals(vAlignVal))
        num1 = VerticalAlignmentApplierUtil.CalcTextRiseForTextTop(stylesContainer, context.GetCssContext().GetRootFontSize());
      else if ("text-bottom".Equals(vAlignVal))
        num1 = VerticalAlignmentApplierUtil.CalcTextRiseForTextBottom(stylesContainer, context.GetCssContext().GetRootFontSize());
      else if (CssTypesValidationUtils.IsMetricValue(vAlignVal))
        num1 = CssDimensionParsingUtils.ParseAbsoluteLength(vAlignVal);
      else if (vAlignVal.EndsWith("%"))
        num1 = VerticalAlignmentApplierUtil.CalcTextRiseForPercentageValue(stylesContainer, context.GetCssContext().GetRootFontSize(), vAlignVal);
      if ((double) num1 == 0.0)
        return;
      foreach (IPropertyContainer childElement in (IEnumerable<IPropertyContainer>) childElements)
      {
        if (childElement is Text)
        {
          float? nullable1 = childElement.GetProperty<float?>(72);
          if (nullable1.HasValue)
          {
            float? nullable2 = nullable1;
            float num2 = num1;
            nullable1 = nullable2.HasValue ? new float?(nullable2.GetValueOrDefault() + num2) : new float?();
          }
          else
            nullable1 = new float?(num1);
          childElement.SetProperty(72, (object) nullable1);
        }
        else if (childElement is IBlockElement)
          break;
      }
    }

    private static float CalcTextRiseForSupSub(IStylesContainer stylesContainer, string vAlignVal)
    {
      float parentFontSize = VerticalAlignmentApplierUtil.GetParentFontSize(stylesContainer);
      string str1 = "33%";
      string str2 = "-20%";
      return CssDimensionParsingUtils.ParseRelativeValue("super".Equals(vAlignVal) ? str1 : str2, parentFontSize);
    }

    private static float CalcTextRiseForMiddle(IStylesContainer stylesContainer)
    {
      double absoluteLength = (double) CssDimensionParsingUtils.ParseAbsoluteLength(stylesContainer.GetStyles().Get<string, string>("font-size"));
      float parentFontSize = VerticalAlignmentApplierUtil.GetParentFontSize(stylesContainer);
      double num1 = 0.3;
      float num2 = (float) (absoluteLength * num1);
      return parentFontSize / 4f - num2;
    }

    private static float CalcTextRiseForTextTop(
      IStylesContainer stylesContainer,
      float rootFontSize)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(stylesContainer.GetStyles().Get<string, string>("font-size"));
      string lineHeightStr = stylesContainer.GetStyles().Get<string, string>("line-height");
      float heightActualValue = VerticalAlignmentApplierUtil.GetLineHeightActualValue(absoluteLength, rootFontSize, lineHeightStr);
      return VerticalAlignmentApplierUtil.GetParentFontSize(stylesContainer) * 0.8f - (float) ((double) absoluteLength * 0.8 + ((double) heightActualValue - (double) absoluteLength) / 2.0);
    }

    private static float CalcTextRiseForTextBottom(
      IStylesContainer stylesContainer,
      float rootFontSize)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(stylesContainer.GetStyles().Get<string, string>("font-size"));
      string lineHeightStr = stylesContainer.GetStyles().Get<string, string>("line-height");
      float heightActualValue = VerticalAlignmentApplierUtil.GetLineHeightActualValue(absoluteLength, rootFontSize, lineHeightStr);
      float parentFontSize = VerticalAlignmentApplierUtil.GetParentFontSize(stylesContainer);
      return (float) ((double) absoluteLength * 0.2 + ((double) heightActualValue - (double) absoluteLength) / 2.0) - parentFontSize * 0.2f;
    }

    private static float CalcTextRiseForPercentageValue(
      IStylesContainer stylesContainer,
      float rootFontSize,
      string vAlignVal)
    {
      double absoluteLength = (double) CssDimensionParsingUtils.ParseAbsoluteLength(stylesContainer.GetStyles().Get<string, string>("font-size"));
      string str = stylesContainer.GetStyles().Get<string, string>("line-height");
      double rootFontSize1 = (double) rootFontSize;
      string lineHeightStr = str;
      float heightActualValue = VerticalAlignmentApplierUtil.GetLineHeightActualValue((float) absoluteLength, (float) rootFontSize1, lineHeightStr);
      return CssDimensionParsingUtils.ParseRelativeValue(vAlignVal, heightActualValue);
    }

    private static float GetLineHeightActualValue(
      float fontSize,
      float rootFontSize,
      string lineHeightStr)
    {
      float heightActualValue;
      if (lineHeightStr != null)
      {
        if ("normal".Equals(lineHeightStr) || "auto".Equals(lineHeightStr))
        {
          heightActualValue = fontSize * 1.2f;
        }
        else
        {
          UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(lineHeightStr, fontSize, rootFontSize);
          heightActualValue = !CssTypesValidationUtils.IsNumber(lineHeightStr) ? (!lengthValueToPt.IsPointValue() ? (float) ((double) fontSize * (double) lengthValueToPt.GetValue() / 100.0) : lengthValueToPt.GetValue()) : fontSize * lengthValueToPt.GetValue();
        }
      }
      else
        heightActualValue = fontSize * 1.2f;
      return heightActualValue;
    }

    private static float GetParentFontSize(IStylesContainer stylesContainer)
    {
      return !(stylesContainer is INode) || !(((INode) stylesContainer).ParentNode() is IStylesContainer) ? CssDimensionParsingUtils.ParseAbsoluteLength(stylesContainer.GetStyles().Get<string, string>("font-size")) : CssDimensionParsingUtils.ParseAbsoluteLength(((IStylesContainer) ((INode) stylesContainer).ParentNode()).GetStyles().Get<string, string>("font-size"));
    }
  }
}
