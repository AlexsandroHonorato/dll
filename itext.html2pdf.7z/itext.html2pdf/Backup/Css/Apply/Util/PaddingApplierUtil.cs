﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.PaddingApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class PaddingApplierUtil
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (PaddingApplierUtil));

    private PaddingApplierUtil()
    {
    }

    public static void ApplyPaddings(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      PaddingApplierUtil.ApplyPaddings(cssProps, context, element, 0.0f, 0.0f);
    }

    public static void ApplyPaddings(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element,
      float baseValueVertical,
      float baseValueHorizontal)
    {
      string str1 = cssProps.Get<string, string>("padding-top");
      string str2 = cssProps.Get<string, string>("padding-bottom");
      string str3 = cssProps.Get<string, string>("padding-left");
      string str4 = cssProps.Get<string, string>("padding-right");
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      double num1 = (double) absoluteLength;
      double num2 = (double) rootFontSize;
      UnitValue lengthValueToPt1 = CssDimensionParsingUtils.ParseLengthValueToPt(str1, (float) num1, (float) num2);
      UnitValue lengthValueToPt2 = CssDimensionParsingUtils.ParseLengthValueToPt(str2, absoluteLength, rootFontSize);
      UnitValue lengthValueToPt3 = CssDimensionParsingUtils.ParseLengthValueToPt(str3, absoluteLength, rootFontSize);
      UnitValue lengthValueToPt4 = CssDimensionParsingUtils.ParseLengthValueToPt(str4, absoluteLength, rootFontSize);
      if (lengthValueToPt1 != null)
      {
        if (lengthValueToPt1.IsPointValue())
          element.SetProperty(50, (object) lengthValueToPt1);
        else if ((double) baseValueVertical != 0.0)
          element.SetProperty(50, (object) new UnitValue(1, (float) ((double) baseValueVertical * (double) lengthValueToPt1.GetValue() * 0.0099999997764825821)));
        else
          LoggerExtensions.LogError(PaddingApplierUtil.logger, "Padding value in percents not supported", Array.Empty<object>());
      }
      if (lengthValueToPt2 != null)
      {
        if (lengthValueToPt2.IsPointValue())
          element.SetProperty(47, (object) lengthValueToPt2);
        else if ((double) baseValueVertical != 0.0)
          element.SetProperty(47, (object) new UnitValue(1, (float) ((double) baseValueVertical * (double) lengthValueToPt2.GetValue() * 0.0099999997764825821)));
        else
          LoggerExtensions.LogError(PaddingApplierUtil.logger, "Padding value in percents not supported", Array.Empty<object>());
      }
      if (lengthValueToPt3 != null)
      {
        if (lengthValueToPt3.IsPointValue())
          element.SetProperty(48, (object) lengthValueToPt3);
        else if ((double) baseValueHorizontal != 0.0)
          element.SetProperty(48, (object) new UnitValue(1, (float) ((double) baseValueHorizontal * (double) lengthValueToPt3.GetValue() * 0.0099999997764825821)));
        else
          LoggerExtensions.LogError(PaddingApplierUtil.logger, "Padding value in percents not supported", Array.Empty<object>());
      }
      if (lengthValueToPt4 == null)
        return;
      if (lengthValueToPt4.IsPointValue())
        element.SetProperty(49, (object) lengthValueToPt4);
      else if ((double) baseValueHorizontal != 0.0)
        element.SetProperty(49, (object) new UnitValue(1, (float) ((double) baseValueHorizontal * (double) lengthValueToPt4.GetValue() * 0.0099999997764825821)));
      else
        LoggerExtensions.LogError(PaddingApplierUtil.logger, "Padding value in percents not supported", Array.Empty<object>());
    }
  }
}
