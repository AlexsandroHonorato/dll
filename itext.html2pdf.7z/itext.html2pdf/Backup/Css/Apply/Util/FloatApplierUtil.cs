﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.FloatApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class FloatApplierUtil
  {
    private FloatApplierUtil()
    {
    }

    public static void ApplyFloating(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string str1 = cssProps.Get<string, string>("float");
      if (str1 != null)
      {
        if ("left".Equals(str1))
          element.SetProperty(99, (object) FloatPropertyValue.LEFT);
        else if ("right".Equals(str1))
          element.SetProperty(99, (object) FloatPropertyValue.RIGHT);
      }
      string str2 = cssProps.Get<string, string>("clear");
      if (str2 == null)
        return;
      if ("left".Equals(str2))
        element.SetProperty(100, (object) ClearPropertyValue.LEFT);
      else if ("right".Equals(str2))
      {
        element.SetProperty(100, (object) ClearPropertyValue.RIGHT);
      }
      else
      {
        if (!"both".Equals(str2))
          return;
        element.SetProperty(100, (object) ClearPropertyValue.BOTH);
      }
    }
  }
}
