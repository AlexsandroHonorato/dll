﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.OpacityApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Layout;
using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class OpacityApplierUtil
  {
    private OpacityApplierUtil()
    {
    }

    public static void ApplyOpacity(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer container)
    {
      float? nullable = CssDimensionParsingUtils.ParseFloat(cssProps.Get<string, string>("opacity"));
      if (!nullable.HasValue)
        return;
      container.SetProperty(92, (object) nullable);
    }
  }
}
