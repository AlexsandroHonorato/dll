﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.CounterProcessorUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Css.Resolve;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class CounterProcessorUtil
  {
    public static void ProcessCounters(IDictionary<string, string> cssProps, CssContext context)
    {
      CounterProcessorUtil.ProcessReset(cssProps.Get<string, string>("counter-reset"), context);
      CounterProcessorUtil.ProcessIncrement(cssProps.Get<string, string>("counter-increment"), context);
    }

    public static void StartProcessingCounters(CssContext context, IElementNode element)
    {
      context.GetCounterManager().PushEveryCounterToCounters(element);
    }

    public static void EndProcessingCounters(CssContext context, IElementNode element)
    {
      context.GetCounterManager().PopEveryCounterFromCounters(element);
    }

    private static void ProcessReset(string counterReset, CssContext context)
    {
      if (counterReset == null)
        return;
      CssCounterManager counterManager = context.GetCounterManager();
      string[] strArray = StringUtil.Split(counterReset, " ");
      for (int index = 0; index < strArray.Length; ++index)
      {
        string counterName = strArray[index];
        int? integer;
        if (index + 1 < strArray.Length && (integer = CssDimensionParsingUtils.ParseInteger(strArray[index + 1])).HasValue)
        {
          counterManager.ResetCounter(counterName, integer.Value);
          ++index;
        }
        else
          counterManager.ResetCounter(counterName);
      }
    }

    private static void ProcessIncrement(string counterIncrement, CssContext context)
    {
      if (counterIncrement == null)
        return;
      CssCounterManager counterManager = context.GetCounterManager();
      string[] strArray = StringUtil.Split(counterIncrement, " ");
      for (int index = 0; index < strArray.Length; ++index)
      {
        string counterName = strArray[index];
        int? integer;
        if (index + 1 < strArray.Length && (integer = CssDimensionParsingUtils.ParseInteger(strArray[index + 1])).HasValue)
        {
          counterManager.IncrementCounter(counterName, integer.Value);
          ++index;
        }
        else
          counterManager.IncrementCounter(counterName);
      }
    }
  }
}
