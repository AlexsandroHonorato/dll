﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.BorderStyleApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class BorderStyleApplierUtil
  {
    private BorderStyleApplierUtil()
    {
    }

    public static void ApplyBorders(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      Border[] bordersArray = BorderStyleApplierUtil.GetBordersArray(cssProps, absoluteLength, rootFontSize);
      if (bordersArray[0] != null)
        element.SetProperty(13, (object) bordersArray[0]);
      if (bordersArray[1] != null)
        element.SetProperty(12, (object) bordersArray[1]);
      if (bordersArray[2] != null)
        element.SetProperty(10, (object) bordersArray[2]);
      if (bordersArray[3] != null)
        element.SetProperty(11, (object) bordersArray[3]);
      BorderRadius[] borderRadiiArray = BorderStyleApplierUtil.GetBorderRadiiArray(cssProps, absoluteLength, rootFontSize);
      if (borderRadiiArray[0] != null)
        element.SetProperty(110, (object) borderRadiiArray[0]);
      if (borderRadiiArray[1] != null)
        element.SetProperty(111, (object) borderRadiiArray[1]);
      if (borderRadiiArray[2] != null)
        element.SetProperty(112, (object) borderRadiiArray[2]);
      if (borderRadiiArray[3] == null)
        return;
      element.SetProperty(113, (object) borderRadiiArray[3]);
    }

    public static Border[] GetBordersArray(IDictionary<string, string> styles, float em, float rem)
    {
      return new Border[4]
      {
        BorderStyleApplierUtil.GetCertainBorder(styles.Get<string, string>("border-top-width"), styles.Get<string, string>("border-top-style"), BorderStyleApplierUtil.GetSpecificBorderColorOrDefaultColor(styles, "border-top-color"), em, rem),
        BorderStyleApplierUtil.GetCertainBorder(styles.Get<string, string>("border-right-width"), styles.Get<string, string>("border-right-style"), BorderStyleApplierUtil.GetSpecificBorderColorOrDefaultColor(styles, "border-right-color"), em, rem),
        BorderStyleApplierUtil.GetCertainBorder(styles.Get<string, string>("border-bottom-width"), styles.Get<string, string>("border-bottom-style"), BorderStyleApplierUtil.GetSpecificBorderColorOrDefaultColor(styles, "border-bottom-color"), em, rem),
        BorderStyleApplierUtil.GetCertainBorder(styles.Get<string, string>("border-left-width"), styles.Get<string, string>("border-left-style"), BorderStyleApplierUtil.GetSpecificBorderColorOrDefaultColor(styles, "border-left-color"), em, rem)
      };
    }

    public static Border GetCertainBorder(
      string borderWidth,
      string borderStyle,
      string borderColor,
      float em,
      float rem)
    {
      if (borderStyle == null || "none".Equals(borderStyle))
        return (Border) null;
      if (borderWidth == null)
        borderWidth = CssDefaults.GetDefaultValue("border-width");
      if (CommonCssConstants.BORDER_WIDTH_VALUES.Contains(borderWidth))
      {
        if ("thin".Equals(borderWidth))
          borderWidth = "1px";
        else if ("medium".Equals(borderWidth))
          borderWidth = "2px";
        else if ("thick".Equals(borderWidth))
          borderWidth = "3px";
      }
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(borderWidth, em, rem);
      if (lengthValueToPt == null)
        return (Border) null;
      if (lengthValueToPt.IsPercentValue())
        return (Border) null;
      float width = lengthValueToPt.GetValue();
      Border certainBorder = (Border) null;
      if ((double) width > 0.0)
      {
        Color color1 = ColorConstants.BLACK;
        float opacity = 1f;
        if (borderColor != null)
        {
          if (!"transparent".Equals(borderColor))
          {
            TransparentColor color2 = CssDimensionParsingUtils.ParseColor(borderColor);
            color1 = color2.GetColor();
            opacity = color2.GetOpacity();
          }
          else
            opacity = 0.0f;
        }
        else if ("groove".Equals(borderStyle) || "ridge".Equals(borderStyle) || "inset".Equals(borderStyle) || "outset".Equals(borderStyle))
          color1 = (Color) new DeviceRgb(212, 208, 200);
        switch (borderStyle)
        {
          case "dashed":
            certainBorder = (Border) new DashedBorder(color1, width, opacity);
            break;
          case "dotted":
            certainBorder = (Border) new RoundDotsBorder(color1, width, opacity);
            break;
          case "double":
            certainBorder = (Border) new DoubleBorder(color1, width, opacity);
            break;
          case "groove":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new GrooveBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new GrooveBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "inset":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new InsetBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new InsetBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "outset":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new OutsetBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new OutsetBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "ridge":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new RidgeBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new RidgeBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "solid":
            certainBorder = (Border) new SolidBorder(color1, width, opacity);
            break;
          default:
            certainBorder = (Border) null;
            break;
        }
      }
      return certainBorder;
    }

    public static BorderRadius[] GetBorderRadiiArray(
      IDictionary<string, string> styles,
      float em,
      float rem)
    {
      BorderRadius[] borderRadiiArray = new BorderRadius[4];
      BorderRadius borderRadius = (BorderRadius) null;
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(styles.Get<string, string>("border-radius"), em, rem);
      if (lengthValueToPt != null)
        borderRadius = new BorderRadius(lengthValueToPt);
      UnitValue[] cornerBorderRadius1 = CssDimensionParsingUtils.ParseSpecificCornerBorderRadius(styles.Get<string, string>("border-top-left-radius"), em, rem);
      borderRadiiArray[0] = cornerBorderRadius1 == null ? borderRadius : new BorderRadius(cornerBorderRadius1[0], cornerBorderRadius1[1]);
      UnitValue[] cornerBorderRadius2 = CssDimensionParsingUtils.ParseSpecificCornerBorderRadius(styles.Get<string, string>("border-top-right-radius"), em, rem);
      borderRadiiArray[1] = cornerBorderRadius2 == null ? borderRadius : new BorderRadius(cornerBorderRadius2[0], cornerBorderRadius2[1]);
      UnitValue[] cornerBorderRadius3 = CssDimensionParsingUtils.ParseSpecificCornerBorderRadius(styles.Get<string, string>("border-bottom-right-radius"), em, rem);
      borderRadiiArray[2] = cornerBorderRadius3 == null ? borderRadius : new BorderRadius(cornerBorderRadius3[0], cornerBorderRadius3[1]);
      UnitValue[] cornerBorderRadius4 = CssDimensionParsingUtils.ParseSpecificCornerBorderRadius(styles.Get<string, string>("border-bottom-left-radius"), em, rem);
      borderRadiiArray[3] = cornerBorderRadius4 == null ? borderRadius : new BorderRadius(cornerBorderRadius4[0], cornerBorderRadius4[1]);
      return borderRadiiArray;
    }

    private static string GetSpecificBorderColorOrDefaultColor(
      IDictionary<string, string> styles,
      string specificBorderColorProperty)
    {
      string colorOrDefaultColor = styles.Get<string, string>(specificBorderColorProperty);
      if (colorOrDefaultColor == null || "currentcolor".Equals(colorOrDefaultColor))
        colorOrDefaultColor = styles.Get<string, string>("color");
      return colorOrDefaultColor;
    }
  }
}
