﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.PositionApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class PositionApplierUtil
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (PositionApplierUtil));

    private PositionApplierUtil()
    {
    }

    public static void ApplyPosition(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string position = cssProps.Get<string, string>("position");
      if ("absolute".Equals(position))
      {
        element.SetProperty(52, (object) 3);
        PositionApplierUtil.ApplyLeftRightTopBottom(cssProps, context, element, position);
      }
      else if ("relative".Equals(position))
      {
        element.SetProperty(52, (object) 2);
        PositionApplierUtil.ApplyLeftRightTopBottom(cssProps, context, element, position);
      }
      else
        "fixed".Equals(position);
    }

    private static void ApplyLeftRightTopBottom(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element,
      string position)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      if ("relative".Equals(position) && cssProps.ContainsKey("left") && cssProps.ContainsKey("right"))
      {
        if ("rtl".Equals(cssProps.Get<string, string>("direction")))
          PositionApplierUtil.ApplyRightProperty(cssProps, element, absoluteLength, rootFontSize, 54);
        else
          PositionApplierUtil.ApplyLeftProperty(cssProps, element, absoluteLength, rootFontSize, 34);
      }
      else
      {
        PositionApplierUtil.ApplyLeftProperty(cssProps, element, absoluteLength, rootFontSize, 34);
        PositionApplierUtil.ApplyRightProperty(cssProps, element, absoluteLength, rootFontSize, 54);
      }
      PositionApplierUtil.ApplyTopProperty(cssProps, element, absoluteLength, rootFontSize, 73);
      PositionApplierUtil.ApplyBottomProperty(cssProps, element, absoluteLength, rootFontSize, 14);
    }

    private static void ApplyLeftProperty(
      IDictionary<string, string> cssProps,
      IPropertyContainer element,
      float em,
      float rem,
      int layoutPropertyMapping)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("left"), em, rem);
      if (lengthValueToPt == null)
        return;
      if (lengthValueToPt.IsPointValue())
        element.SetProperty(layoutPropertyMapping, (object) lengthValueToPt.GetValue());
      else
        LoggerExtensions.LogError(PositionApplierUtil.logger, MessageFormatUtil.Format("Css property {0} in percents is not supported", new object[1]
        {
          (object) "left"
        }), Array.Empty<object>());
    }

    private static void ApplyRightProperty(
      IDictionary<string, string> cssProps,
      IPropertyContainer element,
      float em,
      float rem,
      int layoutPropertyMapping)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("right"), em, rem);
      if (lengthValueToPt == null)
        return;
      if (lengthValueToPt.IsPointValue())
        element.SetProperty(layoutPropertyMapping, (object) lengthValueToPt.GetValue());
      else
        LoggerExtensions.LogError(PositionApplierUtil.logger, MessageFormatUtil.Format("Css property {0} in percents is not supported", new object[1]
        {
          (object) "right"
        }), Array.Empty<object>());
    }

    private static void ApplyTopProperty(
      IDictionary<string, string> cssProps,
      IPropertyContainer element,
      float em,
      float rem,
      int layoutPropertyMapping)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("top"), em, rem);
      if (lengthValueToPt == null)
        return;
      if (lengthValueToPt.IsPointValue())
        element.SetProperty(layoutPropertyMapping, (object) lengthValueToPt.GetValue());
      else
        LoggerExtensions.LogError(PositionApplierUtil.logger, MessageFormatUtil.Format("Css property {0} in percents is not supported", new object[1]
        {
          (object) "top"
        }), Array.Empty<object>());
    }

    private static void ApplyBottomProperty(
      IDictionary<string, string> cssProps,
      IPropertyContainer element,
      float em,
      float rem,
      int layoutPropertyMapping)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("bottom"), em, rem);
      if (lengthValueToPt == null)
        return;
      if (lengthValueToPt.IsPointValue())
        element.SetProperty(layoutPropertyMapping, (object) lengthValueToPt.GetValue());
      else
        LoggerExtensions.LogError(PositionApplierUtil.logger, MessageFormatUtil.Format("Css property {0} in percents is not supported", new object[1]
        {
          (object) "bottom"
        }), Array.Empty<object>());
    }
  }
}
