﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.HyphenationApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Hyphenation;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class HyphenationApplierUtil
  {
    private const int HYPHENATE_BEFORE = 2;
    private const int HYPHENATE_AFTER = 3;

    private HyphenationApplierUtil()
    {
    }

    public static void ApplyHyphenation(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IStylesContainer stylesContainer,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("hyphens") ?? CssDefaults.GetDefaultValue("hyphens");
      if ("none".Equals(str))
        element.SetProperty(30, (object) null);
      else if ("manual".Equals(str))
      {
        element.SetProperty(30, (object) new HyphenationConfig(2, 3));
      }
      else
      {
        if (!"auto".Equals(str) || !(stylesContainer is IElementNode))
          return;
        string lang = ((IElementNode) stylesContainer).GetLang();
        if (lang == null || lang.Length <= 0)
          return;
        element.SetProperty(30, (object) new HyphenationConfig(lang.JSubstring(0, 2), "", 2, 3));
      }
    }
  }
}
