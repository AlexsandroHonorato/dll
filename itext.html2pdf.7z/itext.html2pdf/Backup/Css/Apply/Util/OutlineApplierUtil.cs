﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.OutlineApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class OutlineApplierUtil
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (OutlineApplierUtil));

    private OutlineApplierUtil()
    {
    }

    public static void ApplyOutlines(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      Border certainBorder = OutlineApplierUtil.GetCertainBorder(cssProps.Get<string, string>("outline-width"), cssProps.Get<string, string>("outline-style"), OutlineApplierUtil.GetSpecificOutlineColorOrDefaultColor(cssProps, "outline-color"), absoluteLength, rootFontSize);
      if (certainBorder != null)
        element.SetProperty(106, (object) certainBorder);
      if (cssProps.Get<string, string>("outline-offset") == null || element.GetProperty<Border>(106) == null)
        return;
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("outline-offset"), absoluteLength, rootFontSize);
      if (lengthValueToPt == null)
        return;
      if (lengthValueToPt.IsPercentValue())
      {
        LoggerExtensions.LogError(OutlineApplierUtil.LOGGER, "outline-width in percents is not supported", Array.Empty<object>());
      }
      else
      {
        if ((double) lengthValueToPt.GetValue() == 0.0)
          return;
        element.SetProperty(107, (object) lengthValueToPt.GetValue());
      }
    }

    public static Border GetCertainBorder(
      string outlineWidth,
      string outlineStyle,
      string outlineColor,
      float em,
      float rem)
    {
      if (outlineStyle == null || "none".Equals(outlineStyle))
        return (Border) null;
      if (outlineWidth == null)
        outlineWidth = CssDefaults.GetDefaultValue("outline-width");
      if (CommonCssConstants.BORDER_WIDTH_VALUES.Contains(outlineWidth))
      {
        if ("thin".Equals(outlineWidth))
          outlineWidth = "1px";
        else if ("medium".Equals(outlineWidth))
          outlineWidth = "2px";
        else if ("thick".Equals(outlineWidth))
          outlineWidth = "3px";
      }
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(outlineWidth, em, rem);
      if (lengthValueToPt == null)
        return (Border) null;
      if (lengthValueToPt.IsPercentValue())
      {
        LoggerExtensions.LogError(OutlineApplierUtil.LOGGER, "outline-width in percents is not supported", Array.Empty<object>());
        return (Border) null;
      }
      float width = lengthValueToPt.GetValue();
      Border certainBorder = (Border) null;
      if ((double) width > 0.0)
      {
        Color color1 = ColorConstants.BLACK;
        float opacity = 1f;
        if (outlineColor != null)
        {
          if (!"transparent".Equals(outlineColor))
          {
            TransparentColor color2 = CssDimensionParsingUtils.ParseColor(outlineColor);
            color1 = color2.GetColor();
            opacity = color2.GetOpacity();
          }
          else
            opacity = 0.0f;
        }
        else if ("groove".Equals(outlineStyle) || "ridge".Equals(outlineStyle) || "inset".Equals(outlineStyle) || "outset".Equals(outlineStyle))
          color1 = (Color) new DeviceRgb(212, 208, 200);
        switch (outlineStyle)
        {
          case "auto":
          case "solid":
            certainBorder = (Border) new SolidBorder(color1, width, opacity);
            break;
          case "dashed":
            certainBorder = (Border) new DashedBorder(color1, width, opacity);
            break;
          case "dotted":
            certainBorder = (Border) new DottedBorder(color1, width, opacity);
            break;
          case "double":
            certainBorder = (Border) new DoubleBorder(color1, width, opacity);
            break;
          case "groove":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new GrooveBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new GrooveBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "inset":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new InsetBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new InsetBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "outset":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new OutsetBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new OutsetBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          case "ridge":
            if (color1 is DeviceRgb)
              certainBorder = (Border) new RidgeBorder((DeviceRgb) color1, width, opacity);
            if (color1 is DeviceCmyk)
            {
              certainBorder = (Border) new RidgeBorder((DeviceCmyk) color1, width, opacity);
              break;
            }
            break;
          default:
            certainBorder = (Border) null;
            break;
        }
      }
      return certainBorder;
    }

    private static string GetSpecificOutlineColorOrDefaultColor(
      IDictionary<string, string> styles,
      string specificOutlineColorProperty)
    {
      string colorOrDefaultColor = styles.Get<string, string>(specificOutlineColorProperty);
      if (colorOrDefaultColor == null || "currentcolor".Equals(colorOrDefaultColor))
        colorOrDefaultColor = styles.Get<string, string>("color");
      else if ("invert".Equals(colorOrDefaultColor))
      {
        LoggerExtensions.LogWarning(OutlineApplierUtil.LOGGER, "Invert color for outline is not supported", Array.Empty<object>());
        colorOrDefaultColor = styles.Get<string, string>("color");
      }
      return colorOrDefaultColor;
    }
  }
}
