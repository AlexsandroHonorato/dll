﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.OrphansWidowsApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class OrphansWidowsApplierUtil
  {
    public const int MAX_LINES_TO_MOVE = 2;
    public const bool OVERFLOW_PARAGRAPH_ON_VIOLATION = false;

    private OrphansWidowsApplierUtil()
    {
    }

    public static void ApplyOrphansAndWidows(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      if (cssProps == null)
        return;
      if (cssProps.ContainsKey("widows"))
      {
        int? integer = CssDimensionParsingUtils.ParseInteger(cssProps.Get<string, string>("widows"));
        if (integer.HasValue)
        {
          int? nullable = integer;
          int num = 0;
          if (nullable.GetValueOrDefault() > num & nullable.HasValue)
            element.SetProperty(122, (object) new ParagraphWidowsControl(integer.Value, 2, false));
        }
      }
      if (!cssProps.ContainsKey("orphans"))
        return;
      int? integer1 = CssDimensionParsingUtils.ParseInteger(cssProps.Get<string, string>("orphans"));
      if (!integer1.HasValue)
        return;
      int? nullable1 = integer1;
      int num1 = 0;
      if (!(nullable1.GetValueOrDefault() > num1 & nullable1.HasValue))
        return;
      element.SetProperty(121, (object) new ParagraphOrphansControl(integer1.Value));
    }
  }
}
