﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.PageBreakApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl.Layout;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public class PageBreakApplierUtil
  {
    private PageBreakApplierUtil()
    {
    }

    public static void ApplyPageBreakProperties(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      PageBreakApplierUtil.ApplyPageBreakInside(cssProps, context, element);
      PageBreakApplierUtil.ApplyKeepWithNext(cssProps, context, element);
    }

    public static void AddPageBreakElementBefore(
      ProcessorContext context,
      ITagWorker parentTagWorker,
      IElementNode childElement,
      ITagWorker childTagWorker)
    {
      if (!PageBreakApplierUtil.IsEligibleForBreakBeforeAfter(parentTagWorker, childElement, childTagWorker))
        return;
      HtmlPageBreak htmlPageBreak = PageBreakApplierUtil.CreateHtmlPageBreak(((IStylesContainer) childElement).GetStyles().Get<string, string>("page-break-before"));
      if (htmlPageBreak == null)
        return;
      parentTagWorker.ProcessTagChild((ITagWorker) new PageBreakApplierUtil.HtmlPageBreakWorker(htmlPageBreak), context);
    }

    public static void AddPageBreakElementAfter(
      ProcessorContext context,
      ITagWorker parentTagWorker,
      IElementNode childElement,
      ITagWorker childTagWorker)
    {
      if (!PageBreakApplierUtil.IsEligibleForBreakBeforeAfter(parentTagWorker, childElement, childTagWorker))
        return;
      HtmlPageBreak htmlPageBreak = PageBreakApplierUtil.CreateHtmlPageBreak(((IStylesContainer) childElement).GetStyles().Get<string, string>("page-break-after"));
      if (htmlPageBreak == null)
        return;
      parentTagWorker.ProcessTagChild((ITagWorker) new PageBreakApplierUtil.HtmlPageBreakWorker(htmlPageBreak), context);
    }

    private static bool IsEligibleForBreakBeforeAfter(
      ITagWorker parentTagWorker,
      IElementNode childElement,
      ITagWorker childTagWorker)
    {
      string str = ((IStylesContainer) childElement).GetStyles().Get<string, string>("display");
      if ("block".Equals(str) || "table".Equals(str))
        return true;
      return str == null && childTagWorker.GetElementResult() is IBlockElement;
    }

    private static HtmlPageBreak CreateHtmlPageBreak(string pageBreakVal)
    {
      HtmlPageBreak htmlPageBreak = (HtmlPageBreak) null;
      if ("always".Equals(pageBreakVal))
        htmlPageBreak = new HtmlPageBreak(HtmlPageBreakType.ALWAYS);
      else if ("left".Equals(pageBreakVal))
        htmlPageBreak = new HtmlPageBreak(HtmlPageBreakType.LEFT);
      else if ("right".Equals(pageBreakVal))
        htmlPageBreak = new HtmlPageBreak(HtmlPageBreakType.RIGHT);
      return htmlPageBreak;
    }

    private static void ApplyKeepWithNext(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("page-break-before");
      if ("avoid".Equals(cssProps.Get<string, string>("page-break-after")))
        element.SetProperty(81, (object) true);
      if (!"avoid".Equals(str))
        return;
      element.SetProperty(1048577, (object) true);
    }

    private static void ApplyPageBreakInside(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      if (!"avoid".Equals(cssProps.Get<string, string>("page-break-inside")))
        return;
      element.SetProperty(32, (object) true);
    }

    private class HtmlPageBreakWorker : ITagWorker
    {
      private HtmlPageBreak pageBreak;

      internal HtmlPageBreakWorker(HtmlPageBreak pageBreak) => this.pageBreak = pageBreak;

      public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
      {
      }

      public virtual bool ProcessContent(string content, ProcessorContext context)
      {
        throw new InvalidOperationException();
      }

      public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
      {
        throw new InvalidOperationException();
      }

      public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.pageBreak;
    }
  }
}
