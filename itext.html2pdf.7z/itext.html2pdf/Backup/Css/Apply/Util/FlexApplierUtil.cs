﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Util.FlexApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Util
{
  public sealed class FlexApplierUtil
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (FlexApplierUtil));

    private FlexApplierUtil()
    {
    }

    public static void ApplyFlexItemProperties(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      element.SetProperty(89, (object) null);
      FlexApplierUtil.LogWarningIfThereAreNotSupportedPropertyValues(FlexApplierUtil.CreateSupportedFlexItemPropertiesAndValuesMap(), cssProps);
      string str1 = cssProps.Get<string, string>("flex-grow");
      if (str1 != null)
      {
        float? nullable = CssDimensionParsingUtils.ParseFloat(str1);
        element.SetProperty(132, (object) nullable);
      }
      string str2 = cssProps.Get<string, string>("flex-shrink");
      if (str2 != null)
      {
        float? nullable = CssDimensionParsingUtils.ParseFloat(str2);
        element.SetProperty((int) sbyte.MaxValue, (object) nullable);
      }
      string str3 = cssProps.Get<string, string>("flex-basis");
      if (str3 == null || "auto".Equals(str3))
        return;
      if (!"content".Equals(str3))
      {
        float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(cssProps.Get<string, string>("font-size"));
        float rootFontSize = context.GetCssContext().GetRootFontSize();
        UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(str3, absoluteLength, rootFontSize);
        element.SetProperty(131, (object) lengthValueToPt);
      }
      else
        LoggerExtensions.LogWarning(FlexApplierUtil.LOGGER, MessageFormatUtil.Format("Flex related property {0}: {1} is not supported yet.", new object[2]
        {
          (object) "flex-basis",
          (object) "content"
        }), Array.Empty<object>());
    }

    public static void ApplyFlexContainerProperties(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      FlexApplierUtil.LogWarningIfThereAreNotSupportedPropertyValues(FlexApplierUtil.CreateSupportedFlexContainerPropertiesAndValuesMap(), cssProps);
      FlexApplierUtil.ApplyAlignItems(cssProps, element);
      FlexApplierUtil.ApplyJustifyContent(cssProps, element);
      FlexApplierUtil.ApplyWrap(cssProps, element);
      FlexApplierUtil.ApplyDirection(cssProps, element);
    }

    private static void ApplyWrap(IDictionary<string, string> cssProps, IPropertyContainer element)
    {
      FlexWrapPropertyValue wrapPropertyValue;
      switch (cssProps.Get<string, string>("flex-wrap"))
      {
        case null:
          return;
        case "wrap":
          wrapPropertyValue = FlexWrapPropertyValue.WRAP;
          break;
        case "wrap-reverse":
          wrapPropertyValue = FlexWrapPropertyValue.WRAP_REVERSE;
          break;
        case "nowrap":
          wrapPropertyValue = FlexWrapPropertyValue.NOWRAP;
          break;
        default:
          wrapPropertyValue = FlexWrapPropertyValue.NOWRAP;
          break;
      }
      element.SetProperty(128, (object) wrapPropertyValue);
    }

    private static void ApplyDirection(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      FlexDirectionPropertyValue directionPropertyValue;
      switch (cssProps.Get<string, string>("flex-direction"))
      {
        case null:
          return;
        case "row":
          directionPropertyValue = FlexDirectionPropertyValue.ROW;
          break;
        case "row-reverse":
          directionPropertyValue = FlexDirectionPropertyValue.ROW_REVERSE;
          break;
        case "column":
          directionPropertyValue = FlexDirectionPropertyValue.COLUMN;
          break;
        case "column-reverse":
          directionPropertyValue = FlexDirectionPropertyValue.COLUMN_REVERSE;
          break;
        default:
          directionPropertyValue = FlexDirectionPropertyValue.ROW;
          break;
      }
      element.SetProperty(139, (object) directionPropertyValue);
    }

    private static void ApplyAlignItems(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("align-items");
      AlignmentPropertyValue alignmentPropertyValue;
      switch (str)
      {
        case "center":
          alignmentPropertyValue = AlignmentPropertyValue.CENTER;
          break;
        case "end":
          alignmentPropertyValue = AlignmentPropertyValue.END;
          break;
        case "flex-end":
          alignmentPropertyValue = AlignmentPropertyValue.FLEX_END;
          break;
        case "flex-start":
          alignmentPropertyValue = AlignmentPropertyValue.FLEX_START;
          break;
        case "normal":
          alignmentPropertyValue = AlignmentPropertyValue.NORMAL;
          break;
        case "self-end":
          alignmentPropertyValue = AlignmentPropertyValue.SELF_END;
          break;
        case "self-start":
          alignmentPropertyValue = AlignmentPropertyValue.SELF_START;
          break;
        case "start":
          alignmentPropertyValue = AlignmentPropertyValue.START;
          break;
        case "stretch":
          alignmentPropertyValue = AlignmentPropertyValue.STRETCH;
          break;
        case null:
          return;
        default:
          LoggerExtensions.LogWarning(FlexApplierUtil.LOGGER, MessageFormatUtil.Format("Flex related property {0}: {1} is not supported yet.", new object[2]
          {
            (object) "align-items",
            (object) str
          }), Array.Empty<object>());
          alignmentPropertyValue = AlignmentPropertyValue.STRETCH;
          break;
      }
      element.SetProperty(134, (object) alignmentPropertyValue);
    }

    private static void ApplyJustifyContent(
      IDictionary<string, string> cssProps,
      IPropertyContainer element)
    {
      string str = cssProps.Get<string, string>("justify-content");
      JustifyContent justifyContent;
      switch (str)
      {
        case "center":
          justifyContent = JustifyContent.CENTER;
          break;
        case "end":
          justifyContent = JustifyContent.END;
          break;
        case "flex-end":
          justifyContent = JustifyContent.FLEX_END;
          break;
        case "flex-start":
          justifyContent = JustifyContent.FLEX_START;
          break;
        case "left":
          justifyContent = JustifyContent.LEFT;
          break;
        case "normal":
          justifyContent = JustifyContent.NORMAL;
          break;
        case "right":
          justifyContent = JustifyContent.RIGHT;
          break;
        case "self-end":
          justifyContent = JustifyContent.SELF_END;
          break;
        case "self-start":
          justifyContent = JustifyContent.SELF_START;
          break;
        case "start":
          justifyContent = JustifyContent.START;
          break;
        case "stretch":
          justifyContent = JustifyContent.STRETCH;
          break;
        case null:
          return;
        default:
          LoggerExtensions.LogWarning(FlexApplierUtil.LOGGER, MessageFormatUtil.Format("Flex related property {0}: {1} is not supported yet.", new object[2]
          {
            (object) "justify-content",
            (object) str
          }), Array.Empty<object>());
          justifyContent = JustifyContent.FLEX_START;
          break;
      }
      element.SetProperty(133, (object) justifyContent);
    }

    private static void LogWarningIfThereAreNotSupportedPropertyValues(
      IDictionary<string, ICollection<string>> supportedPairs,
      IDictionary<string, string> cssProps)
    {
      foreach (KeyValuePair<string, ICollection<string>> supportedPair in (IEnumerable<KeyValuePair<string, ICollection<string>>>) supportedPairs)
      {
        string key = supportedPair.Key;
        ICollection<string> strings = supportedPair.Value;
        string str = cssProps.Get<string, string>(key);
        if (str != null && !strings.Contains(str))
          LoggerExtensions.LogWarning(FlexApplierUtil.LOGGER, MessageFormatUtil.Format("Flex related property {0}: {1} is not supported yet.", new object[2]
          {
            (object) key,
            (object) str
          }), Array.Empty<object>());
      }
    }

    private static IDictionary<string, ICollection<string>> CreateSupportedFlexItemPropertiesAndValuesMap()
    {
      Dictionary<string, ICollection<string>> col = new Dictionary<string, ICollection<string>>();
      ICollection<string> strings = (ICollection<string>) new HashSet<string>();
      strings.Add("auto");
      col.Put<string, ICollection<string>>("align-self", strings);
      col.Put<string, ICollection<string>>("order", (ICollection<string>) new HashSet<string>());
      return (IDictionary<string, ICollection<string>>) col;
    }

    private static IDictionary<string, ICollection<string>> CreateSupportedFlexContainerPropertiesAndValuesMap()
    {
      Dictionary<string, ICollection<string>> col = new Dictionary<string, ICollection<string>>();
      ICollection<string> strings1 = (ICollection<string>) new HashSet<string>();
      strings1.Add("row");
      strings1.Add("row-reverse");
      strings1.Add("column");
      strings1.Add("column-reverse");
      col.Put<string, ICollection<string>>("flex-direction", strings1);
      ICollection<string> strings2 = (ICollection<string>) new HashSet<string>();
      strings2.Add("stretch");
      strings2.Add("normal");
      col.Put<string, ICollection<string>>("align-content", strings2);
      ICollection<string> strings3 = (ICollection<string>) new HashSet<string>();
      strings3.Add("normal");
      col.Put<string, ICollection<string>>("row-gap", strings3);
      ICollection<string> strings4 = (ICollection<string>) new HashSet<string>();
      strings4.Add("normal");
      col.Put<string, ICollection<string>>("column-gap", strings4);
      return (IDictionary<string, ICollection<string>>) col;
    }
  }
}
