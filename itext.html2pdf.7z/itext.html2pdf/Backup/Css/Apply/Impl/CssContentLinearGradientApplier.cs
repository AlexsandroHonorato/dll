﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.CssContentLinearGradientApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class CssContentLinearGradientApplier : ICssApplier
  {
    private const float DEFAULT_CONTENT_WIDTH_PT = 225f;
    private const float DEFAULT_CONTENT_HEIGHT_PT = 112.5f;

    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      if (elementResult == null)
        return;
      if (elementResult is Div)
      {
        if (!styles.ContainsKey("width") || "auto".Equals(styles.Get<string, string>("width")))
          ((BlockElement<Div>) elementResult).SetWidth(225f);
        if (!styles.ContainsKey("height") || "auto".Equals(styles.Get<string, string>("height")))
          ((BlockElement<Div>) elementResult).SetHeight(112.5f);
      }
      WidthHeightApplierUtil.ApplyWidthHeight(styles, context, elementResult);
      BackgroundApplierUtil.ApplyBackground(styles, context, elementResult);
    }
  }
}
