﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.ColTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl.Tags;
using iText.Html2pdf.Css.Apply.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class ColTagCssApplier : ICssApplier
  {
    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      if (styles == null || !(tagWorker is ColTagWorker))
        return;
      ((ColTagWorker) tagWorker).GetColumn().SetCellCssProps(SupportedColColgroupPropertiesUtil.GetCellProperties(styles)).SetOwnCssProps(SupportedColColgroupPropertiesUtil.GetOwnProperties(styles)).SetWidth(SupportedColColgroupPropertiesUtil.GetWidth(styles, context));
    }
  }
}
