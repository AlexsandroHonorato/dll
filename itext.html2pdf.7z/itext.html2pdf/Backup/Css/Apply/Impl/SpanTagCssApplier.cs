﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.SpanTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl.Tags;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class SpanTagCssApplier : ICssApplier
  {
    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      SpanTagWorker spanTagWorker = (SpanTagWorker) tagWorker;
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      foreach (IPropertyContainer ownLeafElement in (IEnumerable<IPropertyContainer>) spanTagWorker.GetOwnLeafElements())
      {
        if (!(ownLeafElement is IFormField))
          this.ApplyChildElementStyles(ownLeafElement, styles, context, stylesContainer);
      }
      VerticalAlignmentApplierUtil.ApplyVerticalAlignmentForInlines(styles, context, stylesContainer, spanTagWorker.GetAllElements());
      if (styles.ContainsKey("opacity"))
      {
        foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) spanTagWorker.GetAllElements())
        {
          if (allElement is Text && !allElement.HasProperty(92))
            OpacityApplierUtil.ApplyOpacity(styles, context, allElement);
        }
      }
      string str = styles.Get<string, string>("float");
      if (str != null && !"none".Equals(str))
      {
        foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) spanTagWorker.GetAllElements())
        {
          FloatPropertyValue? property = allElement.GetProperty<FloatPropertyValue?>(99);
          if (!property.HasValue || FloatPropertyValue.NONE.Equals((object) property))
            FloatApplierUtil.ApplyFloating(styles, context, allElement);
        }
      }
      if (spanTagWorker.GetAllElements() == null)
        return;
      foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) spanTagWorker.GetAllElements())
      {
        FloatPropertyValue? property = allElement.GetProperty<FloatPropertyValue?>(99);
        if (allElement is Text && !allElement.HasOwnProperty(6) && (!property.HasValue || FloatPropertyValue.NONE.Equals((object) property)))
          BackgroundApplierUtil.ApplyBackground(styles, context, allElement);
      }
    }

    protected internal virtual void ApplyChildElementStyles(
      IPropertyContainer element,
      IDictionary<string, string> css,
      ProcessorContext context,
      IStylesContainer stylesContainer)
    {
      FontStyleApplierUtil.ApplyFontStyles(css, context, stylesContainer, element);
      BackgroundApplierUtil.ApplyBackground(css, context, element);
      BorderStyleApplierUtil.ApplyBorders(css, context, element);
      OutlineApplierUtil.ApplyOutlines(css, context, element);
      HyphenationApplierUtil.ApplyHyphenation(css, context, stylesContainer, element);
      MarginApplierUtil.ApplyMargins(css, context, element);
      PositionApplierUtil.ApplyPosition(css, context, element);
      FloatApplierUtil.ApplyFloating(css, context, element);
      PaddingApplierUtil.ApplyPaddings(css, context, element);
    }
  }
}
