﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.MultiColumnCssApplierUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public sealed class MultiColumnCssApplierUtil
  {
    private MultiColumnCssApplierUtil()
    {
    }

    public static void ApplyMultiCol(
      IDictionary<string, string> cssProps,
      ProcessorContext context,
      IPropertyContainer element)
    {
      int? integer = CssDimensionParsingUtils.ParseInteger(cssProps.Get<string, string>("column-count"));
      if (integer.HasValue)
        element.SetProperty(138, (object) integer);
      float absoluteFontSize = CssDimensionParsingUtils.ParseAbsoluteFontSize(cssProps.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      UnitValue lengthValueToPt1 = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("column-width"), absoluteFontSize, rootFontSize);
      if (lengthValueToPt1 != null)
        element.SetProperty(142, (object) lengthValueToPt1.GetValue());
      UnitValue lengthValueToPt2 = CssDimensionParsingUtils.ParseLengthValueToPt(cssProps.Get<string, string>("column-gap"), absoluteFontSize, rootFontSize);
      if (lengthValueToPt2 != null)
        element.SetProperty(143, (object) lengthValueToPt2.GetValue());
      if (!element.HasProperty(143))
        element.SetProperty(143, (object) CssDimensionParsingUtils.ParseRelativeValue("1em", absoluteFontSize));
      if (!element.HasProperty(138) && !element.HasProperty(142) && ("auto".Equals(cssProps.Get<string, string>("column-count")) || "auto".Equals(cssProps.Get<string, string>("column-width"))))
        element.SetProperty(138, (object) 1);
      Border certainBorder = BorderStyleApplierUtil.GetCertainBorder(cssProps.Get<string, string>("column-rule-width"), cssProps.Get<string, string>("column-rule-style"), MultiColumnCssApplierUtil.GetColumnGapColorOrDefault(cssProps), absoluteFontSize, rootFontSize);
      element.SetProperty(144, (object) certainBorder);
    }

    private static string GetColumnGapColorOrDefault(IDictionary<string, string> styles)
    {
      string gapColorOrDefault = styles.Get<string, string>("column-rule-color");
      if (gapColorOrDefault == null || "currentcolor".Equals(gapColorOrDefault))
        gapColorOrDefault = styles.Get<string, string>("color");
      return gapColorOrDefault;
    }
  }
}
