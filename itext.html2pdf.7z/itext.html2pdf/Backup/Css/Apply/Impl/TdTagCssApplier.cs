﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.TdTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Borders;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class TdTagCssApplier : BlockCssApplier
  {
    public override void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker worker)
    {
      base.Apply(context, stylesContainer, worker);
      IPropertyContainer elementResult = worker.GetElementResult();
      if (elementResult == null)
        return;
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      VerticalAlignmentApplierUtil.ApplyVerticalAlignmentForCells(styles, context, elementResult);
      Border[] bordersArray = BorderStyleApplierUtil.GetBordersArray(styles, CssDimensionParsingUtils.ParseAbsoluteLength(styles.Get<string, string>("font-size")), context.GetCssContext().GetRootFontSize());
      if (bordersArray[0] == null)
        elementResult.SetProperty(13, (object) Border.NO_BORDER);
      if (bordersArray[1] == null)
        elementResult.SetProperty(12, (object) Border.NO_BORDER);
      if (bordersArray[2] == null)
        elementResult.SetProperty(10, (object) Border.NO_BORDER);
      if (bordersArray[3] != null)
        return;
      elementResult.SetProperty(11, (object) Border.NO_BORDER);
    }
  }
}
