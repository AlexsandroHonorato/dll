﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.DefaultCssApplierFactory
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Util;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class DefaultCssApplierFactory : ICssApplierFactory
  {
    private static readonly ICssApplierFactory INSTANCE = (ICssApplierFactory) new DefaultCssApplierFactory();
    private readonly TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator> defaultMapping;

    public DefaultCssApplierFactory()
    {
      this.defaultMapping = new DefaultTagCssApplierMapping().GetDefaultCssApplierMapping();
    }

    public static ICssApplierFactory GetInstance() => DefaultCssApplierFactory.INSTANCE;

    public ICssApplier GetCssApplier(IElementNode tag)
    {
      ICssApplier customCssApplier = this.GetCustomCssApplier(tag);
      if (customCssApplier != null)
        return customCssApplier;
      DefaultTagCssApplierMapping.ICssApplierCreator cssApplierCreator = DefaultCssApplierFactory.GetCssApplierCreator(this.defaultMapping, tag);
      return cssApplierCreator == null ? (ICssApplier) null : cssApplierCreator();
    }

    public virtual ICssApplier GetCustomCssApplier(IElementNode tag) => (ICssApplier) null;

    internal virtual TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator> GetDefaultMapping()
    {
      return this.defaultMapping;
    }

    private static DefaultTagCssApplierMapping.ICssApplierCreator GetCssApplierCreator(
      TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator> mapping,
      IElementNode tag)
    {
      DefaultTagCssApplierMapping.ICssApplierCreator cssApplierCreator = (DefaultTagCssApplierMapping.ICssApplierCreator) null;
      string display = ((IStylesContainer) tag).GetStyles() != null ? ((IStylesContainer) tag).GetStyles().Get<string, string>("display") : (string) null;
      if (display != null)
        cssApplierCreator = (DefaultTagCssApplierMapping.ICssApplierCreator) mapping.GetMapping(tag.Name(), display);
      if (cssApplierCreator == null)
        cssApplierCreator = (DefaultTagCssApplierMapping.ICssApplierCreator) mapping.GetMapping(tag.Name());
      return cssApplierCreator;
    }
  }
}
