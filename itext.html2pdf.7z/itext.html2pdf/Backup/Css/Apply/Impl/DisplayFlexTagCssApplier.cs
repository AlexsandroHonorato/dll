﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.DisplayFlexTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class DisplayFlexTagCssApplier : BlockCssApplier
  {
    public override void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      base.Apply(context, stylesContainer, tagWorker);
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      if (elementResult != null)
      {
        FlexApplierUtil.ApplyFlexContainerProperties(stylesContainer.GetStyles(), elementResult);
        elementResult.DeleteOwnProperty(99);
        elementResult.DeleteOwnProperty(100);
        elementResult.DeleteOwnProperty(103);
        elementResult.DeleteOwnProperty(104);
      }
      MultiColumnCssApplierUtil.ApplyMultiCol(stylesContainer.GetStyles(), context, elementResult);
    }
  }
}
