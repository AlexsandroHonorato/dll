﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.TableTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class TableTagCssApplier : BlockCssApplier
  {
    public override void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker worker)
    {
      base.Apply(context, stylesContainer, worker);
      Table elementResult = (Table) worker.GetElementResult();
      if (elementResult == null)
        return;
      string str1 = stylesContainer.GetStyles().Get<string, string>("table-layout");
      if (str1 != null)
        elementResult.SetProperty(93, (object) str1);
      string str2 = stylesContainer.GetStyles().Get<string, string>("border-collapse");
      if (str2 == null || "separate".Equals(str2))
        elementResult.SetBorderCollapse(BorderCollapsePropertyValue.SEPARATE);
      string str3 = stylesContainer.GetStyles().Get<string, string>("border-spacing");
      if (str3 == null)
        return;
      string[] strArray = StringUtil.Split(str3, "\\s+");
      if (1 == strArray.Length)
      {
        elementResult.SetHorizontalBorderSpacing(CssDimensionParsingUtils.ParseAbsoluteLength(strArray[0]));
        elementResult.SetVerticalBorderSpacing(CssDimensionParsingUtils.ParseAbsoluteLength(strArray[0]));
      }
      else
      {
        if (2 != strArray.Length)
          return;
        elementResult.SetHorizontalBorderSpacing(CssDimensionParsingUtils.ParseAbsoluteLength(strArray[0]));
        elementResult.SetVerticalBorderSpacing(CssDimensionParsingUtils.ParseAbsoluteLength(strArray[1]));
      }
    }
  }
}
