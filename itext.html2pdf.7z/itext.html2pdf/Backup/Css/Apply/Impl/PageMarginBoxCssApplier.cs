﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.PageMarginBoxCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Kernel.Geom;
using iText.Layout;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class PageMarginBoxCssApplier : ICssApplier
  {
    public static float[] ParseBoxProps(
      IDictionary<string, string> styles,
      float em,
      float rem,
      float[] defaultValues,
      Rectangle containingBlock,
      string topPropName,
      string rightPropName,
      string bottomPropName,
      string leftPropName)
    {
      string valString1 = styles.Get<string, string>(topPropName);
      string valString2 = styles.Get<string, string>(rightPropName);
      string valString3 = styles.Get<string, string>(bottomPropName);
      string valString4 = styles.Get<string, string>(leftPropName);
      double em1 = (double) em;
      double rem1 = (double) rem;
      double height = (double) containingBlock.GetHeight();
      float? boxValue1 = PageMarginBoxCssApplier.ParseBoxValue(valString1, (float) em1, (float) rem1, (float) height);
      float? boxValue2 = PageMarginBoxCssApplier.ParseBoxValue(valString2, em, rem, containingBlock.GetWidth());
      float? boxValue3 = PageMarginBoxCssApplier.ParseBoxValue(valString3, em, rem, containingBlock.GetHeight());
      float? boxValue4 = PageMarginBoxCssApplier.ParseBoxValue(valString4, em, rem, containingBlock.GetWidth());
      return new float[4]
      {
        boxValue1.HasValue ? boxValue1.Value : defaultValues[0],
        boxValue2.HasValue ? boxValue2.Value : defaultValues[1],
        boxValue3.HasValue ? boxValue3.Value : defaultValues[2],
        boxValue4.HasValue ? boxValue4.Value : defaultValues[3]
      };
    }

    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      BackgroundApplierUtil.ApplyBackground(styles, context, elementResult);
      FontStyleApplierUtil.ApplyFontStyles(styles, context, stylesContainer, elementResult);
      BorderStyleApplierUtil.ApplyBorders(styles, context, elementResult);
      VerticalAlignmentApplierUtil.ApplyVerticalAlignmentForCells(styles, context, elementResult);
      string str1 = CssConstants.OVERFLOW_VALUES.Contains(styles.Get<string, string>("overflow")) ? styles.Get<string, string>("overflow") : (string) null;
      string str2 = CssConstants.OVERFLOW_VALUES.Contains(styles.Get<string, string>("overflow-x")) ? styles.Get<string, string>("overflow-x") : str1;
      if (str2 == null || "hidden".Equals(str2))
        elementResult.SetProperty(103, (object) OverflowPropertyValue.HIDDEN);
      else
        elementResult.SetProperty(103, (object) OverflowPropertyValue.VISIBLE);
      string str3 = CssConstants.OVERFLOW_VALUES.Contains(styles.Get<string, string>("overflow-y")) ? styles.Get<string, string>("overflow-y") : str1;
      if (str3 == null || "hidden".Equals(str3))
        elementResult.SetProperty(104, (object) OverflowPropertyValue.HIDDEN);
      else
        elementResult.SetProperty(104, (object) OverflowPropertyValue.VISIBLE);
      OutlineApplierUtil.ApplyOutlines(styles, context, elementResult);
      elementResult.SetProperty(91, (object) context.GetFontProvider());
      elementResult.SetProperty(98, (object) context.GetTempFonts());
      if (!(stylesContainer is PageMarginBoxContextNode))
      {
        LoggerExtensions.LogWarning(ITextLogManager.GetLogger(typeof (PageMarginBoxCssApplier)), "Page margin box margin, padding, height and width properties are not processed. Passed styles container shall be of PageMarginBoxContextNode type.", Array.Empty<object>());
      }
      else
      {
        float width = ((PageMarginBoxContextNode) stylesContainer).GetContainingBlockForMarginBox().GetWidth();
        float height = ((PageMarginBoxContextNode) stylesContainer).GetContainingBlockForMarginBox().GetHeight();
        MarginApplierUtil.ApplyMargins(styles, context, elementResult, height, width);
        PaddingApplierUtil.ApplyPaddings(styles, context, elementResult, height, width);
      }
    }

    private static float? ParseBoxValue(
      string valString,
      float em,
      float rem,
      float dimensionSize)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(valString, em, rem);
      if (lengthValueToPt != null)
      {
        if (lengthValueToPt.IsPointValue())
          return new float?(lengthValueToPt.GetValue());
        if (lengthValueToPt.IsPercentValue())
          return new float?((float) ((double) lengthValueToPt.GetValue() * (double) dimensionSize / 100.0));
      }
      return new float?();
    }
  }
}
