﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.BodyTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class BodyTagCssApplier : ICssApplier
  {
    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      BodyHtmlStylesContainer element = new BodyHtmlStylesContainer();
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      if (elementResult == null)
        return;
      BackgroundApplierUtil.ApplyBackground(styles, context, (IPropertyContainer) element);
      MarginApplierUtil.ApplyMargins(styles, context, (IPropertyContainer) element);
      PaddingApplierUtil.ApplyPaddings(styles, context, (IPropertyContainer) element);
      BorderStyleApplierUtil.ApplyBorders(styles, context, (IPropertyContainer) element);
      if (element.HasStylesToApply())
        elementResult.SetProperty(1048579, (object) element);
      FontStyleApplierUtil.ApplyFontStyles(styles, context, stylesContainer, elementResult);
    }
  }
}
