﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.DefaultTagCssApplierMapping
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Util;
using iText.StyledXmlParser.Css.Pseudo;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  internal class DefaultTagCssApplierMapping
  {
    private static TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator> mapping = new TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator>();

    internal DefaultTagCssApplierMapping()
    {
    }

    static DefaultTagCssApplierMapping()
    {
      DefaultTagCssApplierMapping.mapping.PutMapping("a", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("abbr", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("address", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("article", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("aside", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("b", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("bdi", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("bdo", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("blockquote", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("body", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BodyTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("button", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("caption", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new CaptionCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("center", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("cite", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("code", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("col", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new ColTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("colgroup", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new ColgroupTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dd", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("del", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dfn", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dl", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new DlTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dt", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("em", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("fieldset", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("figcaption", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("figure", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("font", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("footer", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("form", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h1", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h2", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h3", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h4", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h5", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("h6", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("header", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("hr", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new HrTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("html", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new HtmlTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("i", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("img", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("input", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("ins", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("kbd", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("label", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("legend", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("li", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new LiTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("main", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("mark", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("nav", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("object", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("ol", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new UlOlTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("optgroup", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("option", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("p", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("pre", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("q", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("s", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("samp", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("section", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("select", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("small", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("span", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("strike", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("strong", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("sub", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("sup", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("svg", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("table", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TableTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("textarea", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("td", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TdTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("tfoot", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("th", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TdTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("thead", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("time", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("tr", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TrTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("tt", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("u", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("ul", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new UlOlTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("var", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      string pseudoElementTagName1 = CssPseudoElementUtil.CreatePseudoElementTagName("placeholder");
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName1, (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new PlaceholderCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", "inline", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("ul", "inline", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("li", "inline", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("li", "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("li", "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dd", "inline", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("dt", "inline", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("span", "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("span", "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("a", "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("a", "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("a", "table-cell", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("label", "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("label", "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", "table", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TableTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", "table-cell", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new TdTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", "table-row", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new DisplayTableRowTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("div", "flex", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new DisplayFlexTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("span", "flex", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new DisplayFlexTagCssApplier()));
      string pseudoElementTagName2 = CssPseudoElementUtil.CreatePseudoElementTagName("before");
      string pseudoElementTagName3 = CssPseudoElementUtil.CreatePseudoElementTagName("after");
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName2, (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName3, (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName2, "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName3, "inline-block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName2, "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName3, "block", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName2, "table", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(pseudoElementTagName3, "table", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(CssPseudoElementUtil.CreatePseudoElementTagName("img"), (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new BlockCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping(CssPseudoElementUtil.CreatePseudoElementTagName("div"), (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new CssContentLinearGradientApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("_e0d00a6_page-counter", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new SpanTagCssApplier()));
      DefaultTagCssApplierMapping.mapping.PutMapping("_064ef03_page-margin-box", (DefaultTagCssApplierMapping.ICssApplierCreator) (() => (ICssApplier) new PageMarginBoxCssApplier()));
    }

    internal virtual TagProcessorMapping<DefaultTagCssApplierMapping.ICssApplierCreator> GetDefaultCssApplierMapping()
    {
      return DefaultTagCssApplierMapping.mapping;
    }

    public delegate ICssApplier ICssApplierCreator();
  }
}
