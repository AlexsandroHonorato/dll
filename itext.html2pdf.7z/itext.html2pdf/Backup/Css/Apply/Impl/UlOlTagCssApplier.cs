﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.UlOlTagCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class UlOlTagCssApplier : BlockCssApplier
  {
    public override void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      if (!(tagWorker.GetElementResult() is List) && !(tagWorker.GetElementResult() is MulticolContainer))
        return;
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      if ("inside".Equals(styles.Get<string, string>("list-style-position")))
        elementResult.SetProperty(83, (object) ListSymbolPosition.INSIDE);
      else
        elementResult.SetProperty(83, (object) ListSymbolPosition.OUTSIDE);
      ListStyleApplierUtil.ApplyListStyleTypeProperty(stylesContainer, styles, context, elementResult);
      ListStyleApplierUtil.ApplyListStyleImageProperty(styles, context, elementResult);
      MultiColumnCssApplierUtil.ApplyMultiCol(styles, context, elementResult);
      base.Apply(context, stylesContainer, tagWorker);
      bool flag = BaseDirection.RIGHT_TO_LEFT.Equals((object) elementResult.GetProperty<BaseDirection?>(7));
      if ((!flag || elementResult.HasProperty(49)) && (flag || elementResult.HasProperty(48)))
        return;
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(styles.Get<string, string>("font-size"));
      float rootFontSize = context.GetCssContext().GetRootFontSize();
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(styles.Get<string, string>("padding-inline-start"), absoluteLength, rootFontSize);
      elementResult.SetProperty(flag ? 49 : 48, (object) lengthValueToPt);
    }
  }
}
