﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.BlockCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Impl.Tags;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Node.Impl.Jsoup.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class BlockCssApplier : ICssApplier
  {
    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      IPropertyContainer elementResult = tagWorker.GetElementResult();
      if (elementResult == null)
        return;
      WidthHeightApplierUtil.ApplyWidthHeight(styles, context, elementResult);
      BackgroundApplierUtil.ApplyBackground(styles, context, elementResult);
      MarginApplierUtil.ApplyMargins(styles, context, elementResult);
      PaddingApplierUtil.ApplyPaddings(styles, context, elementResult);
      FontStyleApplierUtil.ApplyFontStyles(styles, context, stylesContainer, elementResult);
      BorderStyleApplierUtil.ApplyBorders(styles, context, elementResult);
      HyphenationApplierUtil.ApplyHyphenation(styles, context, stylesContainer, elementResult);
      PositionApplierUtil.ApplyPosition(styles, context, elementResult);
      OpacityApplierUtil.ApplyOpacity(styles, context, elementResult);
      PageBreakApplierUtil.ApplyPageBreakProperties(styles, context, elementResult);
      OverflowApplierUtil.ApplyOverflow(styles, elementResult);
      TransformationApplierUtil.ApplyTransformation(styles, context, elementResult);
      OutlineApplierUtil.ApplyOutlines(styles, context, elementResult);
      OrphansWidowsApplierUtil.ApplyOrphansAndWidows(styles, elementResult);
      VerticalAlignmentApplierUtil.ApplyVerticalAlignmentForBlocks(styles, elementResult, BlockCssApplier.IsInlineItem(tagWorker));
      MultiColumnCssApplierUtil.ApplyMultiCol(styles, context, elementResult);
      if (BlockCssApplier.IsFlexItem(stylesContainer))
        FlexApplierUtil.ApplyFlexItemProperties(styles, context, elementResult);
      else
        FloatApplierUtil.ApplyFloating(styles, context, elementResult);
    }

    private static bool IsInlineItem(ITagWorker tagWorker)
    {
      return tagWorker is SpanTagWorker || tagWorker is ImgTagWorker;
    }

    private static bool IsFlexItem(IStylesContainer stylesContainer)
    {
      return stylesContainer is JsoupElementNode && ((JsoupNode) stylesContainer).ParentNode() is JsoupElementNode && "flex".Equals(((JsoupElementNode) ((JsoupNode) stylesContainer).ParentNode()).GetStyles().Get<string, string>("display"));
    }
  }
}
