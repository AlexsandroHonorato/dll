﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.Apply.Impl.PlaceholderCssApplier
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css.Apply.Impl
{
  public class PlaceholderCssApplier : ICssApplier
  {
    public virtual void Apply(
      ProcessorContext context,
      IStylesContainer stylesContainer,
      ITagWorker tagWorker)
    {
      IDictionary<string, string> styles = stylesContainer.GetStyles();
      IStylesContainer stylesContainer1 = (IStylesContainer) ((CssContextNode) stylesContainer).ParentNode();
      IPropertyContainer elementResult = context.GetState().Top().GetElementResult();
      if (!(elementResult is IPlaceholderable))
        return;
      IPropertyContainer placeholder = (IPropertyContainer) ((IPlaceholderable) elementResult).GetPlaceholder();
      FontStyleApplierUtil.ApplyFontStyles(styles, context, stylesContainer1, placeholder);
      BackgroundApplierUtil.ApplyBackground(styles, context, placeholder);
      OpacityApplierUtil.ApplyOpacity(styles, context, placeholder);
    }
  }
}
