﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Css.CssConstants
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser.Css;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Css
{
  public class CssConstants : CommonCssConstants
  {
    public const string BLEED = "bleed";
    public const string BOTH = "both";
    public const string BOX_SIZING = "box-sizing";
    public const string CLEAR = "clear";
    public const string CONTENT = "content";
    public const string COUNTER_INCREMENT = "counter-increment";
    public const string COUNTER_RESET = "counter-reset";
    public const string DISPLAY = "display";
    public const string LIST_ITEM = "list-item";
    public const string MARKS = "marks";
    public const string MAX_HEIGHT = "max-height";
    public const string MAX_WIDTH = "max-width";
    public const string MIN_WIDTH = "min-width";
    public const string OBJECT_FIT = "object-fit";
    public const string OUTLINE_OFFSET = "outline-offset";
    public const string OVERFLOW_X = "overflow-x";
    public const string OVERFLOW_Y = "overflow-y";
    public const string PADDING_INLINE_START = "padding-inline-start";
    public const string PLACEHOLDER = "placeholder";
    public const string SIZE = "size";
    public const string STYLE = "style";
    public const string TABLE_LAYOUT = "table-layout";
    public const string VERTICAL_ALIGN = "vertical-align";
    public const string ABSOLUTE = "absolute";
    public const string BLINK = "blink";
    public const string BLOCK = "block";
    public const string CAPITALIZE = "capitalize";
    public const string CONTENTS = "contents";
    public const string COLLAPSE = "collapse";
    public const string CROP = "crop";
    public const string CROSS = "cross";
    public const string FILL = "fill";
    public const string FIRST = "first";
    public const string FIRST_EXCEPT = "first-except";
    public const string GRID = "grid";
    public const string INLINE = "inline";
    public const string INLINE_BLOCK = "inline-block";
    public const string INLINE_FLEX = "INLINE_FLEX";
    public const string INLINE_GRID = "INLINE_GRID";
    public const string INLINE_TABLE = "inline-table";
    public const string INVERT = "invert";
    public const string JUSTIFY = "justify";
    public const string LANDSCAPE = "landscape";
    public const string LAST = "last";
    public const string LINE_THROUGH = "line-through";
    public const string LOWERCASE = "lowercase";
    public const string LTR = "ltr";
    public const string MIDDLE = "middle";
    public const string NOWRAP = "nowrap";
    public const string OVERLINE = "overline";
    public const string PAGE = "page";
    public const string PAGES = "pages";
    public const string PORTRAIT = "portrait";
    public const string PRE = "pre";
    public const string PRE_LINE = "pre-line";
    public const string PRE_WRAP = "pre-wrap";
    public const string RELATIVE = "relative";
    public const string RUN_IN = "run-in";
    public const string RTL = "rtl";
    public const string SCALE_DOWN = "scale-down";
    public const string SEPARATE = "separate";
    public const string SUB = "sub";
    public const string SUPER = "super";
    public const string TABLE = "table";
    public const string TABLE_CAPTION = "table-caption";
    public const string TABLE_CELL = "table-cell";
    public const string TABLE_COLUMN = "table-column";
    public const string TABLE_COLUMN_GROUP = "table-column-group";
    public const string TABLE_FOOTER_GROUP = "table-footer-group";
    public const string TABLE_HEADER_GROUP = "table-header-group";
    public const string TABLE_ROW = "table-row";
    public const string TABLE_ROW_GROUP = "table-row-group";
    public const string TEXT_BOTTOM = "text-bottom";
    public const string TEXT_TOP = "text-top";
    public const string UNDERLINE = "underline";
    public const string UPPERCASE = "uppercase";
    public static readonly ICollection<string> OVERFLOW_VALUES = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[4]
    {
      "visible",
      "hidden",
      "scroll",
      "auto"
    })));
    public const string AFTER = "after";
    public const string BEFORE = "before";
    public const string FIRST_LETTER = "first-letter";
    public const string FIRST_LINE = "first-line";
    public const string SELECTION = "selection";
    public const string COUNTER = "counter";
    public const string COUNTERS = "counters";
    public const string ELEMENT = "element";
    public const string RUNNING = "running";
    public const string TARGET_COUNTER = "target-counter";
    public const string TARGET_COUNTERS = "target-counters";
    public const string DPI = "dpi";
  }
}
