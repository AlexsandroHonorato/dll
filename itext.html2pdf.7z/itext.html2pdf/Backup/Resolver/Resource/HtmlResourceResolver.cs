﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Resolver.Resource.HtmlResourceResolver
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Util;
using iText.Kernel.Pdf.Xobject;
using iText.StyledXmlParser.Resolver.Resource;
using iText.Svg.Converter;
using iText.Svg.Processors;
using iText.Svg.Processors.Impl;
using System;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

#nullable disable
namespace iText.Html2pdf.Resolver.Resource
{
  public class HtmlResourceResolver : ResourceResolver
  {
    private const string SVG_PREFIX = "data:image/svg+xml";
    private static readonly Regex SVG_IDENTIFIER_PATTERN = StringUtil.RegexCompile(",[\\s]*(<svg )");
    private readonly ProcessorContext context;

    public HtmlResourceResolver(string baseUri, ProcessorContext context)
      : this(baseUri, context, (IResourceRetriever) null)
    {
    }

    public HtmlResourceResolver(
      string baseUri,
      ProcessorContext context,
      IResourceRetriever retriever)
      : base(baseUri, retriever)
    {
      this.context = context;
    }

    public virtual PdfXObject RetrieveImage(string src)
    {
      if (src != null && src.Trim().StartsWith("data:image/svg+xml") && Matcher.Match(HtmlResourceResolver.SVG_IDENTIFIER_PATTERN, src).Find())
      {
        PdfXObject pdfXobject = this.TryResolveSvgImageSource(src);
        if (pdfXobject != null)
          return pdfXobject;
      }
      return base.RetrieveImage(src);
    }

    protected virtual PdfXObject TryResolveBase64ImageSource(string src)
    {
      string str = StringUtil.ReplaceAll(src, "\\s", "");
      if (str.StartsWith("data:image/svg+xml"))
      {
        string s = str.Substring(str.IndexOf("base64", StringComparison.Ordinal) + "base64".Length + 1);
        try
        {
          using (MemoryStream memoryStream = new MemoryStream(Convert.FromBase64String(s)))
          {
            PdfFormXObject pdfFormXobject = HtmlResourceResolver.ProcessAsSvg((Stream) memoryStream, this.context, (string) null);
            if (pdfFormXobject != null)
              return (PdfXObject) pdfFormXobject;
          }
        }
        catch (Exception ex)
        {
        }
      }
      return base.TryResolveBase64ImageSource(src);
    }

    protected virtual PdfXObject CreateImageByUrl(Uri url)
    {
      try
      {
        return base.CreateImageByUrl(url);
      }
      catch (Exception ex)
      {
        using (Stream inputStreamByUrl = this.GetRetriever().GetInputStreamByUrl(url))
          return inputStreamByUrl == null ? (PdfXObject) null : (PdfXObject) HtmlResourceResolver.ProcessAsSvg(inputStreamByUrl, this.context, FileUtil.ParentDirectory(url));
      }
    }

    private PdfXObject TryResolveSvgImageSource(string src)
    {
      try
      {
        using (MemoryStream memoryStream = new MemoryStream(src.GetBytes(Encoding.UTF8)))
        {
          PdfFormXObject pdfFormXobject = HtmlResourceResolver.ProcessAsSvg((Stream) memoryStream, this.context, (string) null);
          if (pdfFormXobject != null)
            return (PdfXObject) pdfFormXobject;
        }
      }
      catch (Exception ex)
      {
      }
      return (PdfXObject) null;
    }

    private static PdfFormXObject ProcessAsSvg(
      Stream stream,
      ProcessorContext context,
      string parentDir)
    {
      SvgConverterProperties converterProperties = ContextMappingHelper.MapToSvgConverterProperties(context);
      if (parentDir != null)
        converterProperties.SetBaseUri(parentDir);
      ISvgProcessorResult andProcess = SvgConverter.ParseAndProcess(stream, (ISvgConverterProperties) converterProperties);
      return new SvgProcessingUtil(context.GetResourceResolver()).CreateXObjectFromProcessingResult(andProcess, context.GetPdfDocument());
    }
  }
}
