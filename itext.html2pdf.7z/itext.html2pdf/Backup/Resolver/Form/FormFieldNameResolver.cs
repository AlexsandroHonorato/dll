﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Resolver.Form.FormFieldNameResolver
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Css.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Resolver.Form
{
  public class FormFieldNameResolver
  {
    private const string DEFAULT_NAME = "Field";
    private const string NAME_COUNT_SEPARATOR = "_";
    private readonly IDictionary<string, int?> names = (IDictionary<string, int?>) new Dictionary<string, int?>();

    public virtual string ResolveFormName(string name)
    {
      name = this.NormalizeString(name);
      return string.IsNullOrEmpty(name) ? this.ResolveNormalizedFormName("Field") : this.ResolveNormalizedFormName(name);
    }

    public virtual void Reset() => this.names.Clear();

    private string NormalizeString(string s) => s == null ? "" : s.Trim().Replace(".", "");

    private string ResolveNormalizedFormName(string name)
    {
      int endIndex = name.LastIndexOf("_");
      int? nullable1 = new int?();
      if (endIndex != -1 && endIndex < name.Length)
      {
        nullable1 = CssDimensionParsingUtils.ParseInteger(name.Substring(endIndex + 1));
        if (nullable1.HasValue)
        {
          int? nullable2 = nullable1;
          int num = 0;
          if (nullable2.GetValueOrDefault() > num & nullable2.HasValue)
            name = name.JSubstring(0, endIndex);
        }
      }
      int? nullable3 = this.names.Get<string, int?>(name);
      int num1 = nullable3.HasValue ? nullable3.Value + 1 : 0;
      if (nullable1.HasValue && num1 < nullable1.Value)
        num1 = nullable1.Value;
      this.names.Put<string, int?>(name, new int?(num1));
      return num1 != 0 ? name + "_" + num1.ToString() : name;
    }
  }
}
