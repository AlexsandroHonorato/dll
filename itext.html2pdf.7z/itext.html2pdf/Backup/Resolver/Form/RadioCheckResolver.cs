﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Resolver.Form.RadioCheckResolver
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Layout;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Resolver.Form
{
  public class RadioCheckResolver
  {
    private readonly IDictionary<string, Radio> @checked = (IDictionary<string, Radio>) new Dictionary<string, Radio>();

    public virtual void CheckField(string radioGroupName, Radio checkedField)
    {
      ((ElementPropertyContainer<Radio>) this.@checked.Get<string, Radio>(radioGroupName))?.DeleteOwnProperty(2097159);
      this.@checked.Put<string, Radio>(radioGroupName, checkedField);
    }
  }
}
