﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Resolver.Font.DefaultFontProvider
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.IO.Util;
using iText.Layout.Font;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Resolver.Font;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.IO;

#nullable disable
namespace iText.Html2pdf.Resolver.Font
{
  public class DefaultFontProvider : BasicFontProvider
  {
    internal const string SHIPPED_FONT_RESOURCE_PATH = "iText.Html2Pdf.font.";
    internal static readonly string[] SHIPPED_FONT_NAMES = new string[10]
    {
      "NotoSansMono-Regular.ttf",
      "NotoSansMono-Bold.ttf",
      "NotoSans-Regular.ttf",
      "NotoSans-Bold.ttf",
      "NotoSans-BoldItalic.ttf",
      "NotoSans-Italic.ttf",
      "NotoSerif-Regular.ttf",
      "NotoSerif-Bold.ttf",
      "NotoSerif-BoldItalic.ttf",
      "NotoSerif-Italic.ttf"
    };
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (DefaultFontProvider));
    private const string DEFAULT_FONT_FAMILY = "Times";
    private static readonly Range FREE_FONT_RANGE = new RangeBuilder().AddRange(0, 1423).AddRange(3712, int.MaxValue).Create();
    private IList<byte[]> calligraphyFontsTempList = (IList<byte[]>) new List<byte[]>();

    public DefaultFontProvider()
      : this(true, true, false)
    {
    }

    public DefaultFontProvider(
      bool registerStandardPdfFonts,
      bool registerShippedFonts,
      bool registerSystemFonts)
      : this(registerStandardPdfFonts, registerShippedFonts, registerSystemFonts, "Times")
    {
    }

    public DefaultFontProvider(
      bool registerStandardPdfFonts,
      bool registerShippedFonts,
      bool registerSystemFonts,
      string defaultFontFamily)
      : base(registerStandardPdfFonts, registerSystemFonts, defaultFontFamily)
    {
      if (!registerShippedFonts)
        return;
      this.AddAllAvailableFonts(this.AddCalligraphFonts());
    }

    private void AddAllAvailableFonts(Range rangeToLoad)
    {
      this.AddShippedFonts(rangeToLoad);
      foreach (byte[] calligraphyFontsTemp in (IEnumerable<byte[]>) this.calligraphyFontsTempList)
        ((FontProvider) this).AddFont(calligraphyFontsTemp, (string) null);
      this.calligraphyFontsTempList = (IList<byte[]>) null;
    }

    private void AddShippedFonts(Range rangeToLoad)
    {
      foreach (string str in DefaultFontProvider.SHIPPED_FONT_NAMES)
      {
        try
        {
          using (Stream resourceStream = ResourceUtil.GetResourceStream("iText.Html2Pdf.font." + str))
            ((FontProvider) this).AddFont(StreamUtil.InputStreamToArray(resourceStream), (string) null, rangeToLoad);
        }
        catch (Exception ex)
        {
          LoggerExtensions.LogError(DefaultFontProvider.LOGGER, "Error while loading font", Array.Empty<object>());
        }
      }
    }

    protected internal virtual Range AddCalligraphFonts()
    {
      if (TypographyUtils.IsPdfCalligraphAvailable())
      {
        try
        {
          this.calligraphyFontsTempList.AddAll<byte[]>((IEnumerable<byte[]>) TypographyUtils.LoadShippedFonts().Values);
          return DefaultFontProvider.FREE_FONT_RANGE;
        }
        catch (Exception ex)
        {
          LoggerExtensions.LogError(DefaultFontProvider.LOGGER, "Error while loading font", Array.Empty<object>());
        }
      }
      return (Range) null;
    }
  }
}
