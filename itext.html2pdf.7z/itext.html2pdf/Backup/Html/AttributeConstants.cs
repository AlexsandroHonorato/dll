﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Html.AttributeConstants
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.StyledXmlParser;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Html
{
  public sealed class AttributeConstants : CommonAttributeConstants
  {
    public const string ALIGN = "align";
    public const string ALT = "alt";
    public const string APPLICATION_NAME = "application-name";
    public const string AUTHOR = "author";
    public const string BGCOLOR = "bgcolor";
    public const string BORDER = "border";
    public const string CELLPADDING = "cellpadding";
    public const string CELLSPACING = "cellspacing";
    public const string COLOR = "color";
    public const string COL = "col";
    public const string COLGROUP = "colgroup";
    public const string COLS = "cols";
    public const string COLSPAN = "colspan";
    public const string CONTENT = "content";
    public const string DATA = "data";
    public const string DESCRIPTION = "description";
    public const string DIR = "dir";
    public const string FACE = "face";
    public const string HEIGHT = "height";
    public const string HREF = "href";
    public const string HSPACE = "hspace";
    public const string ID = "id";
    public const string KEYWORDS = "keywords";
    public const string LABEL = "label";
    public const string LANG = "lang";
    public const string MEDIA = "media";
    public const string MULTIPLE = "multiple";
    public const string NAME = "name";
    public const string NOSHADE = "noshade";
    public const string NOWRAP = "nowrap";
    public const string NUMBER = "number";
    public const string ROW = "row";
    public const string ROWGROUP = "rowgroup";
    public const string ROWS = "rows";
    public const string ROWSPAN = "rowspan";
    public const string SCOPE = "scope";
    public const string SELECTED = "selected";
    public const string SIZE = "size";
    public const string SPAN = "span";
    public const string SRC = "src";
    public const string STYLE = "style";
    public const string TYPE = "type";
    public const string VALIGN = "valign";
    public const string VALUE = "value";
    public const string VSPACE = "vspace";
    public const string WIDTH = "width";
    public const string TITLE = "title";
    public const string _1 = "1";
    public const string A = "A";
    public const string a = "a";
    public const string BOTTOM = "bottom";
    public const string BUTTON = "button";
    public const string CENTER = "center";
    public const string CHECKBOX = "checkbox";
    public const string CHECKED = "checked";
    public const string DATE = "date";
    public const string DATETIME = "datetime";
    public const string DATETIME_LOCAL = "datetime_local";
    public const string EMAIL = "email";
    public const string FILE = "file";
    public const string HIDDEN = "hidden";
    public const string I = "I";
    public const string i = "i";
    public const string IMAGE = "image";
    public const string LEFT = "left";
    public const string LTR = "ltr";
    public const string MIDDLE = "middle";
    public const string MONTH = "month";
    public const string PASSWORD = "password";
    public const string PLACEHOLDER = "placeholder";
    public const string RADIO = "radio";
    public const string RANGE = "range";
    public const string RESET = "reset";
    public const string RIGHT = "right";
    public const string RTL = "rtl";
    public const string SEARCH = "search";
    public const string START = "start";
    public const string SUBMIT = "submit";
    public const string TEL = "tel";
    public const string TEXT = "text";
    public const string TIME = "time";
    public const string TOP = "top";
    public const string URL = "url";
    public const string WEEK = "week";
    public static readonly ICollection<string> INPUT_TYPE_VALUES = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[23]
    {
      "button",
      "checkbox",
      "color",
      "date",
      "datetime",
      "datetime_local",
      "email",
      "file",
      "hidden",
      "image",
      "month",
      "number",
      "password",
      "radio",
      "range",
      "reset",
      "search",
      "submit",
      "tel",
      "text",
      "time",
      "url",
      "week"
    })));

    private AttributeConstants()
    {
    }

    public sealed class ObjectTypes
    {
      public const string SVGIMAGE = "image/svg+xml";
    }
  }
}
