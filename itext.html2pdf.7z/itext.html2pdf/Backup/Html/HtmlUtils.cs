﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Html.HtmlUtils
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Kernel.Numbering;

#nullable disable
namespace iText.Html2pdf.Html
{
  public sealed class HtmlUtils
  {
    private const string DISC_SYMBOL = "•";
    private const string CIRCLE_SYMBOL = "◦";
    private const string SQUARE_SYMBOL = "■";
    private const string LATIN_NUMERALS = "abcdefghijklmnopqrstuvwxyz";
    private const string GREEK_NUMERALS = "αβγδεζηθικλμνξοπρστυφχψω";
    private const string ROMAN_NUMERALS = "ivxlcdm";
    private const string GEORGIAN_NUMERALS = "აბგდევზჱთიკლმნჲოპჟრსტჳფქღყშჩცძწჭხჴჯჰჵ";
    private const string ARMENIAN_NUMERALS = "ԱԲԳԴԵԶԷԸԹԺԻԼԽԾԿՀՁՂՃՄՅՆՇՈՉՊՋՌՍՎՏՐՑՒՓՔ";
    private const string DEFAULT_NUMERALS = "1234567890";
    private const int MAX_ROMAN_NUMBER = 3999;

    private HtmlUtils()
    {
    }

    public static string ConvertNumberAccordingToGlyphStyle(
      CounterDigitsGlyphStyle glyphStyle,
      int number)
    {
      switch (glyphStyle)
      {
        case CounterDigitsGlyphStyle.NONE:
          return "";
        case CounterDigitsGlyphStyle.DISC:
          return "•";
        case CounterDigitsGlyphStyle.SQUARE:
          return "■";
        case CounterDigitsGlyphStyle.CIRCLE:
          return "◦";
        case CounterDigitsGlyphStyle.UPPER_ALPHA_AND_LATIN:
          return number <= 0 ? HtmlUtils.ConvertNumberDefault(number) : EnglishAlphabetNumbering.ToLatinAlphabetNumberUpperCase(number);
        case CounterDigitsGlyphStyle.LOWER_ALPHA_AND_LATIN:
          return number <= 0 ? HtmlUtils.ConvertNumberDefault(number) : EnglishAlphabetNumbering.ToLatinAlphabetNumberLowerCase(number);
        case CounterDigitsGlyphStyle.LOWER_GREEK:
          return number <= 0 ? HtmlUtils.ConvertNumberDefault(number) : GreekAlphabetNumbering.ToGreekAlphabetNumberLowerCase(number);
        case CounterDigitsGlyphStyle.LOWER_ROMAN:
          return number > 3999 ? HtmlUtils.ConvertNumberDefault(number) : RomanNumbering.ToRomanLowerCase(number);
        case CounterDigitsGlyphStyle.UPPER_ROMAN:
          return number > 3999 ? HtmlUtils.ConvertNumberDefault(number) : RomanNumbering.ToRomanUpperCase(number);
        case CounterDigitsGlyphStyle.GEORGIAN:
          return GeorgianNumbering.ToGeorgian(number);
        case CounterDigitsGlyphStyle.ARMENIAN:
          return ArmenianNumbering.ToArmenian(number);
        case CounterDigitsGlyphStyle.DECIMAL_LEADING_ZERO:
          return (number < 10 ? "0" : "") + HtmlUtils.ConvertNumberDefault(number);
        default:
          return HtmlUtils.ConvertNumberDefault(number);
      }
    }

    private static string ConvertNumberDefault(int number) => number.ToString();

    public static string GetAllNumberGlyphsForStyle(CounterDigitsGlyphStyle glyphStyle)
    {
      switch (glyphStyle)
      {
        case CounterDigitsGlyphStyle.NONE:
          return "";
        case CounterDigitsGlyphStyle.DISC:
          return "•";
        case CounterDigitsGlyphStyle.SQUARE:
          return "■";
        case CounterDigitsGlyphStyle.CIRCLE:
          return "◦";
        case CounterDigitsGlyphStyle.UPPER_ALPHA_AND_LATIN:
          return "abcdefghijklmnopqrstuvwxyz".ToUpperInvariant();
        case CounterDigitsGlyphStyle.LOWER_ALPHA_AND_LATIN:
          return "abcdefghijklmnopqrstuvwxyz";
        case CounterDigitsGlyphStyle.LOWER_GREEK:
          return "αβγδεζηθικλμνξοπρστυφχψω";
        case CounterDigitsGlyphStyle.LOWER_ROMAN:
          return "ivxlcdm";
        case CounterDigitsGlyphStyle.UPPER_ROMAN:
          return "ivxlcdm".ToUpperInvariant();
        case CounterDigitsGlyphStyle.GEORGIAN:
          return "აბგდევზჱთიკლმნჲოპჟრსტჳფქღყშჩცძწჭხჴჯჰჵ";
        case CounterDigitsGlyphStyle.ARMENIAN:
          return "ԱԲԳԴԵԶԷԸԹԺԻԼԽԾԿՀՁՂՃՄՅՆՇՈՉՊՋՌՍՎՏՐՑՒՓՔ";
        default:
          return "1234567890";
      }
    }

    public static CounterDigitsGlyphStyle ConvertStringCounterGlyphStyleToEnum(string glyphStyle)
    {
      switch (glyphStyle)
      {
        case "armenian":
          return CounterDigitsGlyphStyle.ARMENIAN;
        case "circle":
          return CounterDigitsGlyphStyle.CIRCLE;
        case "decimal-leading-zero":
          return CounterDigitsGlyphStyle.DECIMAL_LEADING_ZERO;
        case "disc":
          return CounterDigitsGlyphStyle.DISC;
        case "georgian":
          return CounterDigitsGlyphStyle.GEORGIAN;
        case "lower-alpha":
        case "lower-latin":
          return CounterDigitsGlyphStyle.LOWER_ALPHA_AND_LATIN;
        case "lower-greek":
          return CounterDigitsGlyphStyle.LOWER_GREEK;
        case "lower-roman":
          return CounterDigitsGlyphStyle.LOWER_ROMAN;
        case "none":
          return CounterDigitsGlyphStyle.NONE;
        case "square":
          return CounterDigitsGlyphStyle.SQUARE;
        case "upper-alpha":
        case "upper-latin":
          return CounterDigitsGlyphStyle.UPPER_ALPHA_AND_LATIN;
        case "upper-roman":
          return CounterDigitsGlyphStyle.UPPER_ROMAN;
        case null:
          return CounterDigitsGlyphStyle.DEFAULT;
        default:
          return CounterDigitsGlyphStyle.DEFAULT;
      }
    }
  }
}
