﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Html.TagConstants
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

#nullable disable
namespace iText.Html2pdf.Html
{
  public sealed class TagConstants
  {
    public const string A = "a";
    public const string ABBR = "abbr";
    public const string ADDRESS = "address";
    public const string ARTICLE = "article";
    public const string ASIDE = "aside";
    public const string B = "b";
    public const string BDI = "bdi";
    public const string BDO = "bdo";
    public const string BIG = "big";
    public const string BLOCKQUOTE = "blockquote";
    public const string BODY = "body";
    public const string BR = "br";
    public const string BUTTON = "button";
    public const string CAPTION = "caption";
    public const string CENTER = "center";
    public const string CITE = "cite";
    public const string CODE = "code";
    public const string COL = "col";
    public const string COLGROUP = "colgroup";
    public const string DD = "dd";
    public const string DEL = "del";
    public const string DFN = "dfn";
    public const string DL = "dl";
    public const string DT = "dt";
    public const string DIV = "div";
    public const string EM = "em";
    public const string FIELDSET = "fieldset";
    public const string FIGCAPTION = "figcaption";
    public const string FIGURE = "figure";
    public const string FONT = "font";
    public const string FOOTER = "footer";
    public const string FORM = "form";
    public const string H1 = "h1";
    public const string H2 = "h2";
    public const string H3 = "h3";
    public const string H4 = "h4";
    public const string H5 = "h5";
    public const string H6 = "h6";
    public const string HR = "hr";
    public const string HEAD = "head";
    public const string HEADER = "header";
    public const string HTML = "html";
    public const string I = "i";
    public const string IMG = "img";
    public const string INPUT = "input";
    public const string INS = "ins";
    public const string KBD = "kbd";
    public const string LABEL = "label";
    public const string LEGEND = "legend";
    public const string LI = "li";
    public const string LINK = "link";
    public const string MAIN = "main";
    public const string MARK = "mark";
    public const string MARQUEE = "marquee";
    public const string META = "meta";
    public const string NAV = "nav";
    public const string OBJECT = "object";
    public const string OL = "ol";
    public const string OPTGROUP = "optgroup";
    public const string OPTION = "option";
    public const string P = "p";
    public const string PRE = "pre";
    public const string Q = "q";
    public const string S = "s";
    public const string SVG = "svg";
    public const string SAMP = "samp";
    public const string SCRIPT = "script";
    public const string SECTION = "section";
    public const string SELECT = "select";
    public const string SMALL = "small";
    public const string SPAN = "span";
    public const string STRIKE = "strike";
    public const string STRONG = "strong";
    public const string STYLE = "style";
    public const string SUB = "sub";
    public const string SUP = "sup";
    public const string TABLE = "table";
    public const string TBODY = "tbody";
    public const string TEXTAREA = "textarea";
    public const string TD = "td";
    public const string TFOOT = "tfoot";
    public const string TH = "th";
    public const string THEAD = "thead";
    public const string TIME = "time";
    public const string TITLE = "title";
    public const string TR = "tr";
    public const string TT = "tt";
    public const string U = "u";
    public const string UL = "ul";
    public const string VAR = "var";

    private TagConstants()
    {
    }
  }
}
