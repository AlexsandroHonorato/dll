﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.LinkContext
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Pdf.Annot;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl
{
  public class LinkContext
  {
    private ICollection<string> linkDestinations = (ICollection<string>) new HashSet<string>();
    private IDictionary<string, PdfLinkAnnotation> linkAnnotations = (IDictionary<string, PdfLinkAnnotation>) new Dictionary<string, PdfLinkAnnotation>();

    public virtual LinkContext ScanForIds(INode root)
    {
      this.linkDestinations.Clear();
      while (root.ParentNode() != null)
        root = root.ParentNode();
      Stack<INode> c = new Stack<INode>();
      c.Push(root);
      while (!c.IsEmpty<INode>())
      {
        INode inode = c.Pop();
        if (inode is IElementNode)
        {
          IElementNode ielementNode = (IElementNode) inode;
          if ("a".Equals(ielementNode.Name()))
          {
            string attribute = ielementNode.GetAttribute("href");
            if (attribute != null && attribute.StartsWith("#"))
              this.linkDestinations.Add(attribute.Substring(1));
          }
        }
        if (!inode.ChildNodes().IsEmpty<INode>())
          c.AddAll<INode>((IEnumerable<INode>) inode.ChildNodes());
      }
      return this;
    }

    public virtual bool IsUsedLinkDestination(string linkDestination)
    {
      return this.linkDestinations.Contains(linkDestination);
    }

    public virtual void AddLinkAnnotation(string id, PdfLinkAnnotation annot)
    {
      this.linkAnnotations.Put<string, PdfLinkAnnotation>(id, annot);
    }

    public virtual PdfLinkAnnotation GetLinkAnnotation(string id)
    {
      return this.linkAnnotations.Get<string, PdfLinkAnnotation>(id);
    }
  }
}
