﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageCountRenderer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Html2pdf.Html;
using iText.IO.Font.Otf;
using iText.Kernel.Font;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Layout;
using iText.Layout.Renderer;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageCountRenderer : TextRenderer
  {
    private readonly CounterDigitsGlyphStyle digitsGlyphStyle;

    internal PageCountRenderer(PageCountElement textElement)
      : base((Text) textElement)
    {
      this.digitsGlyphStyle = textElement.GetDigitsGlyphStyle();
    }

    protected internal PageCountRenderer(TextRenderer other)
      : base(other)
    {
      this.digitsGlyphStyle = ((PageCountRenderer) other).digitsGlyphStyle;
    }

    public override LayoutResult Layout(LayoutContext layoutContext)
    {
      PageCountType pageCountType = this.GetProperty<PageCountType?>(1048578).Value;
      string text = this.GetText().ToString();
      bool flag = false;
      switch (pageCountType)
      {
        case PageCountType.CURRENT_PAGE_NUMBER:
          this.SetText(HtmlUtils.ConvertNumberAccordingToGlyphStyle(this.digitsGlyphStyle, layoutContext.GetArea().GetPageNumber()));
          flag = true;
          break;
        case PageCountType.TOTAL_PAGE_COUNT:
          IRenderer renderer = (IRenderer) this;
          while (true)
          {
            switch (renderer)
            {
              case AbstractRenderer _ when ((AbstractRenderer) renderer).GetParent() != null:
                renderer = ((AbstractRenderer) renderer).GetParent();
                continue;
              case HtmlDocumentRenderer _ when ((HtmlDocumentRenderer) renderer).GetEstimatedNumberOfPages() > 0:
                goto label_5;
              case DocumentRenderer _ when renderer.GetModelElement() is Document:
                goto label_6;
              default:
                goto label_7;
            }
          }
label_5:
          this.SetText(HtmlUtils.ConvertNumberAccordingToGlyphStyle(this.digitsGlyphStyle, ((HtmlDocumentRenderer) renderer).GetEstimatedNumberOfPages()));
          flag = true;
          break;
label_6:
          this.SetText(HtmlUtils.ConvertNumberAccordingToGlyphStyle(this.digitsGlyphStyle, ((Document) renderer.GetModelElement()).GetPdfDocument().GetNumberOfPages()));
          flag = true;
          break;
      }
label_7:
      LayoutResult layoutResult = base.Layout(layoutContext);
      if (!flag)
        return layoutResult;
      this.SetText(text);
      return layoutResult;
    }

    public override IRenderer GetNextRenderer()
    {
      if (typeof (PageCountRenderer) != this.GetType())
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageCountRenderer)), MessageFormatUtil.Format("If a renderer overflows, iText uses this method to create another renderer for the overflow part. So if one wants to extend the renderer, one should override this method: otherwise the default method will be used and thus the default rather than the custom renderer will be created.", Array.Empty<object>()), Array.Empty<object>());
      return (IRenderer) new PageCountRenderer((PageCountElement) this.modelElement);
    }

    protected override TextRenderer CreateCopy(GlyphLine gl, PdfFont font)
    {
      if (typeof (PageCountRenderer) != this.GetType())
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageCountRenderer)), MessageFormatUtil.Format("While processing an instance of TextRenderer, iText uses createCopy() to create glyph lines of specific fonts, which represent its parts. So if one extends TextRenderer, one should override createCopy, otherwise if FontSelector related logic is triggered, copies of this TextRenderer will have the default behavior rather than the custom one.", Array.Empty<object>()), Array.Empty<object>());
      PageCountRenderer copy = new PageCountRenderer((TextRenderer) this);
      copy.SetProcessedGlyphLineAndFont(gl, font);
      return (TextRenderer) copy;
    }

    protected override bool ResolveFonts(IList<IRenderer> addTo)
    {
      IList<IRenderer> addTo1 = (IList<IRenderer>) new List<IRenderer>();
      base.ResolveFonts(addTo1);
      this.SetProperty(20, addTo1[0].GetProperty<object>(20));
      addTo.Add((IRenderer) this);
      return true;
    }
  }
}
