﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.HtmlBodyStylesApplierHandler
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Events;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class HtmlBodyStylesApplierHandler : IEventHandler
  {
    private readonly HtmlDocumentRenderer htmlDocumentRenderer;
    private readonly IDictionary<int, HtmlBodyStylesApplierHandler.PageStylesProperties> pageStylesPropertiesMap;
    private PdfCanvas pdfCanvas;

    public HtmlBodyStylesApplierHandler(
      HtmlDocumentRenderer htmlDocumentRenderer,
      IDictionary<int, HtmlBodyStylesApplierHandler.PageStylesProperties> pageStylesPropertiesMap)
    {
      this.htmlDocumentRenderer = htmlDocumentRenderer;
      this.pageStylesPropertiesMap = pageStylesPropertiesMap;
    }

    public virtual void HandleEvent(Event @event)
    {
      if (!(@event is PdfDocumentEvent))
        return;
      PdfPage page = ((PdfDocumentEvent) @event).GetPage();
      int pageNumber = ((PdfDocumentEvent) @event).GetDocument().GetPageNumber(page);
      this.ProcessPage(page, pageNumber);
    }

    internal virtual void ProcessPage(PdfPage page, int pageNumber)
    {
      HtmlBodyStylesApplierHandler.PageStylesProperties stylesProperties = this.pageStylesPropertiesMap.Get<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(pageNumber);
      if (stylesProperties == null)
        return;
      PageContextProcessor pageProcessor = this.htmlDocumentRenderer.GetPageProcessor(pageNumber);
      this.pdfCanvas = pageProcessor.DrawPageBackground(page);
      this.ApplyHtmlBodyStyles(page, pageProcessor.ComputeLayoutMargins(), stylesProperties.styles, pageNumber);
      this.pdfCanvas = (PdfCanvas) null;
    }

    private void ApplyHtmlBodyStyles(
      PdfPage page,
      float[] margins,
      BodyHtmlStylesContainer[] styles,
      int pageNumber)
    {
      int num = this.ApplyFirstBackground(page, margins, styles, pageNumber);
      bool recalculateBodyAreaForContentSize = false;
      for (int index1 = 0; index1 < 2; ++index1)
      {
        if (styles[index1] != null)
        {
          if (index1 == 1)
            recalculateBodyAreaForContentSize = styles[0] != null && (styles[0].HasOwnProperty(6) || styles[0].HasOwnProperty(90));
          if (styles[index1].HasContentToDraw())
            this.DrawSimulatedDiv(page, styles[index1].properties, margins, num != index1, pageNumber, recalculateBodyAreaForContentSize);
          for (int index2 = 0; index2 < 4; ++index2)
            margins[index2] += styles[index1].GetTotalWidth()[index2];
        }
      }
    }

    private int ApplyFirstBackground(
      PdfPage page,
      float[] margins,
      BodyHtmlStylesContainer[] styles,
      int pageNumber)
    {
      int index = -1;
      if (styles[0] != null && (styles[0].GetOwnProperty<Background>(6) != null || styles[0].GetOwnProperty<object>(90) != null))
        index = 0;
      else if (styles[1] != null && (styles[1].GetOwnProperty<Background>(6) != null || styles[1].GetOwnProperty<object>(90) != null))
        index = 1;
      if (index != -1)
      {
        Dictionary<int, object> dictionary = new Dictionary<int, object>();
        dictionary.Put<int, object>(6, (object) styles[index].GetProperty<Background>(6));
        dictionary.Put<int, object>(90, styles[index].GetProperty<object>(90));
        this.DrawSimulatedDiv(page, (IDictionary<int, object>) dictionary, margins, true, pageNumber, false);
      }
      return index;
    }

    private void DrawSimulatedDiv(
      PdfPage page,
      IDictionary<int, object> styles,
      float[] margins,
      bool drawBackground,
      int pageNumber,
      bool recalculateBodyAreaForContentSize)
    {
      Div div = new Div().SetFillAvailableArea(true);
      foreach (KeyValuePair<int, object> style in (IEnumerable<KeyValuePair<int, object>>) styles)
      {
        if (style.Key != 6 && style.Key != 90 || drawBackground)
          div.SetProperty(style.Key, style.Value);
      }
      div.GetAccessibilityProperties().SetRole("Artifact");
      Rectangle rectangle = new Rectangle(page.GetTrimBox()).ApplyMargins(margins[0], margins[1], margins[2], margins[3], false);
      if (recalculateBodyAreaForContentSize)
      {
        if (this.pageStylesPropertiesMap.Get<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(pageNumber).lowestAndHighest == null)
          return;
        HtmlBodyStylesApplierHandler.LowestAndHighest lowestAndHighest = this.pageStylesPropertiesMap.Get<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(pageNumber).lowestAndHighest;
        this.RecalculateBackgroundAreaForBody(rectangle, div, lowestAndHighest);
      }
      if (this.pdfCanvas == null)
        this.pdfCanvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), page.GetDocument());
      iText.Layout.Canvas canvas = new iText.Layout.Canvas(this.pdfCanvas, rectangle);
      canvas.EnableAutoTagging(page);
      canvas.Add((IBlockElement) div);
      canvas.Close();
    }

    private void RecalculateBackgroundAreaForBody(
      Rectangle backgroundArea,
      Div pageBordersSimulation,
      HtmlBodyStylesApplierHandler.LowestAndHighest lowestAndHighest)
    {
      UnitValue ownProperty1 = pageBordersSimulation.GetOwnProperty<UnitValue>(46);
      UnitValue ownProperty2 = pageBordersSimulation.GetOwnProperty<UnitValue>(43);
      float num1 = ownProperty1 == null ? 0.0f : ownProperty1.GetValue();
      float num2 = ownProperty2 == null ? 0.0f : ownProperty2.GetValue();
      Border ownProperty3 = pageBordersSimulation.GetOwnProperty<Border>(13);
      Border ownProperty4 = pageBordersSimulation.GetOwnProperty<Border>(10);
      float num3 = ownProperty3 == null ? 0.0f : ownProperty3.GetWidth();
      float num4 = ownProperty4 == null ? 0.0f : ownProperty4.GetWidth();
      UnitValue ownProperty5 = pageBordersSimulation.GetOwnProperty<UnitValue>(50);
      UnitValue ownProperty6 = pageBordersSimulation.GetOwnProperty<UnitValue>(47);
      float num5 = ownProperty5 == null ? 0.0f : ownProperty5.GetValue();
      float num6 = ownProperty6 == null ? 0.0f : ownProperty6.GetValue();
      float num7 = backgroundArea.GetY() + backgroundArea.GetHeight();
      if ((double) lowestAndHighest.lowest >= (double) backgroundArea.GetY())
        backgroundArea.SetY(lowestAndHighest.lowest - num6 - num4 - num2);
      float num8 = lowestAndHighest.highest - lowestAndHighest.lowest + num5 + num6 + num3 + num4 + num1 + num2 + backgroundArea.GetY();
      if ((double) num8 > (double) num7)
        return;
      backgroundArea.SetHeight(num8 - backgroundArea.GetY());
    }

    internal class LowestAndHighest
    {
      internal float lowest;
      internal float highest;

      public LowestAndHighest(float lowest, float highest)
      {
        this.lowest = lowest;
        this.highest = highest;
      }
    }

    internal class PageStylesProperties
    {
      internal BodyHtmlStylesContainer[] styles;
      internal HtmlBodyStylesApplierHandler.LowestAndHighest lowestAndHighest;

      public PageStylesProperties(BodyHtmlStylesContainer[] styles) => this.styles = styles;
    }
  }
}
