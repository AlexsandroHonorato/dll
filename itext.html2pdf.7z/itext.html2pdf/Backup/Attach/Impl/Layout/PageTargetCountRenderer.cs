﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageTargetCountRenderer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Html2pdf.Html;
using iText.IO.Font.Otf;
using iText.Kernel.Font;
using iText.Layout.Element;
using iText.Layout.Layout;
using iText.Layout.Renderer;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageTargetCountRenderer : TextRenderer
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (PageTargetCountRenderer));
    private const string UNDEFINED_VALUE = "0";
    private readonly string target;
    private readonly CounterDigitsGlyphStyle digitsGlyphStyle;

    internal PageTargetCountRenderer(PageTargetCountElement textElement)
      : base((Text) textElement)
    {
      this.digitsGlyphStyle = textElement.GetDigitsGlyphStyle();
      this.target = textElement.GetTarget();
    }

    protected internal PageTargetCountRenderer(TextRenderer other)
      : base(other)
    {
      this.digitsGlyphStyle = ((PageTargetCountRenderer) other).digitsGlyphStyle;
      this.target = ((PageTargetCountRenderer) other).target;
    }

    public override LayoutResult Layout(LayoutContext layoutContext)
    {
      string text = this.GetText().ToString();
      int? pageById = TargetCounterHandler.GetPageByID((IRenderer) this, this.target);
      if (!pageById.HasValue)
        this.SetText("0");
      else
        this.SetText(HtmlUtils.ConvertNumberAccordingToGlyphStyle(this.digitsGlyphStyle, pageById.Value));
      LayoutResult layoutResult = base.Layout(layoutContext);
      this.SetText(text);
      return layoutResult;
    }

    public override void Draw(DrawContext drawContext)
    {
      if (!TargetCounterHandler.IsValueDefinedForThisId((IRenderer) this, this.target))
        LoggerExtensions.LogWarning(PageTargetCountRenderer.LOGGER, MessageFormatUtil.Format("Cannot resolve target-counter value with given target \"{0}\"", new object[1]
        {
          (object) this.target
        }), Array.Empty<object>());
      base.Draw(drawContext);
    }

    public override IRenderer GetNextRenderer()
    {
      if (typeof (PageTargetCountRenderer) != this.GetType())
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageTargetCountRenderer)), MessageFormatUtil.Format("If a renderer overflows, iText uses this method to create another renderer for the overflow part. So if one wants to extend the renderer, one should override this method: otherwise the default method will be used and thus the default rather than the custom renderer will be created.", Array.Empty<object>()), Array.Empty<object>());
      return (IRenderer) new PageTargetCountRenderer((PageTargetCountElement) this.modelElement);
    }

    protected override TextRenderer CreateCopy(GlyphLine gl, PdfFont font)
    {
      if (typeof (PageTargetCountRenderer) != this.GetType())
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageTargetCountRenderer)), MessageFormatUtil.Format("While processing an instance of TextRenderer, iText uses createCopy() to create glyph lines of specific fonts, which represent its parts. So if one extends TextRenderer, one should override createCopy, otherwise if FontSelector related logic is triggered, copies of this TextRenderer will have the default behavior rather than the custom one.", Array.Empty<object>()), Array.Empty<object>());
      PageTargetCountRenderer copy = new PageTargetCountRenderer((TextRenderer) this);
      copy.SetProcessedGlyphLineAndFont(gl, font);
      return (TextRenderer) copy;
    }

    protected override bool ResolveFonts(IList<IRenderer> addTo)
    {
      IList<IRenderer> addTo1 = (IList<IRenderer>) new List<IRenderer>();
      base.ResolveFonts(addTo1);
      this.SetProperty(20, addTo1[0].GetProperty<object>(20));
      addTo.Add((IRenderer) this);
      return true;
    }
  }
}
