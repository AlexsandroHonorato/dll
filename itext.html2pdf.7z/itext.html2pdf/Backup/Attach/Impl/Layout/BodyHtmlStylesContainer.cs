﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.BodyHtmlStylesContainer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class BodyHtmlStylesContainer : IPropertyContainer
  {
    protected internal IDictionary<int, object> properties = (IDictionary<int, object>) new Dictionary<int, object>();

    public virtual void SetProperty(int property, object value)
    {
      this.properties.Put<int, object>(property, value);
    }

    public virtual bool HasProperty(int property) => this.HasOwnProperty(property);

    public virtual bool HasOwnProperty(int property) => this.properties.ContainsKey(property);

    public virtual void DeleteOwnProperty(int property)
    {
      this.properties.JRemove<int, object>(property);
    }

    public virtual T1 GetProperty<T1>(int property) => this.GetOwnProperty<T1>(property);

    public virtual T1 GetOwnProperty<T1>(int property)
    {
      return (T1) this.properties.Get<int, object>(property);
    }

    public virtual T1 GetDefaultProperty<T1>(int property)
    {
      switch (property)
      {
        case 43:
        case 44:
        case 45:
        case 46:
        case 47:
        case 48:
        case 49:
        case 50:
          return (T1) UnitValue.CreatePointValue(0.0f);
        default:
          return (T1) null;
      }
    }

    public virtual bool HasContentToDraw()
    {
      Border[] bodyHtmlBorders = this.GetBodyHtmlBorders();
      for (int index = 0; index < 4; ++index)
      {
        if (bodyHtmlBorders[index] != null && (double) bodyHtmlBorders[index].GetWidth() != 0.0)
          return true;
      }
      return this.GetOwnProperty<Background>(6) != null || this.GetOwnProperty<object>(90) != null;
    }

    public virtual bool HasStylesToApply()
    {
      float[] totalWidth = this.GetTotalWidth();
      for (int index = 0; index < 4; ++index)
      {
        if ((double) totalWidth[index] > 0.0)
          return true;
      }
      return this.GetOwnProperty<Background>(6) != null || this.GetOwnProperty<object>(90) != null;
    }

    public virtual float[] GetTotalWidth()
    {
      Border[] bodyHtmlBorders = this.GetBodyHtmlBorders();
      float[] marginsOrPaddings1 = this.GetBodyHtmlMarginsOrPaddings(true);
      float[] marginsOrPaddings2 = this.GetBodyHtmlMarginsOrPaddings(false);
      float[] totalWidth = new float[4];
      for (int index = 0; index < 4; ++index)
      {
        totalWidth[index] += marginsOrPaddings1[index] + marginsOrPaddings2[index];
        if (bodyHtmlBorders[index] != null)
          totalWidth[index] += bodyHtmlBorders[index].GetWidth();
      }
      return totalWidth;
    }

    private float[] GetBodyHtmlMarginsOrPaddings(bool margin)
    {
      int[] numArray = new int[4];
      if (margin)
      {
        numArray[0] = 46;
        numArray[1] = 45;
        numArray[2] = 43;
        numArray[3] = 44;
      }
      else
      {
        numArray[0] = 50;
        numArray[1] = 49;
        numArray[2] = 47;
        numArray[3] = 48;
      }
      float[] marginsOrPaddings = new float[4];
      UnitValue[] unitValueArray = new UnitValue[4];
      for (int index = 0; index < 4; ++index)
      {
        unitValueArray[index] = this.GetOwnProperty<UnitValue>(numArray[index]);
        if (unitValueArray[index] != null && unitValueArray[index].IsPointValue())
          marginsOrPaddings[index] = unitValueArray[index].GetValue();
      }
      return marginsOrPaddings;
    }

    private Border[] GetBodyHtmlBorders()
    {
      return new Border[4]
      {
        this.GetOwnProperty<Border>(13),
        this.GetOwnProperty<Border>(12),
        this.GetOwnProperty<Border>(10),
        this.GetOwnProperty<Border>(11)
      };
    }
  }
}
