﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.RunningElementContainer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class RunningElementContainer
  {
    private IElementNode runningElement;
    private ITagWorker processedElementWorker;
    private int pageNum;
    private bool firstOnPage;

    public RunningElementContainer(IElementNode runningElement, ITagWorker processedElementWorker)
    {
      this.runningElement = runningElement;
      this.processedElementWorker = processedElementWorker;
    }

    public virtual void SetOccurrencePage(int pageNum, bool firstOnPage)
    {
      this.pageNum = pageNum;
      this.firstOnPage = firstOnPage;
    }

    public virtual int GetOccurrencePage() => this.pageNum;

    public virtual bool IsFirstOnPage() => this.firstOnPage;

    internal virtual IElementNode GetRunningElement() => this.runningElement;

    internal virtual ITagWorker GetProcessedElementWorker() => this.processedElementWorker;
  }
}
