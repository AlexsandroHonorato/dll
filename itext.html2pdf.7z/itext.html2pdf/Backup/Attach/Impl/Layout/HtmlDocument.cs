﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.HtmlDocument
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class HtmlDocument : Document
  {
    public HtmlDocument(PdfDocument pdfDoc, PageSize pageSize, bool immediateFlush)
      : base(pdfDoc, pageSize, immediateFlush)
    {
    }

    public override void Relayout()
    {
      if (!(this.rootRenderer is HtmlDocumentRenderer))
        return;
      ((HtmlDocumentRenderer) this.rootRenderer).RemoveEventHandlers();
      base.Relayout();
      ((HtmlDocumentRenderer) this.rootRenderer).ProcessWaitingElement();
    }
  }
}
