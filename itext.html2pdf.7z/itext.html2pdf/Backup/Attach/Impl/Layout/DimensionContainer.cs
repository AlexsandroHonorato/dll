﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.DimensionContainer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout.Properties;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Util;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal abstract class DimensionContainer
  {
    internal float dimension;
    internal float minDimension;
    internal float maxDimension;
    internal float minContentDimension;
    internal float maxContentDimension;

    internal DimensionContainer()
    {
      this.dimension = -1f;
      this.minDimension = 0.0f;
      this.minContentDimension = 0.0f;
      this.maxDimension = float.MaxValue;
      this.maxContentDimension = float.MaxValue;
    }

    internal virtual bool IsAutoDimension() => (double) this.dimension == -1.0;

    internal virtual float ParseDimension(
      CssContextNode node,
      string content,
      float maxAvailableDimension,
      float additionalWidthFix)
    {
      float absoluteFontSize = CssDimensionParsingUtils.ParseAbsoluteFontSize(node.GetStyles().Get<string, string>("font-size"));
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(content, absoluteFontSize, 0.0f);
      if (lengthValueToPt == null)
        return 0.0f;
      return lengthValueToPt.IsPointValue() ? lengthValueToPt.GetValue() + additionalWidthFix : (float) ((double) maxAvailableDimension * (double) lengthValueToPt.GetValue() / 100.0);
    }
  }
}
