﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.RunningElement
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout.Element;
using iText.Layout.Layout;
using iText.Layout.Properties;
using iText.Layout.Renderer;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class RunningElement : Div
  {
    private RunningElementContainer runningElementContainer;

    public RunningElement(RunningElementContainer runningElementContainer)
    {
      this.runningElementContainer = runningElementContainer;
      this.GetAccessibilityProperties().SetRole("Artifact");
    }

    protected override IRenderer MakeNewRenderer()
    {
      return (IRenderer) new RunningElement.RunningElementRenderer((Div) this, this.runningElementContainer);
    }

    internal class RunningElementRenderer : DivRenderer
    {
      private RunningElementContainer runningElementContainer;
      private bool isFirstOnRootArea;

      public RunningElementRenderer(
        Div modelElement,
        RunningElementContainer runningElementContainer)
        : base(modelElement)
      {
        this.runningElementContainer = runningElementContainer;
        this.SetProperty(123, (object) RenderingMode.DEFAULT_LAYOUT_MODE);
      }

      public override LayoutResult Layout(LayoutContext layoutContext)
      {
        this.isFirstOnRootArea = this.IsFirstOnRootArea();
        return base.Layout(layoutContext);
      }

      public override void Draw(DrawContext drawContext)
      {
        this.runningElementContainer.SetOccurrencePage(this.GetOccupiedArea().GetPageNumber(), this.isFirstOnRootArea);
        base.Draw(drawContext);
      }
    }
  }
}
