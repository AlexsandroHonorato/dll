﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.WidthDimensionContainer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout.Minmaxwidth;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class WidthDimensionContainer : DimensionContainer
  {
    public WidthDimensionContainer(
      CssContextNode node,
      float maxWidth,
      IRenderer renderer,
      float additionalWidthFix)
    {
      string content = node.GetStyles().Get<string, string>("width");
      if (content != null && !"auto".Equals(content))
        this.dimension = this.ParseDimension(node, content, maxWidth, additionalWidthFix);
      this.minDimension = this.GetMinWidth(node, maxWidth, additionalWidthFix);
      this.maxDimension = this.GetMaxWidth(node, maxWidth, additionalWidthFix);
      if (!this.IsAutoDimension())
      {
        this.maxContentDimension = this.dimension;
        this.minContentDimension = this.dimension;
      }
      else
      {
        if (!(renderer is BlockRenderer))
          return;
        MinMaxWidth minMaxWidth = ((AbstractRenderer) renderer).GetMinMaxWidth();
        this.maxContentDimension = minMaxWidth.GetMaxWidth();
        this.minContentDimension = minMaxWidth.GetMinWidth();
      }
    }

    private float GetMinWidth(
      CssContextNode node,
      float maxAvailableWidth,
      float additionalWidthFix)
    {
      string content = node.GetStyles().Get<string, string>("min-width");
      return content == null ? 0.0f : this.ParseDimension(node, content, maxAvailableWidth, additionalWidthFix);
    }

    private float GetMaxWidth(
      CssContextNode node,
      float maxAvailableWidth,
      float additionalWidthFix)
    {
      string content = node.GetStyles().Get<string, string>("max-width");
      if (content == null)
        return float.MaxValue;
      float dimension = this.ParseDimension(node, content, maxAvailableWidth, additionalWidthFix);
      return (double) dimension == 0.0 ? float.MaxValue : dimension;
    }
  }
}
