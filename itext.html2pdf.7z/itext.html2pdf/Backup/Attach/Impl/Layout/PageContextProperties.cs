﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageContextProperties
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Css.Resolve;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageContextProperties
  {
    private static readonly IList<string> pageMarginBoxNames = JavaUtil.ArraysAsList<string>(new string[16]
    {
      "top-left-corner",
      "top-left",
      "top-center",
      "top-right",
      "top-right-corner",
      "right-top",
      "right-middle",
      "right-bottom",
      "bottom-right-corner",
      "bottom-right",
      "bottom-center",
      "bottom-left",
      "bottom-left-corner",
      "left-bottom",
      "left-middle",
      "left-top"
    });
    private PageContextNode pageContextNode;
    private IList<PageMarginBoxContextNode> pageMarginBoxes;

    private PageContextProperties(
      PageContextNode pageProps,
      IList<PageMarginBoxContextNode> pagesMarginBoxes)
    {
      this.pageContextNode = pageProps;
      this.pageMarginBoxes = pagesMarginBoxes;
    }

    public static PageContextProperties Resolve(
      INode rootNode,
      ICssResolver cssResolver,
      CssContext context,
      params string[] pageClasses)
    {
      PageContextNode resolvedPageClassNode = PageContextProperties.GetResolvedPageClassNode(rootNode, cssResolver, context, pageClasses);
      return new PageContextProperties(resolvedPageClassNode, PageContextProperties.GetResolvedMarginBoxes(resolvedPageClassNode, cssResolver, context));
    }

    private static IList<PageMarginBoxContextNode> GetResolvedMarginBoxes(
      PageContextNode pageClassNode,
      ICssResolver cssResolver,
      CssContext context)
    {
      IList<PageMarginBoxContextNode> resolvedMarginBoxes = (IList<PageMarginBoxContextNode>) new List<PageMarginBoxContextNode>();
      foreach (string pageMarginBoxName in (IEnumerable<string>) PageContextProperties.pageMarginBoxNames)
      {
        PageMarginBoxContextNode marginBoxContextNode = new PageMarginBoxContextNode((INode) pageClassNode, pageMarginBoxName);
        IDictionary<string, string> dictionary = cssResolver.ResolveStyles((INode) marginBoxContextNode, (AbstractCssContext) context);
        if (!((CssContextNode) marginBoxContextNode).ChildNodes().IsEmpty<INode>())
        {
          ((CssContextNode) marginBoxContextNode).SetStyles(dictionary);
          resolvedMarginBoxes.Add(marginBoxContextNode);
        }
        context.SetQuotesDepth(0);
      }
      return resolvedMarginBoxes;
    }

    private static PageContextNode GetResolvedPageClassNode(
      INode rootNode,
      ICssResolver cssResolver,
      CssContext context,
      params string[] pageClasses)
    {
      PageContextNode resolvedPageClassNode = new PageContextNode(rootNode);
      foreach (string pageClass in pageClasses)
        resolvedPageClassNode.AddPageClass(pageClass);
      IDictionary<string, string> dictionary = cssResolver.ResolveStyles((INode) resolvedPageClassNode, (AbstractCssContext) context);
      ((CssContextNode) resolvedPageClassNode).SetStyles(dictionary);
      return resolvedPageClassNode;
    }

    internal virtual PageContextNode GetResolvedPageContextNode() => this.pageContextNode;

    internal virtual IList<PageMarginBoxContextNode> GetResolvedPageMarginBoxes()
    {
      return this.pageMarginBoxes;
    }
  }
}
