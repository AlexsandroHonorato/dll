﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageSizeParser
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Kernel.Geom;
using iText.Layout.Properties;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageSizeParser
  {
    private static readonly IDictionary<string, PageSize> pageSizeConstants = (IDictionary<string, PageSize>) new Dictionary<string, PageSize>();

    static PageSizeParser()
    {
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("a5", PageSize.A5);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("a4", PageSize.A4);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("a3", PageSize.A3);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("b5", PageSize.B5);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("b4", PageSize.B4);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("jis-b5", new PageSize(516f, 729f));
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("jis-b4", new PageSize(729f, 1032f));
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("letter", PageSize.LETTER);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("legal", PageSize.LEGAL);
      PageSizeParser.pageSizeConstants.Put<string, PageSize>("ledger", PageSize.LEDGER.Rotate());
    }

    internal static PageSize FetchPageSize(
      string pageSizeStr,
      float em,
      float rem,
      PageSize defaultPageSize)
    {
      PageSize pageSize1 = (PageSize) ((Rectangle) defaultPageSize).Clone();
      if (pageSizeStr == null || "auto".Equals(pageSizeStr))
        return pageSize1;
      string[] pageSizeChunks = StringUtil.Split(pageSizeStr, " ");
      string str1 = pageSizeChunks[0];
      if (PageSizeParser.IsLengthValue(str1))
      {
        PageSize pageLengthValue = PageSizeParser.ParsePageLengthValue(pageSizeChunks, em, rem);
        if (pageLengthValue != null)
          pageSize1 = pageLengthValue;
        else
          LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageSizeParser)), MessageFormatUtil.Format("Page size value {0} is invalid.", new object[1]
          {
            (object) pageSizeStr
          }), Array.Empty<object>());
      }
      else
      {
        bool? nullable = new bool?();
        PageSize pageSize2 = (PageSize) null;
        if (PageSizeParser.IsLandscapePortraitValue(str1))
          nullable = new bool?("landscape".Equals(str1));
        else
          pageSize2 = PageSizeParser.pageSizeConstants.Get<string, PageSize>(str1);
        if (pageSizeChunks.Length > 1)
        {
          string str2 = pageSizeChunks[1];
          if (PageSizeParser.IsLandscapePortraitValue(str2))
            nullable = new bool?("landscape".Equals(str2));
          else
            pageSize2 = PageSizeParser.pageSizeConstants.Get<string, PageSize>(str2);
        }
        if (((pageSizeChunks.Length != 1 ? 0 : (pageSize2 != null ? 1 : (nullable.HasValue ? 1 : 0))) | (pageSize2 == null ? (false ? 1 : 0) : (nullable.HasValue ? 1 : 0))) != 0)
        {
          if (pageSize2 != null)
            pageSize1 = pageSize2;
          if (((!true.Equals((object) nullable) ? 0 : ((double) ((Rectangle) pageSize1).GetWidth() < (double) ((Rectangle) pageSize1).GetHeight() ? 1 : 0)) | (!false.Equals((object) nullable) ? (false ? 1 : 0) : ((double) ((Rectangle) pageSize1).GetHeight() < (double) ((Rectangle) pageSize1).GetWidth() ? 1 : 0))) != 0)
            pageSize1 = pageSize1.Rotate();
        }
        else
          LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (PageSizeParser)), MessageFormatUtil.Format("Page size value {0} is invalid.", new object[1]
          {
            (object) pageSizeStr
          }), Array.Empty<object>());
      }
      return pageSize1;
    }

    private static PageSize ParsePageLengthValue(string[] pageSizeChunks, float em, float rem)
    {
      float? pageLengthValue = PageSizeParser.TryParsePageLengthValue(pageSizeChunks[0], em, rem);
      if (!pageLengthValue.HasValue)
        return (PageSize) null;
      float? nullable;
      if (pageSizeChunks.Length > 1)
      {
        nullable = PageSizeParser.TryParsePageLengthValue(pageSizeChunks[1], em, rem);
        if (!nullable.HasValue)
          return (PageSize) null;
      }
      else
        nullable = pageLengthValue;
      return new PageSize(pageLengthValue.Value, nullable.Value);
    }

    private static float? TryParsePageLengthValue(string valueChunk, float em, float rem)
    {
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(valueChunk, em, rem);
      return lengthValueToPt == null || lengthValueToPt.IsPercentValue() ? new float?() : new float?(lengthValueToPt.GetValue());
    }

    private static bool IsLengthValue(string pageSizeChunk)
    {
      return CssTypesValidationUtils.IsMetricValue(pageSizeChunk) || CssTypesValidationUtils.IsRelativeValue(pageSizeChunk);
    }

    private static bool IsLandscapePortraitValue(string pageSizeChunk)
    {
      return "landscape".Equals(pageSizeChunk) || "portrait".Equals(pageSizeChunk);
    }
  }
}
