﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.HtmlDocumentRenderer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.IO.Source;
using iText.Kernel.Events;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Layout;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Node;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class HtmlDocumentRenderer : DocumentRenderer
  {
    private const bool TRIM_LAST_BLANK_PAGE = true;
    private PageContextProcessor firstPageProc;
    private PageContextProcessor leftPageProc;
    private PageContextProcessor rightPageProc;
    private bool evenPagesAreLeft = true;
    private HtmlDocumentRenderer.PageMarginBoxesDrawingHandler marginBoxesHandler;
    private HtmlBodyStylesApplierHandler htmlBodyHandler;
    private IDictionary<int, HtmlBodyStylesApplierHandler.PageStylesProperties> pageStylesPropertiesMap = (IDictionary<int, HtmlBodyStylesApplierHandler.PageStylesProperties>) new Dictionary<int, HtmlBodyStylesApplierHandler.PageStylesProperties>();
    private IRenderer waitingElement;
    private bool shouldTrimFirstBlankPagesCausedByBreakBeforeFirstElement = true;
    private bool anythingAddedToCurrentArea;
    private int estimatedNumberOfPages;

    public HtmlDocumentRenderer(Document document, bool immediateFlush)
      : base(document, immediateFlush)
    {
      this.htmlBodyHandler = new HtmlBodyStylesApplierHandler(this, this.pageStylesPropertiesMap);
      document.GetPdfDocument().AddEventHandler("EndPdfPage", (IEventHandler) this.htmlBodyHandler);
    }

    public virtual void ProcessPageRules(
      INode rootNode,
      ICssResolver cssResolver,
      ProcessorContext context)
    {
      PageContextProperties properties1 = PageContextProperties.Resolve(rootNode, cssResolver, context.GetCssContext(), "first", "right");
      PageContextProperties properties2 = PageContextProperties.Resolve(rootNode, cssResolver, context.GetCssContext(), "left");
      PageContextProperties properties3 = PageContextProperties.Resolve(rootNode, cssResolver, context.GetCssContext(), "right");
      PageSize defaultPageSize = this.document.GetPdfDocument().GetDefaultPageSize();
      float[] defaultPageMargins = new float[4]
      {
        this.document.GetTopMargin(),
        this.document.GetRightMargin(),
        this.document.GetBottomMargin(),
        this.document.GetRightMargin()
      };
      this.firstPageProc = new PageContextProcessor(properties1, context, defaultPageSize, defaultPageMargins);
      this.leftPageProc = new PageContextProcessor(properties2, context, defaultPageSize, defaultPageMargins);
      this.rightPageProc = new PageContextProcessor(properties3, context, defaultPageSize, defaultPageMargins);
      this.marginBoxesHandler = new HtmlDocumentRenderer.PageMarginBoxesDrawingHandler().SetHtmlDocumentRenderer(this);
      this.document.GetPdfDocument().AddEventHandler("EndPdfPage", (IEventHandler) this.marginBoxesHandler);
    }

    public override void AddChild(IRenderer renderer)
    {
      if (this.waitingElement != null)
      {
        if (true.Equals((object) renderer.GetProperty<bool?>(1048577)))
          this.waitingElement.SetProperty(81, (object) true);
        IRenderer waitingElement = this.waitingElement;
        this.waitingElement = (IRenderer) null;
        base.AddChild(waitingElement);
        if (!HtmlDocumentRenderer.IsRunningElementsOnly(waitingElement))
          this.shouldTrimFirstBlankPagesCausedByBreakBeforeFirstElement = false;
      }
      this.waitingElement = renderer;
      FloatPropertyValue? property1 = renderer.GetProperty<FloatPropertyValue?>(99);
      int? property2 = renderer.GetProperty<int?>(52);
      if (property2.HasValue)
      {
        int? nullable = property2;
        int num = 3;
        if (nullable.GetValueOrDefault() == num & nullable.HasValue)
          goto label_8;
      }
      if (!property1.HasValue || property1.Equals((object) FloatPropertyValue.NONE))
        return;
label_8:
      this.waitingElement = (IRenderer) null;
      base.AddChild(renderer);
    }

    public override void Close()
    {
      this.ProcessWaitingElement();
      base.Close();
      this.TrimLastPageIfNecessary();
      this.document.GetPdfDocument().RemoveEventHandler("EndPdfPage", (IEventHandler) this.marginBoxesHandler);
      this.document.GetPdfDocument().RemoveEventHandler("EndPdfPage", (IEventHandler) this.htmlBodyHandler);
      for (int pageNumber = 1; pageNumber <= this.document.GetPdfDocument().GetNumberOfPages(); ++pageNumber)
      {
        PdfPage page = this.document.GetPdfDocument().GetPage(pageNumber);
        if (!((PdfObjectWrapper<PdfDictionary>) page).IsFlushed())
        {
          this.marginBoxesHandler.ProcessPage(this.document.GetPdfDocument(), pageNumber);
          this.htmlBodyHandler.ProcessPage(page, pageNumber);
        }
      }
    }

    internal virtual void RemoveEventHandlers()
    {
      this.document.GetPdfDocument().RemoveEventHandler("EndPdfPage", (IEventHandler) this.htmlBodyHandler);
      this.document.GetPdfDocument().RemoveEventHandler("EndPdfPage", (IEventHandler) this.marginBoxesHandler);
    }

    public override IRenderer GetNextRenderer()
    {
      this.ProcessWaitingElement();
      HtmlDocumentRenderer htmlDocumentRenderer = new HtmlDocumentRenderer(this.document, this.immediateFlush);
      PageSize defaultPageSize = this.document.GetPdfDocument().GetDefaultPageSize();
      float[] defaultPageMargins = new float[4]
      {
        this.document.GetTopMargin(),
        this.document.GetRightMargin(),
        this.document.GetBottomMargin(),
        this.document.GetRightMargin()
      };
      htmlDocumentRenderer.firstPageProc = this.firstPageProc.Reset(defaultPageSize, defaultPageMargins);
      htmlDocumentRenderer.leftPageProc = this.leftPageProc.Reset(defaultPageSize, defaultPageMargins);
      htmlDocumentRenderer.rightPageProc = this.rightPageProc.Reset(defaultPageSize, defaultPageMargins);
      htmlDocumentRenderer.estimatedNumberOfPages = this.currentArea == null ? this.estimatedNumberOfPages : this.currentArea.GetPageNumber() - this.SimulateTrimLastPage();
      htmlDocumentRenderer.marginBoxesHandler = this.marginBoxesHandler.SetHtmlDocumentRenderer(htmlDocumentRenderer);
      htmlDocumentRenderer.targetCounterHandler = new TargetCounterHandler(this.targetCounterHandler);
      return (IRenderer) htmlDocumentRenderer;
    }

    public override void Flush()
    {
      this.ProcessWaitingElement();
      base.Flush();
    }

    public virtual void ProcessWaitingElement()
    {
      if (this.waitingElement == null)
        return;
      IRenderer waitingElement = this.waitingElement;
      this.waitingElement = (IRenderer) null;
      base.AddChild(waitingElement);
    }

    protected override LayoutArea UpdateCurrentArea(LayoutResult overflowResult)
    {
      AreaBreak areaBreak = overflowResult?.GetAreaBreak();
      if (areaBreak is HtmlPageBreak)
      {
        HtmlPageBreakType breakType = ((HtmlPageBreak) areaBreak).GetBreakType();
        HtmlPageBreakType htmlPageBreakType;
        if (this.shouldTrimFirstBlankPagesCausedByBreakBeforeFirstElement && this.currentArea != null && overflowResult.GetStatus() == 3 && this.currentArea.IsEmptyArea() && this.currentArea.GetPageNumber() == 1)
        {
          this.document.GetPdfDocument().RemovePage(1);
          overflowResult = (LayoutResult) null;
          this.currentArea = (RootLayoutArea) null;
          this.shouldTrimFirstBlankPagesCausedByBreakBeforeFirstElement = false;
          if (!HtmlPageBreakType.LEFT.Equals((object) breakType) || this.IsPageLeft(1))
          {
            htmlPageBreakType = HtmlPageBreakType.RIGHT;
            if (!htmlPageBreakType.Equals((object) breakType) || this.IsPageRight(1))
              goto label_5;
          }
          this.evenPagesAreLeft = !this.evenPagesAreLeft;
        }
label_5:
        this.anythingAddedToCurrentArea = this.anythingAddedToCurrentArea || overflowResult != null && overflowResult.GetStatus() == 2;
        htmlPageBreakType = HtmlPageBreakType.ALWAYS;
        if (htmlPageBreakType.Equals((object) breakType))
        {
          LayoutArea layoutArea = (LayoutArea) this.currentArea;
          if (this.anythingAddedToCurrentArea || this.currentArea == null)
            layoutArea = base.UpdateCurrentArea(overflowResult);
          this.anythingAddedToCurrentArea = false;
          return layoutArea;
        }
        htmlPageBreakType = HtmlPageBreakType.LEFT;
        if (htmlPageBreakType.Equals((object) breakType))
        {
          LayoutArea layoutArea = (LayoutArea) this.currentArea;
          if (this.anythingAddedToCurrentArea || this.currentArea == null || !this.IsPageLeft(this.currentArea.GetPageNumber()))
          {
            do
            {
              layoutArea = base.UpdateCurrentArea(overflowResult);
            }
            while (!this.IsPageLeft(this.currentArea.GetPageNumber()));
          }
          this.anythingAddedToCurrentArea = false;
          return layoutArea;
        }
        htmlPageBreakType = HtmlPageBreakType.RIGHT;
        if (htmlPageBreakType.Equals((object) breakType))
        {
          LayoutArea layoutArea = (LayoutArea) this.currentArea;
          if (this.anythingAddedToCurrentArea || this.currentArea == null || !this.IsPageRight(this.currentArea.GetPageNumber()))
          {
            do
            {
              layoutArea = base.UpdateCurrentArea(overflowResult);
            }
            while (!this.IsPageRight(this.currentArea.GetPageNumber()));
          }
          this.anythingAddedToCurrentArea = false;
          return layoutArea;
        }
      }
      this.anythingAddedToCurrentArea = false;
      return base.UpdateCurrentArea(overflowResult);
    }

    protected override void ShrinkCurrentAreaAndProcessRenderer(
      IRenderer renderer,
      IList<IRenderer> resultRenderers,
      LayoutResult result)
    {
      if (renderer != null)
        this.anythingAddedToCurrentArea = true;
      base.ShrinkCurrentAreaAndProcessRenderer(renderer, resultRenderers, result);
    }

    protected override void FlushSingleRenderer(IRenderer resultRenderer)
    {
      if (!this.IsElementOnNonStaticLayout(resultRenderer))
      {
        LayoutArea occupiedArea = resultRenderer.GetOccupiedArea();
        this.UpdateLowestAndHighestPoints(occupiedArea.GetBBox(), occupiedArea.GetPageNumber());
      }
      base.FlushSingleRenderer(resultRenderer);
    }

    protected override PageSize AddNewPage(PageSize customPageSize)
    {
      int num = this.document.GetPdfDocument().GetNumberOfPages() + 1;
      PageContextProcessor pageProcessor = this.GetPageProcessor(num);
      PdfPage page = customPageSize == null ? this.document.GetPdfDocument().AddNewPage(pageProcessor.GetPageSize()) : this.document.GetPdfDocument().AddNewPage(customPageSize);
      pageProcessor.ProcessNewPage(page);
      float[] layoutMargins = pageProcessor.ComputeLayoutMargins();
      BodyHtmlStylesContainer[] styles = new BodyHtmlStylesContainer[2]
      {
        this.document.GetProperty<BodyHtmlStylesContainer>(1048580),
        this.document.GetProperty<BodyHtmlStylesContainer>(1048579)
      };
      this.pageStylesPropertiesMap.Put<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(num, new HtmlBodyStylesApplierHandler.PageStylesProperties(styles));
      this.UpdateDefaultMargins(styles, layoutMargins);
      this.SetProperty(46, (object) layoutMargins[0]);
      this.SetProperty(45, (object) layoutMargins[1]);
      this.SetProperty(43, (object) layoutMargins[2]);
      this.SetProperty(44, (object) layoutMargins[3]);
      return new PageSize(page.GetTrimBox());
    }

    internal virtual bool ShouldAttemptTrimLastPage()
    {
      return this.document.GetPdfDocument().GetNumberOfPages() > 1;
    }

    internal virtual void TrimLastPageIfNecessary()
    {
      if (!this.ShouldAttemptTrimLastPage())
        return;
      PdfDocument pdfDocument = this.document.GetPdfDocument();
      PdfPage lastPage = pdfDocument.GetLastPage();
      if (lastPage.GetContentStreamCount() != 1 || ((OutputStream<PdfOutputStream>) lastPage.GetContentStream(0).GetOutputStream()).GetCurrentPos() > 0L)
        return;
      pdfDocument.RemovePage(pdfDocument.GetNumberOfPages());
    }

    internal virtual int SimulateTrimLastPage()
    {
      if (!this.ShouldAttemptTrimLastPage())
        return 0;
      int numberOfPages = this.document.GetPdfDocument().GetNumberOfPages();
      bool flag = false;
      foreach (IRenderer childRenderer in (IEnumerable<IRenderer>) this.childRenderers)
      {
        if (childRenderer.GetOccupiedArea().GetPageNumber() == numberOfPages)
          flag = true;
      }
      foreach (IRenderer positionedRenderer in (IEnumerable<IRenderer>) this.positionedRenderers)
      {
        if (positionedRenderer.GetOccupiedArea().GetPageNumber() == numberOfPages)
          flag = true;
      }
      return !flag ? 1 : 0;
    }

    internal virtual PageContextProcessor GetPageProcessor(int pageNum)
    {
      if (pageNum == 1 && this.evenPagesAreLeft)
        return this.firstPageProc;
      return this.IsPageLeft(pageNum) ? this.leftPageProc : this.rightPageProc;
    }

    internal virtual int GetEstimatedNumberOfPages() => this.estimatedNumberOfPages;

    private void UpdateDefaultMargins(BodyHtmlStylesContainer[] styles, float[] defaultMargins)
    {
      for (int index1 = 0; index1 < 2; ++index1)
      {
        if (styles[index1] != null)
        {
          for (int index2 = 0; index2 < 4; ++index2)
            defaultMargins[index2] += styles[index1].GetTotalWidth()[index2];
        }
      }
    }

    private bool IsElementOnNonStaticLayout(IRenderer resultRenderer)
    {
      bool flag = false;
      if (resultRenderer.HasProperty(52))
      {
        int num = resultRenderer.GetProperty<int?>(52).Value;
        flag = num == 3 || num == 4;
      }
      if (!flag && resultRenderer.HasProperty(99))
      {
        FloatPropertyValue? property = resultRenderer.GetProperty<FloatPropertyValue?>(99);
        FloatPropertyValue? nullable = property;
        FloatPropertyValue floatPropertyValue1 = FloatPropertyValue.LEFT;
        int num;
        if (!(nullable.GetValueOrDefault() == floatPropertyValue1 & nullable.HasValue))
        {
          nullable = property;
          FloatPropertyValue floatPropertyValue2 = FloatPropertyValue.RIGHT;
          num = nullable.GetValueOrDefault() == floatPropertyValue2 & nullable.HasValue ? 1 : 0;
        }
        else
          num = 1;
        flag = num != 0;
      }
      return flag;
    }

    private void UpdateLowestAndHighestPoints(Rectangle rectangle, int page)
    {
      if (!this.pageStylesPropertiesMap.ContainsKey(page))
        return;
      HtmlBodyStylesApplierHandler.LowestAndHighest lowestAndHighest = this.pageStylesPropertiesMap.Get<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(page).lowestAndHighest;
      if (lowestAndHighest == null)
      {
        this.pageStylesPropertiesMap.Get<int, HtmlBodyStylesApplierHandler.PageStylesProperties>(page).lowestAndHighest = new HtmlBodyStylesApplierHandler.LowestAndHighest(rectangle.GetY(), rectangle.GetY() + rectangle.GetHeight());
      }
      else
      {
        float y = rectangle.GetY();
        float val1 = rectangle.GetY() + rectangle.GetHeight();
        lowestAndHighest.lowest = Math.Min(y, lowestAndHighest.lowest);
        lowestAndHighest.highest = Math.Max(val1, lowestAndHighest.highest);
      }
    }

    private static bool IsRunningElementsOnly(IRenderer waitingElement)
    {
      bool flag;
      if (flag = waitingElement is ParagraphRenderer && !waitingElement.GetChildRenderers().IsEmpty<IRenderer>())
      {
        IList<IRenderer> childRenderers = waitingElement.GetChildRenderers();
        int num = 0;
        while (flag && num < childRenderers.Count)
          flag = childRenderers[num++] is RunningElement.RunningElementRenderer;
      }
      return flag;
    }

    private bool IsPageLeft(int pageNum) => this.evenPagesAreLeft == (pageNum % 2 == 0);

    private bool IsPageRight(int pageNum) => !this.IsPageLeft(pageNum);

    private class PageMarginBoxesDrawingHandler : IEventHandler
    {
      private HtmlDocumentRenderer htmlDocumentRenderer;

      internal virtual HtmlDocumentRenderer.PageMarginBoxesDrawingHandler SetHtmlDocumentRenderer(
        HtmlDocumentRenderer htmlDocumentRenderer)
      {
        this.htmlDocumentRenderer = htmlDocumentRenderer;
        return this;
      }

      public virtual void HandleEvent(Event @event)
      {
        if (!(@event is PdfDocumentEvent))
          return;
        PdfPage page = ((PdfDocumentEvent) @event).GetPage();
        PdfDocument document = ((PdfDocumentEvent) @event).GetDocument();
        int pageNumber = document.GetPageNumber(page);
        this.ProcessPage(document, pageNumber);
      }

      internal virtual void ProcessPage(PdfDocument pdfDoc, int pageNumber)
      {
        this.htmlDocumentRenderer.GetPageProcessor(pageNumber).ProcessPageEnd(pageNumber, pdfDoc, (DocumentRenderer) this.htmlDocumentRenderer);
      }
    }
  }
}
