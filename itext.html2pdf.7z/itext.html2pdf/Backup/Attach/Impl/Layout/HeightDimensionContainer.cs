﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.HeightDimensionContainer
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Geom;
using iText.Layout.Layout;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class HeightDimensionContainer : DimensionContainer
  {
    private const float infHeight = 1000000f;

    internal HeightDimensionContainer(
      CssContextNode pmbcNode,
      float width,
      float maxHeight,
      IRenderer renderer,
      float additionalWidthFix)
    {
      string content = pmbcNode.GetStyles().Get<string, string>("height");
      if (content != null && !"auto".Equals(content))
        this.dimension = this.ParseDimension(pmbcNode, content, maxHeight, additionalWidthFix);
      this.minDimension = this.GetMinHeight(pmbcNode, maxHeight, additionalWidthFix);
      this.maxDimension = this.GetMaxHeight(pmbcNode, maxHeight, additionalWidthFix);
      if (!this.IsAutoDimension())
      {
        this.maxContentDimension = this.dimension;
        this.maxContentDimension = this.dimension;
      }
      else
      {
        LayoutContext layoutContext = new LayoutContext(new LayoutArea(1, new Rectangle(0.0f, 0.0f, width, 1000000f)));
        LayoutResult layoutResult = renderer.Layout(layoutContext);
        if (layoutResult.GetStatus() == 3)
          return;
        this.maxContentDimension = layoutResult.GetOccupiedArea().GetBBox().GetHeight();
        this.minContentDimension = this.maxContentDimension;
      }
    }

    private float GetMinHeight(
      CssContextNode node,
      float maxAvailableHeight,
      float additionalWidthFix)
    {
      string content = node.GetStyles().Get<string, string>("min-height");
      return content == null ? 0.0f : this.ParseDimension(node, content, maxAvailableHeight, additionalWidthFix);
    }

    private float GetMaxHeight(
      CssContextNode node,
      float maxAvailableHeight,
      float additionalWidthFix)
    {
      string content = node.GetStyles().Get<string, string>("max-height");
      if (content == null)
        return float.MaxValue;
      float dimension = this.ParseDimension(node, content, maxAvailableHeight, additionalWidthFix);
      return (double) dimension == 0.0 ? float.MaxValue : dimension;
    }
  }
}
