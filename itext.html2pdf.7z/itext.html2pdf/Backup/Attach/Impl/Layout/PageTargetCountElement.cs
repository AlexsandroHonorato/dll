﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageTargetCountElement
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Html2pdf.Html;
using iText.Layout.Element;
using iText.Layout.Renderer;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class PageTargetCountElement : Text
  {
    private readonly string target;
    private readonly CounterDigitsGlyphStyle digitsGlyphStyle;

    public PageTargetCountElement(string target)
      : base("1234567890")
    {
      this.target = target.Replace("'", "").Replace("#", "");
      this.digitsGlyphStyle = CounterDigitsGlyphStyle.DEFAULT;
    }

    public PageTargetCountElement(string target, CounterDigitsGlyphStyle digitsGlyphStyle)
      : base(HtmlUtils.GetAllNumberGlyphsForStyle(digitsGlyphStyle))
    {
      this.target = target.Replace("'", "").Replace("#", "");
      this.digitsGlyphStyle = digitsGlyphStyle;
    }

    public virtual string GetTarget() => this.target;

    public virtual CounterDigitsGlyphStyle GetDigitsGlyphStyle() => this.digitsGlyphStyle;

    protected override IRenderer MakeNewRenderer() => (IRenderer) new PageTargetCountRenderer(this);
  }
}
