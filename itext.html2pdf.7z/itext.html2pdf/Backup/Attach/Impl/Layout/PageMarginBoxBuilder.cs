﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageMarginBoxBuilder
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Css.Page;
using iText.Html2pdf.Css.Resolve;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Minmaxwidth;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageMarginBoxBuilder
  {
    internal IRenderer[] renderers;
    internal PageMarginBoxContextNode[] nodes;
    internal float[] margins;
    internal PageSize pageSize;
    internal IList<PageMarginBoxContextNode> resolvedPageMarginBoxes;
    private const float EPSILON = 1E-05f;

    public PageMarginBoxBuilder(
      IList<PageMarginBoxContextNode> resolvedPageMarginBoxes,
      float[] margins,
      PageSize pageSize)
    {
      this.resolvedPageMarginBoxes = resolvedPageMarginBoxes;
      this.margins = margins;
      this.pageSize = pageSize;
      Rectangle[] rectanglesCornersOnly = this.CalculateMarginBoxRectanglesCornersOnly();
      foreach (PageMarginBoxContextNode resolvedPageMarginBox in (IEnumerable<PageMarginBoxContextNode>) this.resolvedPageMarginBoxes)
      {
        int marginBoxInd = !((CssContextNode) resolvedPageMarginBox).ChildNodes().IsEmpty<INode>() ? this.MapMarginBoxNameToIndex(resolvedPageMarginBox.GetMarginBoxName()) : throw new InvalidOperationException();
        if (rectanglesCornersOnly[marginBoxInd] != null)
          resolvedPageMarginBox.SetPageMarginBoxRectangle(new Rectangle(rectanglesCornersOnly[marginBoxInd]).IncreaseHeight(1E-05f));
        resolvedPageMarginBox.SetContainingBlockForMarginBox(this.CalculateContainingBlockSizesForMarginBox(marginBoxInd, rectanglesCornersOnly[marginBoxInd]));
      }
    }

    public virtual void BuildForSinglePage(
      int pageNumber,
      PdfDocument pdfDocument,
      DocumentRenderer documentRenderer,
      ProcessorContext context)
    {
      if (this.resolvedPageMarginBoxes.IsEmpty<PageMarginBoxContextNode>())
        return;
      this.nodes = new PageMarginBoxContextNode[16];
      foreach (PageMarginBoxContextNode resolvedPageMarginBox in (IEnumerable<PageMarginBoxContextNode>) this.resolvedPageMarginBoxes)
        this.nodes[this.MapMarginBoxNameToIndex(resolvedPageMarginBox.GetMarginBoxName())] = resolvedPageMarginBox;
      IElement[] elements = new IElement[16];
      for (int index = 0; index < 16; ++index)
      {
        if (this.nodes[index] != null)
          elements[index] = this.ProcessMarginBoxContent(this.nodes[index], pageNumber, context);
      }
      this.GetPMBRenderers(elements, documentRenderer, pdfDocument);
    }

    public virtual IRenderer[] GetRenderers() => this.renderers;

    public virtual PageMarginBoxContextNode[] GetNodes() => this.nodes;

    private IElement ProcessMarginBoxContent(
      PageMarginBoxContextNode marginBoxContentNode,
      int pageNumber,
      ProcessorContext context)
    {
      ((CssContextNode) marginBoxContentNode).SetStyles(((CssContextNode) marginBoxContentNode).GetStyles());
      DefaultCssResolver defaultCssResolver = new DefaultCssResolver((INode) marginBoxContentNode, context);
      ITagWorker tagWorker1 = context.GetTagWorkerFactory().GetTagWorker((IElementNode) marginBoxContentNode, context);
      for (int index = 0; index < ((CssContextNode) marginBoxContentNode).ChildNodes().Count; ++index)
      {
        INode childNode = ((CssContextNode) marginBoxContentNode).ChildNodes()[index];
        switch (childNode)
        {
          case ITextNode _:
            string content = ((ITextNode) ((CssContextNode) marginBoxContentNode).ChildNodes()[index]).WholeText();
            tagWorker1.ProcessContent(content, context);
            break;
          case IElementNode _:
            ITagWorker tagWorker2 = context.GetTagWorkerFactory().GetTagWorker((IElementNode) childNode, context);
            if (tagWorker2 != null)
            {
              IDictionary<string, string> dictionary = defaultCssResolver.ResolveStyles(childNode, (AbstractCssContext) context.GetCssContext());
              ((IStylesContainer) childNode).SetStyles(dictionary);
              context.GetCssApplierFactory().GetCssApplier((IElementNode) childNode)?.Apply(context, (IStylesContainer) childNode, tagWorker2);
              tagWorker2.ProcessEnd((IElementNode) childNode, context);
              tagWorker1.ProcessTagChild(tagWorker2, context);
              break;
            }
            break;
          case PageMarginRunningElementNode _:
            PageMarginRunningElementNode runningElementNode = (PageMarginRunningElementNode) childNode;
            RunningElementContainer runningElement = context.GetCssContext().GetRunningManager().GetRunningElement(runningElementNode.GetRunningElementName(), runningElementNode.GetRunningElementOccurrence(), pageNumber);
            if (runningElement != null)
            {
              tagWorker1.ProcessTagChild(runningElement.GetProcessedElementWorker(), context);
              break;
            }
            break;
          default:
            LoggerExtensions.LogError(ITextLogManager.GetLogger(this.GetType()), "Unknown margin box child", Array.Empty<object>());
            break;
        }
      }
      tagWorker1.ProcessEnd((IElementNode) marginBoxContentNode, context);
      if (!(tagWorker1.GetElementResult() is IElement))
        throw new InvalidOperationException("Custom tag worker implementation for margin boxes shall return IElement for #getElementResult() call.");
      context.GetCssApplierFactory().GetCssApplier((IElementNode) marginBoxContentNode).Apply(context, (IStylesContainer) marginBoxContentNode, tagWorker1);
      return (IElement) tagWorker1.GetElementResult();
    }

    private void GetPMBRenderers(
      IElement[] elements,
      DocumentRenderer documentRenderer,
      PdfDocument pdfDocument)
    {
      this.renderers = new IRenderer[16];
      for (int index1 = 0; index1 < 4; ++index1)
      {
        this.renderers[index1 * 4] = this.CreateCornerRenderer(elements[index1 * 4], documentRenderer, pdfDocument, index1);
        for (int index2 = 1; index2 <= 3; ++index2)
          this.renderers[index1 * 4 + index2] = this.CreateRendererFromElement(elements[index1 * 4 + index2], documentRenderer, pdfDocument);
        this.DetermineSizes(index1);
      }
    }

    private IRenderer CreateCornerRenderer(
      IElement cornerBoxElement,
      DocumentRenderer documentRenderer,
      PdfDocument pdfDocument,
      int indexOfCorner)
    {
      IRenderer rendererFromElement = this.CreateRendererFromElement(cornerBoxElement, documentRenderer, pdfDocument);
      if (rendererFromElement == null)
        return (IRenderer) null;
      float num1 = this.margins[indexOfCorner % 3 == 0 ? 3 : 1] - this.GetSizeOfOneSide(rendererFromElement, 44, 11, 48) - this.GetSizeOfOneSide(rendererFromElement, 45, 12, 49);
      float num2 = this.margins[indexOfCorner > 1 ? 2 : 0] - this.GetSizeOfOneSide(rendererFromElement, 46, 13, 50) - this.GetSizeOfOneSide(rendererFromElement, 43, 10, 47);
      rendererFromElement.SetProperty(77, (object) UnitValue.CreatePointValue(num1));
      rendererFromElement.SetProperty(27, (object) UnitValue.CreatePointValue(num2));
      return rendererFromElement;
    }

    private IRenderer CreateRendererFromElement(
      IElement element,
      DocumentRenderer documentRenderer,
      PdfDocument pdfDocument)
    {
      if (element == null)
        return (IRenderer) null;
      IRenderer rendererSubTree = element.CreateRendererSubTree();
      PageMarginBoxBuilder.RemoveAreaBreaks(rendererSubTree);
      rendererSubTree.SetParent((IRenderer) documentRenderer);
      if (pdfDocument.IsTagged())
        LayoutTaggingHelper.AddTreeHints(rendererSubTree.GetProperty<LayoutTaggingHelper>(108), rendererSubTree);
      return rendererSubTree;
    }

    private static void RemoveAreaBreaks(IRenderer renderer)
    {
      IList<IRenderer> c = (IList<IRenderer>) null;
      foreach (IRenderer childRenderer in (IEnumerable<IRenderer>) renderer.GetChildRenderers())
      {
        if (childRenderer is AreaBreakRenderer)
        {
          if (c == null)
            c = (IList<IRenderer>) new List<IRenderer>();
          c.Add(childRenderer);
        }
        else
          PageMarginBoxBuilder.RemoveAreaBreaks(childRenderer);
      }
      if (c == null)
        return;
      renderer.GetChildRenderers().RemoveAll<IRenderer>((ICollection<IRenderer>) c);
    }

    private void DetermineSizes(int side)
    {
      float[][] numArray = new float[3][]
      {
        new float[4],
        new float[4],
        new float[4]
      };
      for (int index = 0; index < 3; ++index)
      {
        if (this.renderers[side * 4 + index + 1] != null)
        {
          numArray[index][0] = this.GetSizeOfOneSide(this.renderers[side * 4 + index + 1], 46, 13, 50);
          numArray[index][1] = this.GetSizeOfOneSide(this.renderers[side * 4 + index + 1], 45, 12, 49);
          numArray[index][2] = this.GetSizeOfOneSide(this.renderers[side * 4 + index + 1], 43, 10, 47);
          numArray[index][3] = this.GetSizeOfOneSide(this.renderers[side * 4 + index + 1], 44, 11, 48);
        }
      }
      Rectangle withoutMargins = ((Rectangle) this.pageSize).Clone().ApplyMargins(this.margins[0], this.margins[1], this.margins[2], this.margins[3], false);
      IDictionary<string, PageMarginBoxContextNode> col = (IDictionary<string, PageMarginBoxContextNode>) new Dictionary<string, PageMarginBoxContextNode>();
      for (int index = side * 4 + 1; index < side * 4 + 4; ++index)
      {
        if (this.nodes[index] != null)
          col.Put<string, PageMarginBoxContextNode>(this.nodes[index].GetMarginBoxName(), this.nodes[index]);
      }
      DimensionContainer[] dimensionContainerArray = new DimensionContainer[3];
      string[] ruleNames = this.GetRuleNames(side);
      float num = side % 2 == 0 ? withoutMargins.GetWidth() : withoutMargins.GetHeight();
      for (int index = 0; index < 3; ++index)
        dimensionContainerArray[index] = side % 2 != 0 ? this.RetrievePageMarginBoxHeights(col.Get<string, PageMarginBoxContextNode>(ruleNames[index]), this.renderers[side * 4 + index + 1], this.margins[side], num, numArray[index][0] + numArray[index][2]) : this.RetrievePageMarginBoxWidths(col.Get<string, PageMarginBoxContextNode>(ruleNames[index]), this.renderers[side * 4 + index + 1], num, numArray[index][1] + numArray[index][3]);
      float[] marginBoxDimensions = this.CalculatePageMarginBoxDimensions(dimensionContainerArray[0], dimensionContainerArray[1], dimensionContainerArray[2], num);
      float centerOrMiddleCoord = side % 2 != 0 ? this.GetStartCoordForCenterOrMiddleBox(num, marginBoxDimensions[1], withoutMargins.GetBottom()) : this.GetStartCoordForCenterOrMiddleBox(num, marginBoxDimensions[1], withoutMargins.GetLeft());
      Rectangle[] rectangles = this.GetRectangles(side, withoutMargins, centerOrMiddleCoord, marginBoxDimensions);
      for (int index = 0; index < 3; ++index)
      {
        if (this.nodes[side * 4 + index + 1] != null)
        {
          this.nodes[side * 4 + index + 1].SetPageMarginBoxRectangle(new Rectangle(rectangles[index]).IncreaseHeight(1E-05f));
          UnitValue pointValue1 = UnitValue.CreatePointValue(rectangles[index].GetWidth() - numArray[index][1] - numArray[index][3]);
          UnitValue pointValue2 = UnitValue.CreatePointValue(rectangles[index].GetHeight() - numArray[index][0] - numArray[index][2]);
          if ((double) Math.Abs(pointValue1.GetValue()) < 9.9999997473787516E-06 || (double) Math.Abs(pointValue2.GetValue()) < 9.9999997473787516E-06)
          {
            this.renderers[side * 4 + index + 1] = (IRenderer) null;
          }
          else
          {
            this.renderers[side * 4 + index + 1].SetProperty(77, (object) pointValue1);
            this.renderers[side * 4 + index + 1].SetProperty(27, (object) pointValue2);
          }
        }
      }
    }

    private string[] GetRuleNames(int side)
    {
      switch (side)
      {
        case 0:
          return new string[3]
          {
            "top-left",
            "top-center",
            "top-right"
          };
        case 1:
          return new string[3]
          {
            "right-top",
            "right-middle",
            "right-bottom"
          };
        case 2:
          return new string[3]
          {
            "bottom-right",
            "bottom-center",
            "bottom-left"
          };
        case 3:
          return new string[3]
          {
            "left-bottom",
            "left-middle",
            "left-top"
          };
        default:
          return new string[3];
      }
    }

    private Rectangle[] GetRectangles(
      int side,
      Rectangle withoutMargins,
      float centerOrMiddleCoord,
      float[] results)
    {
      switch (side)
      {
        case 0:
          return new Rectangle[3]
          {
            new Rectangle(withoutMargins.GetLeft(), withoutMargins.GetTop(), results[0], this.margins[0]),
            new Rectangle(centerOrMiddleCoord, withoutMargins.GetTop(), results[1], this.margins[0]),
            new Rectangle(withoutMargins.GetRight() - results[2], withoutMargins.GetTop(), results[2], this.margins[0])
          };
        case 1:
          return new Rectangle[3]
          {
            new Rectangle(withoutMargins.GetRight(), withoutMargins.GetTop() - results[0], this.margins[1], results[0]),
            new Rectangle(withoutMargins.GetRight(), centerOrMiddleCoord, this.margins[1], results[1]),
            new Rectangle(withoutMargins.GetRight(), withoutMargins.GetBottom(), this.margins[1], results[2])
          };
        case 2:
          return new Rectangle[3]
          {
            new Rectangle(withoutMargins.GetRight() - results[0], 0.0f, results[0], this.margins[2]),
            new Rectangle(centerOrMiddleCoord, 0.0f, results[1], this.margins[2]),
            new Rectangle(withoutMargins.GetLeft(), 0.0f, results[2], this.margins[2])
          };
        case 3:
          return new Rectangle[3]
          {
            new Rectangle(0.0f, withoutMargins.GetBottom(), this.margins[3], results[0]),
            new Rectangle(0.0f, centerOrMiddleCoord, this.margins[3], results[1]),
            new Rectangle(0.0f, withoutMargins.GetTop() - results[2], this.margins[3], results[2])
          };
        default:
          return new Rectangle[3];
      }
    }

    private float GetSizeOfOneSide(
      IRenderer renderer,
      int marginProperty,
      int borderProperty,
      int paddingProperty)
    {
      float num1 = 0.0f;
      float num2 = 0.0f;
      float num3 = 0.0f;
      UnitValue property1 = renderer.GetProperty<UnitValue>(marginProperty);
      if (property1 != null)
        num1 = property1.GetValue();
      UnitValue property2 = renderer.GetProperty<UnitValue>(paddingProperty);
      if (property2 != null)
        num2 = property2.GetValue();
      Border property3 = renderer.GetProperty<Border>(borderProperty);
      if (property3 != null)
        num3 = property3.GetWidth();
      return num1 + num2 + num3;
    }

    private DimensionContainer RetrievePageMarginBoxWidths(
      PageMarginBoxContextNode pmbcNode,
      IRenderer renderer,
      float maxWidth,
      float additionalWidthFix)
    {
      return pmbcNode == null ? (DimensionContainer) null : (DimensionContainer) new WidthDimensionContainer((CssContextNode) pmbcNode, maxWidth, renderer, additionalWidthFix);
    }

    private DimensionContainer RetrievePageMarginBoxHeights(
      PageMarginBoxContextNode pmbcNode,
      IRenderer renderer,
      float marginWidth,
      float maxHeight,
      float additionalHeightFix)
    {
      return pmbcNode == null ? (DimensionContainer) null : (DimensionContainer) new HeightDimensionContainer((CssContextNode) pmbcNode, marginWidth, maxHeight, renderer, additionalHeightFix);
    }

    private float[] CalculatePageMarginBoxDimensions(
      DimensionContainer dimA,
      DimensionContainer dimB,
      DimensionContainer dimC,
      float availableDimension)
    {
      float val1_1 = 0.0f;
      float val1_2 = 0.0f;
      float num1 = 0.0f;
      float val2_1 = 0.0f;
      float[] dimensions = new float[3];
      if (this.IsContainerEmpty(dimA) && this.IsContainerEmpty(dimB) && this.IsContainerEmpty(dimC))
        return dimensions;
      if (this.IsContainerEmpty(dimB))
      {
        if (this.IsContainerEmpty(dimA))
          dimensions[2] = !dimC.IsAutoDimension() ? dimC.dimension : availableDimension;
        else if (this.IsContainerEmpty(dimC))
          dimensions[0] = !dimA.IsAutoDimension() ? dimA.dimension : availableDimension;
        else if (dimA.IsAutoDimension() && dimC.IsAutoDimension())
        {
          float[] numArray = this.DistributeDimensionBetweenTwoBoxes(dimA.maxContentDimension, dimA.minContentDimension, dimC.maxContentDimension, dimC.minContentDimension, availableDimension);
          dimensions = new float[3]
          {
            numArray[0],
            0.0f,
            numArray[1]
          };
        }
        else
        {
          dimensions[0] = dimA.IsAutoDimension() ? availableDimension - dimC.dimension : dimA.dimension;
          dimensions[2] = dimC.IsAutoDimension() ? availableDimension - dimA.dimension : dimC.dimension;
        }
      }
      else
      {
        if (!this.IsContainerEmpty(dimA))
        {
          if (dimA.IsAutoDimension())
          {
            val1_1 = dimA.maxContentDimension;
            val1_2 = dimA.minContentDimension;
          }
          else
          {
            val1_1 = dimA.dimension;
            val1_2 = dimA.dimension;
          }
        }
        if (!this.IsContainerEmpty(dimC))
        {
          if (dimC.IsAutoDimension())
          {
            num1 = dimC.maxContentDimension;
            val2_1 = dimC.minContentDimension;
          }
          else
          {
            num1 = dimC.dimension;
            val2_1 = dimC.dimension;
          }
        }
        if (dimB.IsAutoDimension())
        {
          float maxContentDimensionC = 2f * Math.Max(val1_1, num1);
          float minContentDimensionC = 2f * Math.Max(val1_2, val2_1);
          float[] numArray = this.DistributeDimensionBetweenTwoBoxes(dimB.maxContentDimension, dimB.minContentDimension, maxContentDimensionC, minContentDimensionC, availableDimension);
          float num2 = (float) (((double) availableDimension - (double) numArray[0]) / 2.0);
          dimensions = new float[3]
          {
            num2,
            numArray[0],
            num2
          };
        }
        else
        {
          dimensions[1] = dimB.dimension;
          float val2_2 = (float) (((double) availableDimension - (double) dimensions[1]) / 2.0);
          if ((double) val2_2 > 3.4028234663852886E+38 - (double) MinMaxWidthUtils.GetEps())
            val2_2 = float.MaxValue - MinMaxWidthUtils.GetEps();
          dimensions[0] = Math.Min(val1_1, val2_2) + MinMaxWidthUtils.GetEps();
          dimensions[2] = Math.Min(num1, val2_2) + MinMaxWidthUtils.GetEps();
        }
        this.SetManualDimension(dimA, dimensions, 0);
        this.SetManualDimension(dimC, dimensions, 2);
      }
      if (this.RecalculateIfNecessary(dimA, dimensions, 0) || this.RecalculateIfNecessary(dimB, dimensions, 1) || this.RecalculateIfNecessary(dimC, dimensions, 2))
        return this.CalculatePageMarginBoxDimensions(dimA, dimB, dimC, availableDimension);
      this.RemoveNegativeValues(dimensions);
      return dimensions;
    }

    private bool IsContainerEmpty(DimensionContainer container)
    {
      return container == null || (double) Math.Abs(container.maxContentDimension) < 9.9999997473787516E-06;
    }

    private void RemoveNegativeValues(float[] dimensions)
    {
      for (int index = 0; index < dimensions.Length; ++index)
      {
        if ((double) dimensions[index] < 0.0)
          dimensions[index] = 0.0f;
      }
    }

    private float GetStartCoordForCenterOrMiddleBox(
      float availableDimension,
      float dimensionResult,
      float offset)
    {
      return offset + (float) (((double) availableDimension - (double) dimensionResult) / 2.0);
    }

    private void SetManualDimension(DimensionContainer dim, float[] dimensions, int index)
    {
      if (dim == null || dim.IsAutoDimension())
        return;
      dimensions[index] = dim.dimension;
    }

    private float[] DistributeDimensionBetweenTwoBoxes(
      float maxContentDimensionA,
      float minContentDimensionA,
      float maxContentDimensionC,
      float minContentDimensionC,
      float availableDimension)
    {
      float sum1 = maxContentDimensionA + maxContentDimensionC;
      float sum2 = minContentDimensionA + minContentDimensionC;
      if ((double) sum1 < (double) availableDimension)
        return this.CalculateDistribution(maxContentDimensionA, maxContentDimensionC, maxContentDimensionA, maxContentDimensionC, sum1, availableDimension);
      return (double) sum2 < (double) availableDimension ? this.CalculateDistribution(minContentDimensionA, minContentDimensionC, maxContentDimensionA - minContentDimensionA, maxContentDimensionC - minContentDimensionC, sum1 - sum2, availableDimension) : this.CalculateDistribution(minContentDimensionA, minContentDimensionC, minContentDimensionA, minContentDimensionC, sum2, availableDimension);
    }

    private float[] CalculateDistribution(
      float argA,
      float argC,
      float flexA,
      float flexC,
      float sum,
      float availableDimension)
    {
      float num1;
      float num2;
      if (CssUtils.CompareFloats(sum, 0.0f))
      {
        num1 = 1f;
        num2 = 1f;
      }
      else
      {
        num1 = flexA / sum;
        num2 = flexC / sum;
      }
      float num3 = availableDimension - (argA + argC);
      return new float[2]
      {
        argA + num1 * num3,
        argC + num2 * num3
      };
    }

    private bool RecalculateIfNecessary(DimensionContainer dim, float[] dimensions, int index)
    {
      if (dim != null)
      {
        if ((double) dimensions[index] < (double) dim.minDimension && dim.IsAutoDimension())
        {
          dim.dimension = dim.minDimension;
          return true;
        }
        if ((double) dimensions[index] > (double) dim.maxDimension && dim.IsAutoDimension())
        {
          dim.dimension = dim.maxDimension;
          return true;
        }
      }
      return false;
    }

    private Rectangle[] CalculateMarginBoxRectanglesCornersOnly()
    {
      float margin1 = this.margins[0];
      float margin2 = this.margins[1];
      float margin3 = this.margins[2];
      float margin4 = this.margins[3];
      Rectangle rectangle1 = ((Rectangle) this.pageSize).Clone().ApplyMargins(margin1, margin2, margin3, margin4, false);
      Rectangle rectangle2 = new Rectangle(0.0f, rectangle1.GetTop(), margin4, margin1);
      Rectangle rectangle3 = new Rectangle(rectangle1.GetRight(), rectangle1.GetTop(), margin2, margin1);
      Rectangle rectangle4 = new Rectangle(0.0f, 0.0f, margin4, margin3);
      Rectangle rectangle5 = new Rectangle(rectangle1.GetRight(), 0.0f, margin2, margin3);
      Rectangle[] rectanglesCornersOnly = new Rectangle[16];
      rectanglesCornersOnly[0] = rectangle2;
      rectanglesCornersOnly[4] = rectangle3;
      rectanglesCornersOnly[8] = rectangle5;
      rectanglesCornersOnly[12] = rectangle4;
      return rectanglesCornersOnly;
    }

    private Rectangle CalculateContainingBlockSizesForMarginBox(
      int marginBoxInd,
      Rectangle pageMarginBoxRectangle)
    {
      if (marginBoxInd == 0 || marginBoxInd == 4 || marginBoxInd == 8 || marginBoxInd == 12)
        return pageMarginBoxRectangle;
      Rectangle rectangle = ((Rectangle) this.pageSize).Clone().ApplyMargins(this.margins[0], this.margins[1], this.margins[2], this.margins[3], false);
      if (marginBoxInd < 4)
        return new Rectangle(rectangle.GetWidth(), this.margins[0]);
      if (marginBoxInd < 8)
        return new Rectangle(this.margins[1], rectangle.GetHeight());
      return marginBoxInd < 12 ? new Rectangle(rectangle.GetWidth(), this.margins[2]) : new Rectangle(this.margins[3], rectangle.GetHeight());
    }

    internal virtual int MapMarginBoxNameToIndex(string marginBoxName)
    {
      switch (marginBoxName)
      {
        case "bottom-center":
          return 10;
        case "bottom-left":
          return 11;
        case "bottom-left-corner":
          return 12;
        case "bottom-right":
          return 9;
        case "bottom-right-corner":
          return 8;
        case "left-bottom":
          return 13;
        case "left-middle":
          return 14;
        case "left-top":
          return 15;
        case "right-bottom":
          return 7;
        case "right-middle":
          return 6;
        case "right-top":
          return 5;
        case "top-center":
          return 2;
        case "top-left":
          return 1;
        case "top-left-corner":
          return 0;
        case "top-right":
          return 3;
        case "top-right-corner":
          return 4;
        default:
          return -1;
      }
    }
  }
}
