﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageCountType
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public enum PageCountType
  {
    CURRENT_PAGE_NUMBER,
    TOTAL_PAGE_COUNT,
  }
}
