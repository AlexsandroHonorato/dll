﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.Html2PdfProperty
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  public class Html2PdfProperty
  {
    private const int PROPERTY_START = 1048576;
    public const int KEEP_WITH_PREVIOUS = 1048577;
    public const int PAGE_COUNT_TYPE = 1048578;
    public const int BODY_STYLING = 1048579;
    public const int HTML_STYLING = 1048580;
    public const int CAPITALIZE_ELEMENT = 1048581;
  }
}
