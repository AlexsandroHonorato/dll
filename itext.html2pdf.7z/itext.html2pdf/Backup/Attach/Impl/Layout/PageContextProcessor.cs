﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Layout.PageContextProcessor
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Css.Apply.Impl;
using iText.Html2pdf.Css.Apply.Util;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Kernel.Pdf.Tagutils;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Layout;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Page;
using iText.StyledXmlParser.Css.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Layout
{
  internal class PageContextProcessor
  {
    private PageSize pageSize;
    private ICollection<string> marks;
    private float? bleed;
    private float[] margins;
    private Border[] borders;
    private float[] paddings;
    private Div pageBackgroundSimulation;
    private Div pageBordersSimulation;
    private PageContextProperties properties;
    private ProcessorContext context;
    private PageMarginBoxBuilder pageMarginBoxHelper;
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (PageContextProcessor));

    internal PageContextProcessor(
      PageContextProperties properties,
      ProcessorContext context,
      PageSize defaultPageSize,
      float[] defaultPageMargins)
    {
      this.properties = properties;
      this.context = context;
      this.Reset(defaultPageSize, defaultPageMargins);
    }

    private static ICollection<string> ParseMarks(string marksStr)
    {
      ICollection<string> marks = (ICollection<string>) new HashSet<string>();
      if (marksStr == null)
        return marks;
      foreach (string str in StringUtil.Split(marksStr, " "))
      {
        if ("crop".Equals(str) || "cross".Equals(str))
        {
          marks.Add(str);
        }
        else
        {
          marks.Clear();
          break;
        }
      }
      return marks;
    }

    internal virtual PageContextProcessor Reset(
      PageSize defaultPageSize,
      float[] defaultPageMargins)
    {
      IDictionary<string, string> styles = ((CssContextNode) this.properties.GetResolvedPageContextNode()).GetStyles();
      float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(styles.Get<string, string>("font-size"));
      float rootFontSize = this.context.GetCssContext().GetRootFontSize();
      this.pageSize = PageSizeParser.FetchPageSize(styles.Get<string, string>("size"), absoluteLength, rootFontSize, defaultPageSize);
      UnitValue lengthValueToPt = CssDimensionParsingUtils.ParseLengthValueToPt(styles.Get<string, string>("bleed"), absoluteLength, rootFontSize);
      if (lengthValueToPt != null && lengthValueToPt.IsPointValue())
        this.bleed = new float?(lengthValueToPt.GetValue());
      this.marks = PageContextProcessor.ParseMarks(styles.Get<string, string>("marks"));
      this.ParseMargins(styles, absoluteLength, rootFontSize, defaultPageMargins);
      this.ParseBorders(styles, absoluteLength, rootFontSize);
      this.ParsePaddings(styles, absoluteLength, rootFontSize);
      this.CreatePageSimulationElements(styles, this.context);
      this.pageMarginBoxHelper = new PageMarginBoxBuilder(this.properties.GetResolvedPageMarginBoxes(), this.margins, this.pageSize);
      return this;
    }

    internal virtual PageSize GetPageSize() => this.pageSize;

    internal virtual float[] ComputeLayoutMargins()
    {
      float[] layoutMargins = JavaUtil.ArraysCopyOf<float>(this.margins, this.margins.Length);
      for (int index = 0; index < this.borders.Length; ++index)
      {
        float num = this.borders[index] != null ? this.borders[index].GetWidth() : 0.0f;
        layoutMargins[index] += num;
      }
      for (int index = 0; index < this.paddings.Length; ++index)
        layoutMargins[index] += this.paddings[index];
      return layoutMargins;
    }

    internal virtual void ProcessPageEnd(
      int pageNum,
      PdfDocument pdfDocument,
      DocumentRenderer documentRenderer)
    {
      this.DrawMarginBoxes(pageNum, pdfDocument, documentRenderer);
    }

    internal virtual void ProcessNewPage(PdfPage page)
    {
      this.SetBleed(page);
      this.DrawMarks(page);
      this.DrawPageBorders(page);
    }

    internal virtual PdfCanvas DrawPageBackground(PdfPage page)
    {
      PdfCanvas pdfCanvas = (PdfCanvas) null;
      if (this.pageBackgroundSimulation != null)
      {
        pdfCanvas = new PdfCanvas(page.NewContentStreamBefore(), page.GetResources(), page.GetDocument());
        iText.Layout.Canvas canvas = new iText.Layout.Canvas(pdfCanvas, page.GetBleedBox());
        canvas.EnableAutoTagging(page);
        canvas.Add((IBlockElement) this.pageBackgroundSimulation);
        canvas.Close();
      }
      return pdfCanvas;
    }

    private void SetBleed(PdfPage page)
    {
      if (!this.bleed.HasValue && !this.marks.IsEmpty<string>())
        this.bleed = new float?(6f);
      if (!this.bleed.HasValue)
        return;
      Rectangle mediaBox = page.GetMediaBox();
      mediaBox.IncreaseHeight(this.bleed.Value * 2f);
      mediaBox.SetWidth(mediaBox.GetWidth() + this.bleed.Value * 2f);
      page.SetMediaBox(mediaBox).SetBleedBox(mediaBox);
      Rectangle trimBox = page.GetTrimBox();
      trimBox.MoveUp(this.bleed.Value);
      trimBox.MoveRight(this.bleed.Value);
      page.SetTrimBox(trimBox);
    }

    private void DrawMarks(PdfPage page)
    {
      if (this.marks.IsEmpty<string>())
        return;
      float num1 = 48f;
      float num2 = 57f;
      Rectangle mediaBox = page.GetMediaBox();
      mediaBox.IncreaseHeight(num2 * 2f);
      mediaBox.SetWidth(mediaBox.GetWidth() + num1 * 2f);
      page.SetMediaBox(mediaBox);
      Rectangle bleedBox = page.GetBleedBox();
      bleedBox.MoveUp(num2);
      bleedBox.MoveRight(num1);
      page.SetBleedBox(bleedBox);
      Rectangle trimBox = page.GetTrimBox();
      trimBox.MoveUp(num2);
      trimBox.MoveRight(num1);
      page.SetTrimBox(trimBox);
      PdfCanvas canvas = new PdfCanvas(page);
      if (page.GetDocument().IsTagged())
        canvas.OpenTag((CanvasTag) new CanvasArtifact());
      if (this.marks.Contains("crop"))
      {
        float num3 = 24f;
        float num4 = num2 - num3;
        float num5 = num1 - num3;
        canvas.SaveState().SetLineWidth(0.1f).MoveTo((double) trimBox.GetLeft(), (double) num4).LineTo((double) trimBox.GetLeft(), (double) num2).MoveTo((double) num5, (double) trimBox.GetTop()).LineTo((double) num1, (double) trimBox.GetTop()).MoveTo((double) trimBox.GetRight(), (double) num4).LineTo((double) trimBox.GetRight(), (double) num2).MoveTo((double) mediaBox.GetWidth() - (double) num5, (double) trimBox.GetTop()).LineTo((double) mediaBox.GetWidth() - (double) num1, (double) trimBox.GetTop()).MoveTo((double) trimBox.GetLeft(), (double) mediaBox.GetHeight() - (double) num4).LineTo((double) trimBox.GetLeft(), (double) mediaBox.GetHeight() - (double) num2).MoveTo((double) mediaBox.GetWidth() - (double) num5, (double) trimBox.GetBottom()).LineTo((double) mediaBox.GetWidth() - (double) num1, (double) trimBox.GetBottom()).MoveTo((double) trimBox.GetRight(), (double) mediaBox.GetHeight() - (double) num4).LineTo((double) trimBox.GetRight(), (double) mediaBox.GetHeight() - (double) num2).MoveTo((double) num5, (double) trimBox.GetBottom()).LineTo((double) num1, (double) trimBox.GetBottom()).Stroke().RestoreState();
      }
      if (this.marks.Contains("cross"))
      {
        float num6 = num2 - 12f;
        float num7 = num1 - 12f;
        canvas.SaveState().SetLineWidth(0.1f);
        float x1 = mediaBox.GetWidth() / 2f;
        float y1 = mediaBox.GetHeight() - num6;
        this.DrawCross(canvas, x1, y1, true);
        float x2 = mediaBox.GetWidth() / 2f;
        float y2 = num6;
        this.DrawCross(canvas, x2, y2, true);
        float x3 = num7;
        float y3 = mediaBox.GetHeight() / 2f;
        this.DrawCross(canvas, x3, y3, false);
        float x4 = mediaBox.GetWidth() - num7;
        float y4 = mediaBox.GetHeight() / 2f;
        this.DrawCross(canvas, x4, y4, false);
        canvas.RestoreState();
      }
      if (!page.GetDocument().IsTagged())
        return;
      canvas.CloseTag();
    }

    private void DrawCross(PdfCanvas canvas, float x, float y, bool horizontalCross)
    {
      float num1 = 6f;
      float num2;
      float num3;
      if (horizontalCross)
      {
        num2 = 30f;
        num3 = 12f;
      }
      else
      {
        num2 = 12f;
        num3 = 30f;
      }
      canvas.MoveTo((double) x - (double) num2, (double) y).LineTo((double) x + (double) num2, (double) y).MoveTo((double) x, (double) y - (double) num3).LineTo((double) x, (double) y + (double) num3);
      canvas.Circle((double) x, (double) y, (double) num1);
      canvas.Stroke();
    }

    private void DrawPageBorders(PdfPage page)
    {
      if (this.pageBordersSimulation == null)
        return;
      iText.Layout.Canvas canvas = new iText.Layout.Canvas(new PdfCanvas(page), page.GetTrimBox());
      canvas.EnableAutoTagging(page);
      canvas.Add((IBlockElement) this.pageBordersSimulation);
      canvas.Close();
    }

    private void DrawMarginBoxes(
      int pageNumber,
      PdfDocument pdfDocument,
      DocumentRenderer documentRenderer)
    {
      this.pageMarginBoxHelper.BuildForSinglePage(pageNumber, pdfDocument, documentRenderer, this.context);
      if (this.pageMarginBoxHelper.GetRenderers() == null)
        return;
      for (int index = 0; index < 16; ++index)
      {
        if (this.pageMarginBoxHelper.GetRenderers()[index] != null)
          this.Draw(this.pageMarginBoxHelper.GetRenderers()[index], this.pageMarginBoxHelper.GetNodes()[index], pdfDocument, pdfDocument.GetPage(pageNumber), documentRenderer, pageNumber);
      }
    }

    private void Draw(
      IRenderer renderer,
      PageMarginBoxContextNode node,
      PdfDocument pdfDocument,
      PdfPage page,
      DocumentRenderer documentRenderer,
      int pageNumber)
    {
      LayoutResult layoutResult = renderer.Layout(new LayoutContext(new LayoutArea(pageNumber, node.GetPageMarginBoxRectangle())));
      IRenderer renderer1 = layoutResult.GetStatus() == 1 ? renderer : layoutResult.GetSplitRenderer();
      if (renderer1 != null)
      {
        TagTreePointer tagTreePointer1 = (TagTreePointer) null;
        TagTreePointer tagTreePointer2 = (TagTreePointer) null;
        PdfPage pdfPage = (PdfPage) null;
        if (pdfDocument.IsTagged())
        {
          tagTreePointer1 = pdfDocument.GetTagStructureContext().GetAutoTaggingPointer();
          pdfPage = tagTreePointer1.GetCurrentPage();
          tagTreePointer2 = new TagTreePointer(tagTreePointer1);
          tagTreePointer1.MoveToRoot();
          tagTreePointer1.SetPageForTagging(page);
        }
        renderer1.SetParent((IRenderer) documentRenderer).Draw(new DrawContext(page.GetDocument(), new PdfCanvas(page), pdfDocument.IsTagged()));
        if (!pdfDocument.IsTagged())
          return;
        tagTreePointer1.SetPageForTagging(pdfPage);
        tagTreePointer1.MoveToPointer(tagTreePointer2);
      }
      else
        LoggerExtensions.LogError(PageContextProcessor.LOGGER, MessageFormatUtil.Format("Page margin box {0} content cannot be drawn.", new object[1]
        {
          (object) node.GetMarginBoxName()
        }), Array.Empty<object>());
    }

    private void ParseMargins(
      IDictionary<string, string> styles,
      float em,
      float rem,
      float[] defaultMarginValues)
    {
      PageSize pageSize = this.GetPageSize();
      this.margins = PageMarginBoxCssApplier.ParseBoxProps(styles, em, rem, defaultMarginValues, (Rectangle) pageSize, "margin-top", "margin-right", "margin-bottom", "margin-left");
    }

    private void ParsePaddings(IDictionary<string, string> styles, float em, float rem)
    {
      float num = 0.0f;
      PageSize pageSize = this.GetPageSize();
      this.paddings = PageMarginBoxCssApplier.ParseBoxProps(styles, em, rem, new float[4]
      {
        num,
        num,
        num,
        num
      }, (Rectangle) pageSize, "padding-top", "padding-right", "padding-bottom", "padding-left");
    }

    private void ParseBorders(IDictionary<string, string> styles, float em, float rem)
    {
      this.borders = BorderStyleApplierUtil.GetBordersArray(styles, em, rem);
    }

    private void CreatePageSimulationElements(
      IDictionary<string, string> styles,
      ProcessorContext context)
    {
      this.pageBackgroundSimulation = new Div().SetFillAvailableArea(true);
      BackgroundApplierUtil.ApplyBackground(styles, context, (IPropertyContainer) this.pageBackgroundSimulation);
      this.pageBackgroundSimulation.GetAccessibilityProperties().SetRole("Artifact");
      if (!this.pageBackgroundSimulation.HasOwnProperty(6) && !this.pageBackgroundSimulation.HasOwnProperty(90))
        this.pageBackgroundSimulation = (Div) null;
      if (this.borders[0] == null && this.borders[1] == null && this.borders[2] == null && this.borders[3] == null)
      {
        this.pageBordersSimulation = (Div) null;
      }
      else
      {
        this.pageBordersSimulation = new Div().SetFillAvailableArea(true);
        this.pageBordersSimulation.SetMargins(this.margins[0], this.margins[1], this.margins[2], this.margins[3]);
        this.pageBordersSimulation.SetBorderTop(this.borders[0]);
        this.pageBordersSimulation.SetBorderRight(this.borders[1]);
        this.pageBordersSimulation.SetBorderBottom(this.borders[2]);
        this.pageBordersSimulation.SetBorderLeft(this.borders[3]);
        this.pageBordersSimulation.GetAccessibilityProperties().SetRole("Artifact");
      }
    }
  }
}
