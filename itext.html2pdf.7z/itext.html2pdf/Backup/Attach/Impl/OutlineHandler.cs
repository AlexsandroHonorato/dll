﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.OutlineHandler
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Datastructures;
using iText.Commons.Utils;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Node.Impl.Jsoup.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl
{
  public class OutlineHandler
  {
    private const string DEFAULT_DESTINATION_NAME_PREFIX = "pdfHTML-iText-outline-";
    private IDictionary<string, int?> destCounter = (IDictionary<string, int?>) new Dictionary<string, int?>();
    private PdfOutline currentOutline;
    private LinkedList<Tuple2<string, PdfDictionary>> destinationsInProcess = new LinkedList<Tuple2<string, PdfDictionary>>();
    private LinkedList<int> levelsInProcess = new LinkedList<int>();
    private IDictionary<string, int?> tagPrioritiesMapping = (IDictionary<string, int?>) new Dictionary<string, int?>();
    private string destinationNamePrefix = "pdfHTML-iText-outline-";

    public static OutlineHandler CreateStandardHandler()
    {
      OutlineHandler standardHandler = new OutlineHandler();
      standardHandler.PutTagPriorityMapping("h1", new int?(1));
      standardHandler.PutTagPriorityMapping("h2", new int?(2));
      standardHandler.PutTagPriorityMapping("h3", new int?(3));
      standardHandler.PutTagPriorityMapping("h4", new int?(4));
      standardHandler.PutTagPriorityMapping("h5", new int?(5));
      standardHandler.PutTagPriorityMapping("h6", new int?(6));
      return standardHandler;
    }

    public virtual OutlineHandler PutTagPriorityMapping(string tagName, int? priority)
    {
      this.tagPrioritiesMapping.Put<string, int?>(tagName, priority);
      return this;
    }

    public virtual OutlineHandler PutAllTagPriorityMappings(IDictionary<string, int?> mappings)
    {
      this.tagPrioritiesMapping.AddAll<string, int?>(mappings);
      return this;
    }

    public virtual int? GetTagPriorityMapping(string tagName)
    {
      return this.tagPrioritiesMapping.Get<string, int?>(tagName);
    }

    public virtual bool HasTagPriorityMapping(string tagName)
    {
      return this.tagPrioritiesMapping.ContainsKey(tagName);
    }

    public virtual void Reset()
    {
      this.currentOutline = (PdfOutline) null;
      this.destinationsInProcess.Clear();
      this.levelsInProcess.Clear();
      this.destCounter.Clear();
    }

    public virtual void SetDestinationNamePrefix(string destinationNamePrefix)
    {
      this.destinationNamePrefix = destinationNamePrefix;
    }

    public virtual string GetDestinationNamePrefix() => this.destinationNamePrefix;

    protected internal virtual string GenerateUniqueDestinationName(IElementNode element)
    {
      return this.GetUniqueID(this.destinationNamePrefix);
    }

    protected internal virtual string GenerateOutlineName(IElementNode element)
    {
      string key = element.Name();
      string outlineName = ((JsoupElementNode) element).Text();
      if (string.IsNullOrEmpty(outlineName))
        outlineName = this.GetUniqueID(key);
      return outlineName;
    }

    internal virtual OutlineHandler AddOutlineAndDestToDocument(
      ITagWorker tagWorker,
      IElementNode element,
      ProcessorContext context)
    {
      string tagName = element.Name();
      if (tagWorker != null && this.HasTagPriorityMapping(tagName) && context.GetPdfDocument() != null)
      {
        int num = this.GetTagPriorityMapping(tagName).Value;
        if (this.currentOutline == null)
          this.currentOutline = context.GetPdfDocument().GetOutlines(false);
        PdfOutline pdfOutline1 = this.currentOutline;
        while (!this.levelsInProcess.IsEmpty<int>() && num <= this.levelsInProcess.JGetFirst<int>())
        {
          pdfOutline1 = pdfOutline1.GetParent();
          this.levelsInProcess.JRemoveFirst<int>();
        }
        PdfOutline pdfOutline2 = pdfOutline1.AddOutline(this.GenerateOutlineName(element));
        string uniqueDestinationName = this.GenerateUniqueDestinationName(element);
        PdfAction pdfAction = PdfAction.CreateGoTo(uniqueDestinationName);
        pdfOutline2.AddAction(pdfAction);
        this.destinationsInProcess.AddFirst(new Tuple2<string, PdfDictionary>(uniqueDestinationName, ((PdfObjectWrapper<PdfDictionary>) pdfAction).GetPdfObject()));
        this.levelsInProcess.AddFirst(num);
        this.currentOutline = pdfOutline2;
      }
      return this;
    }

    internal virtual OutlineHandler SetDestinationToElement(
      ITagWorker tagWorker,
      IElementNode element)
    {
      string tagName = element.Name();
      if (tagWorker != null && this.HasTagPriorityMapping(tagName) && this.destinationsInProcess.Count > 0)
      {
        Tuple2<string, PdfDictionary> tuple2 = this.destinationsInProcess.JRemoveFirst<Tuple2<string, PdfDictionary>>();
        if (tagWorker.GetElementResult() is IElement)
          tagWorker.GetElementResult().SetProperty(17, (object) tuple2);
        else
          LoggerExtensions.LogWarning(ITextLogManager.GetLogger(typeof (OutlineHandler)), MessageFormatUtil.Format("Tag worker does not produce IPropertyContainer for \"{0}\" tag. An outline for \"{0}\" tag will not be created.", new object[1]
          {
            (object) tagName
          }), Array.Empty<object>());
      }
      return this;
    }

    private string GetUniqueID(string key)
    {
      if (!this.destCounter.ContainsKey(key))
        this.destCounter.Put<string, int?>(key, new int?(1));
      int num = this.destCounter.Get<string, int?>(key).Value;
      this.destCounter.Put<string, int?>(key, new int?(num + 1));
      return key + num.ToString();
    }
  }
}
