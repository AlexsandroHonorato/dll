﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.DefaultHtmlProcessor
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Actions;
using iText.Commons.Actions.Sequence;
using iText.Commons.Utils;
using iText.Forms.Form.Element;
using iText.Html2pdf.Actions.Events;
using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Attach.Impl.Tags;
using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Css.Apply;
using iText.Html2pdf.Css.Apply.Util;
using iText.Html2pdf.Css.Resolve;
using iText.Html2pdf.Exceptions;
using iText.IO.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Font;
using iText.Layout.Properties;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Css.Font;
using iText.StyledXmlParser.Css.Pseudo;
using iText.StyledXmlParser.Css.Resolve;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Util;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl
{
  public class DefaultHtmlProcessor : IHtmlProcessor
  {
    private static readonly ILogger logger = ITextLogManager.GetLogger(typeof (DefaultHtmlProcessor));
    private static readonly ICollection<string> ignoredTags = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[3]
    {
      "head",
      "style",
      "tbody"
    })));
    private static readonly ICollection<string> ignoredCssTags = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[5]
    {
      "br",
      "link",
      "meta",
      "title",
      "tr"
    })));
    private static readonly ICollection<string> ignoredChildTags = (ICollection<string>) JavaCollectionsUtil.UnmodifiableSet<string>((ISet<string>) new HashSet<string>((IEnumerable<string>) JavaUtil.ArraysAsList<string>(new string[5]
    {
      "body",
      "link",
      "meta",
      "script",
      "title"
    })));
    private ProcessorContext context;
    private IList<IPropertyContainer> roots;
    private ICssResolver cssResolver;

    public DefaultHtmlProcessor(ConverterProperties converterProperties)
    {
      this.context = ProcessorContextCreator.CreateProcessorContext(converterProperties);
    }

    public static void SetConvertedRootElementProperties(
      IDictionary<string, string> cssProperties,
      ProcessorContext context,
      IPropertyContainer propertyContainer)
    {
      propertyContainer.SetProperty(89, (object) true);
      propertyContainer.SetProperty(123, (object) RenderingMode.HTML_MODE);
      propertyContainer.SetProperty(91, (object) context.GetFontProvider());
      if (context.GetTempFonts() != null)
        propertyContainer.SetProperty(98, (object) context.GetTempFonts());
      IList<string> col = FontFamilySplitterUtil.SplitFontFamily(cssProperties.Get<string, string>("font-family"));
      if (col == null || propertyContainer.HasOwnProperty(20))
        return;
      propertyContainer.SetProperty(20, (object) col.ToArray<string>(new string[0]));
    }

    public virtual IList<IElement> ProcessElements(INode root)
    {
      SequenceId sequenceId = new SequenceId();
      EventManager.GetInstance().OnEvent((IEvent) PdfHtmlProductEvent.CreateConvertHtmlEvent(sequenceId, this.context.GetMetaInfoContainer().GetMetaInfo()));
      this.context.Reset();
      this.roots = (IList<IPropertyContainer>) new List<IPropertyContainer>();
      this.cssResolver = (ICssResolver) new DefaultCssResolver(root, this.context);
      this.context.GetLinkContext().ScanForIds(root);
      this.AddFontFaceFonts();
      IElementNode htmlNode = this.FindHtmlNode(root);
      IElementNode bodyNode = this.FindBodyNode(root);
      ((IStylesContainer) htmlNode).SetStyles(this.cssResolver.ResolveStyles((INode) htmlNode, (AbstractCssContext) this.context.GetCssContext()));
      this.Visit((INode) bodyNode);
      Div root1 = (Div) this.roots[0];
      IList<IElement> elementList = (IList<IElement>) new List<IElement>();
      ((IStylesContainer) bodyNode).SetStyles(this.cssResolver.ResolveStyles((INode) bodyNode, (AbstractCssContext) this.context.GetCssContext()));
      foreach (IPropertyContainer child in (IEnumerable<IElement>) root1.GetChildren())
      {
        if (child is IElement)
        {
          DefaultHtmlProcessor.SetConvertedRootElementProperties(((IStylesContainer) bodyNode).GetStyles(), this.context, child);
          elementList.Add((IElement) child);
        }
      }
      this.cssResolver = (ICssResolver) null;
      this.roots = (IList<IPropertyContainer>) null;
      foreach (IElement element in (IEnumerable<IElement>) elementList)
        DefaultHtmlProcessor.UpdateSequenceId(element, sequenceId);
      return elementList;
    }

    public virtual Document ProcessDocument(INode root, PdfDocument pdfDocument)
    {
      EventManager.GetInstance().OnEvent((IEvent) PdfHtmlProductEvent.CreateConvertHtmlEvent(pdfDocument.GetDocumentIdWrapper(), this.context.GetMetaInfoContainer().GetMetaInfo()));
      this.context.Reset(pdfDocument);
      if (!this.context.HasFonts())
        throw new Html2PdfException("Font Provider contains zero fonts. At least one font shall be present");
      this.roots = (IList<IPropertyContainer>) new List<IPropertyContainer>();
      this.cssResolver = (ICssResolver) new DefaultCssResolver(root, this.context);
      this.context.GetLinkContext().ScanForIds(root);
      this.AddFontFaceFonts();
      root = (INode) this.FindHtmlNode(root);
      if (this.context.GetCssContext().IsNonPagesTargetCounterPresent())
      {
        this.VisitToProcessCounters(root);
        this.context.GetCssContext().GetCounterManager().ClearManager();
      }
      this.Visit(root);
      HtmlDocument root1 = (HtmlDocument) this.roots[0];
      if (this.context.GetCssContext().IsPagesCounterPresent())
      {
        if (root1.GetRenderer() is HtmlDocumentRenderer)
        {
          ((HtmlDocumentRenderer) root1.GetRenderer()).ProcessWaitingElement();
          int num = 0;
          do
          {
            ++num;
            root1.Relayout();
            if (num >= this.context.GetLimitOfLayouts())
            {
              LoggerExtensions.LogWarning(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("Exceeded the maximum number of relayouts. The resultant document may look not as expected. Because of the content being dynamic iText performs several relayouts to produce correct document.", Array.Empty<object>()), Array.Empty<object>());
              break;
            }
          }
          while (((DocumentRenderer) root1.GetRenderer()).IsRelayoutRequired());
        }
        else
          LoggerExtensions.LogWarning(DefaultHtmlProcessor.logger, "A custom renderer which doesn't extend HtmlDocumentRenderer is set for HtmlDocument. Counters and target-counters may be displayed incorrectly.", Array.Empty<object>());
      }
      this.cssResolver = (ICssResolver) null;
      this.roots = (IList<IPropertyContainer>) null;
      return (Document) root1;
    }

    private void VisitToProcessCounters(INode node)
    {
      if (!(node is IElementNode))
        return;
      IElementNode ielementNode = (IElementNode) node;
      if (this.cssResolver is DefaultCssResolver)
        ((DefaultCssResolver) this.cssResolver).ResolveContentAndCountersStyles(node, this.context.GetCssContext());
      CounterProcessorUtil.StartProcessingCounters(this.context.GetCssContext(), ielementNode);
      this.VisitToProcessCounters((INode) DefaultHtmlProcessor.CreatePseudoElement(ielementNode, (ITagWorker) null, "before"));
      foreach (INode childNode in (IEnumerable<INode>) ((INode) ielementNode).ChildNodes())
      {
        if (!this.context.IsProcessingInlineSvg())
          this.VisitToProcessCounters(childNode);
      }
      this.VisitToProcessCounters((INode) DefaultHtmlProcessor.CreatePseudoElement(ielementNode, (ITagWorker) null, "after"));
      CounterProcessorUtil.EndProcessingCounters(this.context.GetCssContext(), ielementNode);
    }

    private void Visit(INode node)
    {
      switch (node)
      {
        case IElementNode _:
          IElementNode ielementNode = (IElementNode) node;
          ((IStylesContainer) ielementNode).SetStyles(this.cssResolver.ResolveStyles((INode) ielementNode, (AbstractCssContext) this.context.GetCssContext()));
          if (!this.IsDisplayable(ielementNode))
            break;
          ITagWorker tagWorker = this.context.GetTagWorkerFactory().GetTagWorker(ielementNode, this.context);
          if (tagWorker == null)
          {
            if (!DefaultHtmlProcessor.ignoredTags.Contains(ielementNode.Name()))
              LoggerExtensions.LogError(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("No worker found for tag {0}", new object[1]
              {
                (object) ielementNode.Name()
              }), Array.Empty<object>());
          }
          else
            this.context.GetState().Push(tagWorker);
          if (this.context.GetState().GetStack().Count == 1 && tagWorker != null && tagWorker.GetElementResult() != null)
            tagWorker.GetElementResult().SetProperty(135, (object) new MetaInfoContainer(this.context.GetMetaInfoContainer().GetMetaInfo()));
          if (tagWorker is HtmlTagWorker)
            ((HtmlTagWorker) tagWorker).ProcessPageRules(node, this.cssResolver, this.context);
          if ("body".Equals(ielementNode.Name()) || "html".Equals(ielementNode.Name()))
            this.RunApplier(ielementNode, tagWorker);
          this.context.GetOutlineHandler().AddOutlineAndDestToDocument(tagWorker, ielementNode, this.context);
          TextDecorationApplierUtil.PropagateTextDecorationProperties(ielementNode);
          CounterProcessorUtil.StartProcessingCounters(this.context.GetCssContext(), ielementNode);
          this.Visit((INode) DefaultHtmlProcessor.CreatePseudoElement(ielementNode, tagWorker, "before"));
          this.Visit((INode) DefaultHtmlProcessor.CreatePseudoElement(ielementNode, tagWorker, "placeholder"));
          foreach (INode childNode in (IEnumerable<INode>) ((INode) ielementNode).ChildNodes())
          {
            if (!this.context.IsProcessingInlineSvg())
              this.Visit(childNode);
          }
          this.Visit((INode) DefaultHtmlProcessor.CreatePseudoElement(ielementNode, tagWorker, "after"));
          CounterProcessorUtil.EndProcessingCounters(this.context.GetCssContext(), ielementNode);
          if (tagWorker != null)
          {
            tagWorker.ProcessEnd(ielementNode, this.context);
            LinkHelper.CreateDestination(tagWorker, ielementNode, this.context);
            this.context.GetOutlineHandler().SetDestinationToElement(tagWorker, ielementNode);
            this.context.GetState().Pop();
            if (!"body".Equals(ielementNode.Name()) && !"html".Equals(ielementNode.Name()))
              this.RunApplier(ielementNode, tagWorker);
            if (!this.context.GetState().Empty())
            {
              PageBreakApplierUtil.AddPageBreakElementBefore(this.context, this.context.GetState().Top(), ielementNode, tagWorker);
              tagWorker = this.ProcessRunningElement(tagWorker, ielementNode, this.context);
              int num = this.context.GetState().Top().ProcessTagChild(tagWorker, this.context) ? 1 : 0;
              PageBreakApplierUtil.AddPageBreakElementAfter(this.context, this.context.GetState().Top(), ielementNode, tagWorker);
              if (num == 0 && !DefaultHtmlProcessor.ignoredChildTags.Contains(ielementNode.Name()))
                LoggerExtensions.LogError(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("Worker of type {0} unable to process {1}", new object[2]
                {
                  (object) this.context.GetState().Top().GetType().FullName,
                  (object) tagWorker.GetType().FullName
                }), Array.Empty<object>());
            }
            else if (tagWorker.GetElementResult() != null)
              this.roots.Add(tagWorker.GetElementResult());
            if (tagWorker.GetElementResult() != null && this.context.IsContinuousContainerEnabled())
            {
              tagWorker.GetElementResult().SetProperty(89, (object) false);
              tagWorker.GetElementResult().SetProperty(140, (object) true);
            }
          }
          ((IStylesContainer) ielementNode).SetStyles((IDictionary<string, string>) null);
          break;
        case ITextNode _:
          string content = ((ITextNode) node).WholeText();
          if (content == null)
            break;
          if (!this.context.GetState().Empty())
          {
            if (this.context.GetState().Top().ProcessContent(content, this.context))
              break;
            LoggerExtensions.LogError(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("Worker of type {0} unable to process it`s text content", new object[1]
            {
              (object) this.context.GetState().Top().GetType().FullName
            }), Array.Empty<object>());
            break;
          }
          LoggerExtensions.LogError(DefaultHtmlProcessor.logger, "No consumer found for content", Array.Empty<object>());
          break;
      }
    }

    private void RunApplier(IElementNode element, ITagWorker tagWorker)
    {
      ICssApplier cssApplier = this.context.GetCssApplierFactory().GetCssApplier(element);
      if (cssApplier == null)
      {
        if (DefaultHtmlProcessor.ignoredCssTags.Contains(element.Name()))
          return;
        LoggerExtensions.LogError(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("No css applier found for tag {0}", new object[1]
        {
          (object) element.Name()
        }), Array.Empty<object>());
      }
      else
        cssApplier.Apply(this.context, (IStylesContainer) element, tagWorker);
    }

    private ITagWorker ProcessRunningElement(
      ITagWorker tagWorker,
      IElementNode element,
      ProcessorContext context)
    {
      string str1 = "running(";
      string str2;
      int endIndex;
      if (((IStylesContainer) element).GetStyles() == null || (str2 = ((IStylesContainer) element).GetStyles().Get<string, string>("position")) == null || !str2.StartsWith(str1) || (endIndex = str2.IndexOf(")", StringComparison.Ordinal)) <= str1.Length)
        return tagWorker;
      string runningElemName = str2.JSubstring(str1.Length, endIndex).Trim();
      if (string.IsNullOrEmpty(runningElemName))
        return tagWorker;
      RunningElementContainer elementContainer = new RunningElementContainer(element, tagWorker);
      context.GetCssContext().GetRunningManager().AddRunningElement(runningElemName, elementContainer);
      return (ITagWorker) new RunningElementTagWorker(elementContainer);
    }

    private void AddFontFaceFonts()
    {
      if (!(this.cssResolver is DefaultCssResolver))
        return;
      foreach (CssFontFaceRule font in (IEnumerable<CssFontFaceRule>) ((DefaultCssResolver) this.cssResolver).GetFonts())
      {
        bool flag = false;
        CssFontFace cssFontFace = CssFontFace.Create(font.GetProperties());
        if (cssFontFace != null)
        {
          foreach (CssFontFace.CssFontFaceSrc source in (IEnumerable<CssFontFace.CssFontFaceSrc>) cssFontFace.GetSources())
          {
            if (this.CreateFont(cssFontFace.GetFontFamily(), source, font.ResolveUnicodeRange()))
            {
              flag = true;
              break;
            }
          }
        }
        if (!flag)
          LoggerExtensions.LogError(DefaultHtmlProcessor.logger, MessageFormatUtil.Format("Unable to retrieve font:\n {0}", new object[1]
          {
            (object) font
          }), Array.Empty<object>());
      }
    }

    private bool CreateFont(string fontFamily, CssFontFace.CssFontFaceSrc src, Range unicodeRange)
    {
      if (!CssFontFace.IsSupportedFontFormat(src.GetFormat()))
        return false;
      if (src.IsLocal())
      {
        ICollection<FontInfo> fontInfos = this.context.GetFontProvider().GetFontSet().Get(src.GetSrc());
        if (fontInfos.Count <= 0)
          return false;
        foreach (FontInfo fontInfo in (IEnumerable<FontInfo>) fontInfos)
          this.context.AddTemporaryFont(fontInfo, fontFamily);
        return true;
      }
      try
      {
        byte[] numArray = this.context.GetResourceResolver().RetrieveBytesFromResource(src.GetSrc());
        if (numArray != null)
        {
          this.context.AddTemporaryFont(FontProgramFactory.CreateFont(numArray, false), "Identity-H", fontFamily, unicodeRange);
          return true;
        }
      }
      catch (Exception ex)
      {
      }
      return false;
    }

    private static CssPseudoElementNode CreatePseudoElement(
      IElementNode node,
      ITagWorker tagWorker,
      string pseudoElementName)
    {
      switch (pseudoElementName)
      {
        case "before":
        case "after":
          if (!CssPseudoElementUtil.HasBeforeAfterElements(node))
            return (CssPseudoElementNode) null;
          break;
        case "placeholder":
          if (!"input".Equals(node.Name()) && !"textarea".Equals(node.Name()) || tagWorker == null || !(tagWorker.GetElementResult() is IPlaceholderable) || ((IPlaceholderable) tagWorker.GetElementResult()).GetPlaceholder() == null)
            return (CssPseudoElementNode) null;
          break;
        default:
          return (CssPseudoElementNode) null;
      }
      return new CssPseudoElementNode((INode) node, pseudoElementName);
    }

    private IElementNode FindElement(INode node, string tagName)
    {
      LinkedList<INode> linkedList = new LinkedList<INode>();
      linkedList.Add<INode>(node);
      while (!linkedList.IsEmpty<INode>())
      {
        INode element = linkedList.JGetFirst<INode>();
        linkedList.RemoveFirst();
        if (element is IElementNode && ((IElementNode) element).Name().Equals(tagName))
          return (IElementNode) element;
        foreach (INode childNode in (IEnumerable<INode>) element.ChildNodes())
        {
          if (childNode is IElementNode)
            linkedList.Add<INode>(childNode);
        }
      }
      return (IElementNode) null;
    }

    private IElementNode FindHtmlNode(INode node) => this.FindElement(node, "html");

    private IElementNode FindBodyNode(INode node) => this.FindElement(node, "body");

    private bool IsDisplayable(IElementNode element)
    {
      if (element != null && ((IStylesContainer) element).GetStyles() != null && "none".Equals(((IStylesContainer) element).GetStyles().Get<string, string>("display")))
        return false;
      if (this.IsPlaceholder(element))
        return true;
      if (!(element is CssPseudoElementNode))
        return element != null;
      if (((INode) element).ChildNodes().IsEmpty<INode>())
        return false;
      int num = ((IStylesContainer) element).GetStyles() != null ? 1 : 0;
      string str1 = num != 0 ? ((IStylesContainer) element).GetStyles().Get<string, string>("position") : (string) null;
      string str2 = num != 0 ? ((IStylesContainer) element).GetStyles().Get<string, string>("display") : (string) null;
      bool flag1 = false;
      bool flag2 = false;
      for (int index = 0; index < ((INode) element).ChildNodes().Count; ++index)
      {
        if (((INode) element).ChildNodes()[index] is ITextNode)
        {
          flag1 = true;
          break;
        }
        if (((INode) element).ChildNodes()[index] is IElementNode)
          flag2 = true;
      }
      if (flag2 | flag1 || "absolute".Equals(str1) || "fixed".Equals(str1))
        return true;
      return str2 != null && !"inline".Equals(str2);
    }

    private bool IsPlaceholder(IElementNode element)
    {
      return element is CssPseudoElementNode && "placeholder".Equals(((CssPseudoElementNode) element).GetPseudoElementName());
    }

    private static void UpdateSequenceId(IElement element, SequenceId sequenceId)
    {
      if (!(element is AbstractIdentifiableElement))
        return;
      AbstractIdentifiableElement identifiableElement = (AbstractIdentifiableElement) element;
      if (SequenceIdManager.GetSequenceId(identifiableElement) == sequenceId)
        return;
      SequenceIdManager.SetSequenceId(identifiableElement, sequenceId);
      if (!(identifiableElement is IAbstractElement))
        return;
      DefaultHtmlProcessor.UpdateChildren(((IAbstractElement) identifiableElement).GetChildren(), sequenceId);
    }

    private static void UpdateChildren(IList<IElement> children, SequenceId sequenceId)
    {
      if (children == null)
        return;
      foreach (IElement child in (IEnumerable<IElement>) children)
        DefaultHtmlProcessor.UpdateSequenceId(child, sequenceId);
    }
  }
}
