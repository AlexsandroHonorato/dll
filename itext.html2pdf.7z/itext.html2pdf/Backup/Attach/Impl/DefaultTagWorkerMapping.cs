﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.DefaultTagWorkerMapping
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl.Tags;
using iText.Html2pdf.Util;
using iText.StyledXmlParser.Css.Pseudo;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl
{
  internal class DefaultTagWorkerMapping
  {
    private static TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator> workerMapping = new TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator>();

    static DefaultTagWorkerMapping()
    {
      DefaultTagWorkerMapping.workerMapping.PutMapping("a", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ATagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("abbr", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new AbbrTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("address", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("article", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("aside", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("b", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("bdi", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("bdo", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("blockquote", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("body", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new BodyTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("br", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new BrTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("button", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ButtonTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("caption", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new CaptionTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("center", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("cite", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("code", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("col", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ColTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("colgroup", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ColgroupTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dd", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new LiTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("del", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dfn", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dl", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new UlOlTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dt", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new LiTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("em", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("fieldset", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("figcaption", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("figure", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("font", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("footer", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("form", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h1", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h2", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h3", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h4", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h5", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("h6", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("header", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("hr", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HrTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("html", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new HtmlTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("i", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("img", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ImgTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("input", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new InputTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("ins", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("kbd", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("label", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("legend", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("li", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new LiTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("link", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new LinkTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("main", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("mark", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("meta", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new MetaTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("nav", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("object", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ObjectTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("ol", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new UlOlTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("optgroup", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new OptGroupTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("option", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new OptionTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("p", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new PTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("pre", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new PreTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("q", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("s", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("samp", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("section", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("select", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SelectTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("small", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("span", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("strike", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("strong", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("sub", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("sup", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("svg", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SvgTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("table", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TableTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("td", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TdTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("textarea", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TextAreaTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("tfoot", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TableFooterTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("th", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ThTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("thead", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TableHeaderTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("time", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("title", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TitleTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("tr", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TrTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("tt", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("u", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("ul", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new UlOlTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("var", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      string pseudoElementTagName1 = CssPseudoElementUtil.CreatePseudoElementTagName("placeholder");
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName1, (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new PlaceholderTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("ul", "inline", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("li", "inline", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("li", "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("li", "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dd", "inline", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("dt", "inline", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("span", "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("span", "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("a", "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ABlockTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("a", "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ABlockTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("a", "table-cell", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ABlockTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("label", "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("label", "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "table", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DisplayTableTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "table-row", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DisplayTableRowTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "inline", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "inline-table", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DisplayTableTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "table-cell", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new TdTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("div", "flex", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DisplayFlexTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("span", "flex", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DisplayFlexTagWorker(lhs, rhs)));
      string pseudoElementTagName2 = CssPseudoElementUtil.CreatePseudoElementTagName("before");
      string pseudoElementTagName3 = CssPseudoElementUtil.CreatePseudoElementTagName("after");
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName2, (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName3, (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new SpanTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName2, "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName3, "inline-block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName2, "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName3, "block", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName2, "table", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(pseudoElementTagName3, "table", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(CssPseudoElementUtil.CreatePseudoElementTagName("img"), (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new ImgTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping(CssPseudoElementUtil.CreatePseudoElementTagName("div"), (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new DivTagWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("_e0d00a6_page-counter", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new PageCountWorker(lhs, rhs)));
      DefaultTagWorkerMapping.workerMapping.PutMapping("_064ef03_page-margin-box", (DefaultTagWorkerMapping.ITagWorkerCreator) ((lhs, rhs) => (ITagWorker) new PageMarginBoxWorker(lhs, rhs)));
    }

    internal virtual TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator> GetDefaultTagWorkerMapping()
    {
      return DefaultTagWorkerMapping.workerMapping;
    }

    internal DefaultTagWorkerMapping()
    {
    }

    public delegate ITagWorker ITagWorkerCreator(
      IElementNode elementNode,
      ProcessorContext processorContext);
  }
}
