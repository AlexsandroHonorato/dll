﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.DefaultTagWorkerFactory
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Util;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl
{
  public class DefaultTagWorkerFactory : ITagWorkerFactory
  {
    private static readonly ITagWorkerFactory INSTANCE = (ITagWorkerFactory) new DefaultTagWorkerFactory();
    private readonly TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator> defaultMapping;

    public DefaultTagWorkerFactory()
    {
      this.defaultMapping = new DefaultTagWorkerMapping().GetDefaultTagWorkerMapping();
    }

    public static ITagWorkerFactory GetInstance() => DefaultTagWorkerFactory.INSTANCE;

    public ITagWorker GetTagWorker(IElementNode tag, ProcessorContext context)
    {
      ITagWorker customTagWorker = this.GetCustomTagWorker(tag, context);
      if (customTagWorker != null)
        return customTagWorker;
      DefaultTagWorkerMapping.ITagWorkerCreator tagWorkerCreator = DefaultTagWorkerFactory.GetTagWorkerCreator(this.defaultMapping, tag);
      return tagWorkerCreator == null ? (ITagWorker) null : tagWorkerCreator(tag, context);
    }

    internal virtual TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator> GetDefaultMapping()
    {
      return this.defaultMapping;
    }

    private static DefaultTagWorkerMapping.ITagWorkerCreator GetTagWorkerCreator(
      TagProcessorMapping<DefaultTagWorkerMapping.ITagWorkerCreator> mapping,
      IElementNode tag)
    {
      DefaultTagWorkerMapping.ITagWorkerCreator tagWorkerCreator = (DefaultTagWorkerMapping.ITagWorkerCreator) null;
      string display = ((IStylesContainer) tag).GetStyles() != null ? ((IStylesContainer) tag).GetStyles().Get<string, string>("display") : (string) null;
      if (display != null)
        tagWorkerCreator = (DefaultTagWorkerMapping.ITagWorkerCreator) mapping.GetMapping(tag.Name(), display);
      if (tagWorkerCreator == null)
        tagWorkerCreator = (DefaultTagWorkerMapping.ITagWorkerCreator) mapping.GetMapping(tag.Name());
      return tagWorkerCreator;
    }

    public virtual ITagWorker GetCustomTagWorker(IElementNode tag, ProcessorContext context)
    {
      return (ITagWorker) null;
    }
  }
}
