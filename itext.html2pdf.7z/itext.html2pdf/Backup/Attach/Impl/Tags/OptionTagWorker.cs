﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.OptionTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.StyledXmlParser.Jsoup.Nodes;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Node.Impl.Jsoup.Node;
using System.Text;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class OptionTagWorker : DivTagWorker
  {
    private StringBuilder actualOptionTextContent;
    private string labelAttrVal;
    private bool labelReplacedContent;
    private bool fakedContent;

    public OptionTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
      bool flag = element.GetAttribute("selected") != null;
      this.GetElementResult().SetProperty(2097161, (object) flag);
      this.actualOptionTextContent = new StringBuilder();
      this.labelAttrVal = element.GetAttribute("label");
      if (this.labelAttrVal == null || !((INode) element).ChildNodes().IsEmpty<INode>())
        return;
      ((INode) element).AddChild((INode) new JsoupTextNode(new TextNode("")));
      this.fakedContent = true;
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      string str1 = element.GetAttribute("value");
      string str2 = element.GetAttribute("label");
      string str3 = this.actualOptionTextContent.ToString();
      if (str2 == null)
        str2 = str3;
      if (str1 == null)
        str1 = str3;
      this.GetElementResult().SetProperty(2097155, (object) str1);
      this.GetElementResult().SetProperty(2097162, (object) str2);
    }

    public override bool ProcessContent(string content, ProcessorContext context)
    {
      content = content.Trim();
      if (this.labelAttrVal != null)
      {
        if (!this.labelReplacedContent)
        {
          this.labelReplacedContent = true;
          base.ProcessContent(this.labelAttrVal, context);
        }
      }
      else
        base.ProcessContent(content, context);
      if (!this.fakedContent)
        this.actualOptionTextContent.Append(content);
      return true;
    }

    public override bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return base.ProcessTagChild(childTagWorker, context);
    }
  }
}
