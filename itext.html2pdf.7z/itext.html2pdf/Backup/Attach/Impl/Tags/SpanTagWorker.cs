﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.SpanTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class SpanTagWorker : ITagWorker, IDisplayAware
  {
    internal SpanWrapper spanWrapper;
    internal IDictionary<IPropertyContainer, string> childrenDisplayMap = (IDictionary<IPropertyContainer, string>) new Dictionary<IPropertyContainer, string>();
    private IList<IPropertyContainer> elements;
    private IList<IPropertyContainer> ownLeafElements = (IList<IPropertyContainer>) new List<IPropertyContainer>();
    private WaitingInlineElementsHelper inlineHelper;
    private readonly string display;
    private readonly string textTransform;

    public SpanTagWorker(IElementNode element, ProcessorContext context)
    {
      this.spanWrapper = new SpanWrapper();
      IDictionary<string, string> styles = ((IStylesContainer) element).GetStyles();
      this.inlineHelper = new WaitingInlineElementsHelper(styles == null ? (string) null : styles.Get<string, string>("white-space"), styles == null ? (string) null : styles.Get<string, string>("text-transform"));
      this.display = styles == null ? (string) null : styles.Get<string, string>(nameof (display));
      this.textTransform = styles == null ? (string) null : styles.Get<string, string>("text-transform");
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      if (this.inlineHelper.GetWaitingLeaves().IsEmpty<IElement>() && this.spanWrapper.GetElements().IsEmpty<IPropertyContainer>())
        this.inlineHelper.Add("");
      this.FlushInlineHelper();
      this.elements = this.spanWrapper.GetElements();
      foreach (IPropertyContainer element1 in (IEnumerable<IPropertyContainer>) this.elements)
      {
        if (element1 is IAccessibleElement)
          AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) element1, element);
      }
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      if (elementResult is ILeafElement)
      {
        this.FlushInlineHelper();
        this.spanWrapper.Add((ILeafElement) elementResult);
        this.ownLeafElements.Add(elementResult);
        return true;
      }
      if (childTagWorker is SpanTagWorker)
      {
        this.FlushInlineHelper();
        this.spanWrapper.Add(((SpanTagWorker) childTagWorker).spanWrapper);
        this.childrenDisplayMap.AddAll<IPropertyContainer, string>(((SpanTagWorker) childTagWorker).childrenDisplayMap);
        return true;
      }
      if (!(childTagWorker.GetElementResult() is IBlockElement))
        return false;
      if (childTagWorker is IDisplayAware)
      {
        string display = ((IDisplayAware) childTagWorker).GetDisplay();
        this.childrenDisplayMap.Put<IPropertyContainer, string>(childTagWorker.GetElementResult(), display);
      }
      this.FlushInlineHelper();
      this.spanWrapper.Add((IBlockElement) childTagWorker.GetElementResult());
      return true;
    }

    public virtual IList<IPropertyContainer> GetAllElements() => this.elements;

    public virtual IList<IPropertyContainer> GetOwnLeafElements() => this.ownLeafElements;

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) null;

    public virtual string GetDisplay() => this.display;

    internal virtual string GetElementDisplay(IPropertyContainer child)
    {
      return this.childrenDisplayMap.Get<IPropertyContainer, string>(child);
    }

    private void FlushInlineHelper()
    {
      ICollection<IElement> waitingLeaves = this.inlineHelper.GetWaitingLeaves();
      this.SetCapitalizeProperty(waitingLeaves);
      this.spanWrapper.AddAll(waitingLeaves);
      this.ownLeafElements.AddAll<IPropertyContainer>((IEnumerable<IPropertyContainer>) waitingLeaves);
      this.inlineHelper.ClearWaitingLeaves();
    }

    private void SetCapitalizeProperty(ICollection<IElement> elements)
    {
      foreach (IElement element in (IEnumerable<IElement>) elements)
      {
        if (element is Text)
        {
          if (!element.HasOwnProperty(1048581) && "capitalize".Equals(this.textTransform))
            element.SetProperty(1048581, (object) true);
          else
            element.SetProperty(1048581, (object) false);
        }
      }
    }
  }
}
