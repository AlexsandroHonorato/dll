﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ThTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Tagging;
using iText.Kernel.Pdf.Tagutils;
using iText.Layout;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ThTagWorker : TdTagWorker
  {
    public ThTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      IPropertyContainer elementResult = this.GetElementResult();
      if (!(elementResult is IAccessibleElement))
        return;
      ((IAccessibleElement) elementResult).GetAccessibilityProperties().SetRole("TH");
      if (context.GetPdfDocument() != null && !context.GetPdfDocument().IsTagged())
        return;
      string attribute = element.GetAttribute("scope");
      AccessibilityProperties accessibilityProperties = ((IAccessibleElement) elementResult).GetAccessibilityProperties();
      PdfDictionary pdfDictionary = new PdfDictionary();
      pdfDictionary.Put(PdfName.O, (PdfObject) PdfName.Table);
      if (attribute != null && ("row".EqualsIgnoreCase(attribute) || "rowgroup".EqualsIgnoreCase(attribute)))
      {
        pdfDictionary.Put(PdfName.Scope, (PdfObject) PdfName.Row);
        accessibilityProperties.AddAttributes(new PdfStructureAttributes(pdfDictionary));
      }
      else if (attribute != null && ("col".EqualsIgnoreCase(attribute) || "colgroup".EqualsIgnoreCase(attribute)))
      {
        pdfDictionary.Put(PdfName.Scope, (PdfObject) PdfName.Column);
        accessibilityProperties.AddAttributes(new PdfStructureAttributes(pdfDictionary));
      }
      else
        LoggerExtensions.LogWarning(ITextLogManager.GetLogger(typeof (ThTagWorker)), MessageFormatUtil.Format("Not supported th scope type: {0}. Document may not be compliant with PDF/UA standards.", new object[1]
        {
          (object) attribute
        }), Array.Empty<object>());
    }
  }
}
