﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.DisplayTableTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class DisplayTableTagWorker : ITagWorker
  {
    private Table table;
    private TableWrapper tableWrapper = new TableWrapper();
    private WaitingInlineElementsHelper inlineHelper;
    private Cell waitingCell;
    private bool currentRowIsFinished;

    public DisplayTableTagWorker(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.FlushWaitingCell();
      this.table = this.tableWrapper.ToTable((WaitingColgroupsHelper) null);
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.table, element);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      bool displayTableCell = childTagWorker is IDisplayAware && "table-cell".Equals(((IDisplayAware) childTagWorker).GetDisplay());
      if (this.currentRowIsFinished)
        this.tableWrapper.NewRow();
      if (childTagWorker is DisplayTableRowTagWorker)
      {
        this.FlushWaitingCell();
        if (!this.currentRowIsFinished)
          this.tableWrapper.NewRow();
        foreach (Cell cell in (IEnumerable<Cell>) ((DisplayTableRowTagWorker) childTagWorker).GetTableRowWrapper().GetCells())
          this.tableWrapper.AddCell(cell);
        this.currentRowIsFinished = true;
        return true;
      }
      if (childTagWorker.GetElementResult() is IBlockElement)
      {
        IBlockElement elementResult = (IBlockElement) childTagWorker.GetElementResult();
        this.ProcessCell(elementResult is Cell ? (Cell) elementResult : this.CreateWrapperCell().Add(elementResult), displayTableCell);
        this.currentRowIsFinished = false;
        return true;
      }
      if (childTagWorker.GetElementResult() is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
        this.currentRowIsFinished = false;
        return true;
      }
      if (!(childTagWorker is SpanTagWorker))
        return false;
      if (displayTableCell)
        this.FlushWaitingCell();
      bool flag = true;
      foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
      {
        if (allElement is ILeafElement)
          this.inlineHelper.Add((ILeafElement) allElement);
        else
          flag = false;
      }
      if (displayTableCell)
        this.FlushWaitingCell();
      this.currentRowIsFinished = false;
      return flag;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.table;

    private void ProcessCell(Cell cell, bool displayTableCell)
    {
      if (displayTableCell)
      {
        if (this.waitingCell != cell)
        {
          this.FlushWaitingCell();
          this.tableWrapper.AddCell(cell);
        }
        else
        {
          if (cell.IsEmpty())
            return;
          this.tableWrapper.AddCell(cell);
          this.waitingCell = (Cell) null;
        }
      }
      else
      {
        this.FlushInlineElementsToWaitingCell();
        this.waitingCell.Add((IBlockElement) cell);
      }
    }

    private void FlushInlineElementsToWaitingCell()
    {
      if (this.waitingCell == null)
        this.waitingCell = this.CreateWrapperCell();
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.waitingCell);
    }

    private void FlushWaitingCell()
    {
      this.FlushInlineElementsToWaitingCell();
      if (this.waitingCell == null)
        return;
      this.ProcessCell(this.waitingCell, true);
    }

    private Cell CreateWrapperCell() => new Cell().SetBorder(Border.NO_BORDER).SetPadding(0.0f);
  }
}
