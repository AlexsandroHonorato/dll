﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ButtonTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Html2pdf.Attach.Util;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;
using System.Text;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ButtonTagWorker : DivTagWorker
  {
    private const string DEFAULT_BUTTON_NAME = "Button";
    private IFormField formField;
    private string lang;
    private StringBuilder fallbackContent = new StringBuilder();
    private string name;
    private bool flatten;
    private bool hasChildren;
    private IConformanceLevel pdfAConformanceLevel;

    public ButtonTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
      string name = element.GetAttribute("id") ?? "Button";
      this.name = context.GetFormFieldNameResolver().ResolveFormName(name);
      this.flatten = !context.IsCreateAcroForm();
      if (context.GetConformanceLevel() != null)
        this.pdfAConformanceLevel = context.GetConformanceLevel();
      this.lang = element.GetAttribute(nameof (lang));
    }

    public override bool ProcessContent(string content, ProcessorContext context)
    {
      this.fallbackContent.Append(content);
      return base.ProcessContent(content, context);
    }

    public override bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      this.hasChildren = true;
      return base.ProcessTagChild(childTagWorker, context);
    }

    public override IPropertyContainer GetElementResult()
    {
      if (this.formField == null)
      {
        if (this.hasChildren)
        {
          Button button = new Button(this.name);
          ((ElementPropertyContainer<Button>) button).SetProperty(2097163, (object) this.lang);
          Div elementResult = (Div) base.GetElementResult();
          foreach (IElement child in (IEnumerable<IElement>) elementResult.GetChildren())
          {
            if (child is IAccessibleElement)
              AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) child, this.lang);
            if (child is IBlockElement)
              button.Add((IBlockElement) child);
            else if (child is Image)
              button.Add((Image) child);
          }
          elementResult.GetChildren().Clear();
          this.formField = (IFormField) button;
        }
        else
        {
          Button button = new Button(this.name);
          ((ElementPropertyContainer<Button>) button).SetProperty(2097163, (object) this.lang);
          ((FormField<Button>) button).SetValue(this.fallbackContent.ToString().Trim());
          this.formField = (IFormField) button;
        }
      }
      ((IPropertyContainer) this.formField).SetProperty(2097153, (object) this.flatten);
      ((IPropertyContainer) this.formField).SetProperty(2097167, (object) this.pdfAConformanceLevel);
      return (IPropertyContainer) this.formField;
    }
  }
}
