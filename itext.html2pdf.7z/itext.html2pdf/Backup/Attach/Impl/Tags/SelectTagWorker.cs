﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.SelectTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Forms.Form.Element;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class SelectTagWorker : ITagWorker, IDisplayAware
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (SelectTagWorker));
    private AbstractSelectField selectElement;
    private string display;

    public SelectTagWorker(IElementNode element, ProcessorContext context)
    {
      string str = context.GetFormFieldNameResolver().ResolveFormName(element.GetAttribute("name"));
      bool multiple = element.GetAttribute("multiple") != null;
      int selectSize = this.GetSelectSize(CssDimensionParsingUtils.ParseInteger(element.GetAttribute("size")), multiple);
      if (selectSize > 1 | multiple)
      {
        this.selectElement = (AbstractSelectField) new ListBoxField(str, selectSize, multiple);
        ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).DeleteOwnProperty(48);
        ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).DeleteOwnProperty(49);
        ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).DeleteOwnProperty(50);
        ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).DeleteOwnProperty(47);
      }
      else
        this.selectElement = (AbstractSelectField) new ComboBoxField(str);
      ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).SetProperty(2097163, (object) element.GetAttribute("lang"));
      ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).SetProperty(2097153, (object) !context.IsCreateAcroForm());
      if (context.GetConformanceLevel() != null)
        ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).SetProperty(2097167, (object) context.GetConformanceLevel());
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      return content == null || string.IsNullOrEmpty(content.Trim());
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      switch (childTagWorker)
      {
        case OptionTagWorker _:
        case OptGroupTagWorker _:
          if (childTagWorker.GetElementResult() is IBlockElement)
          {
            IBlockElement elementResult = (IBlockElement) childTagWorker.GetElementResult();
            this.selectElement.AddOption(new SelectFieldItem(elementResult.GetProperty<string>(2097162), elementResult));
            bool? property = ((ElementPropertyContainer<AbstractSelectField>) this.selectElement).GetProperty<bool?>(2097153);
            if (childTagWorker is OptGroupTagWorker && !true.Equals((object) property))
              LoggerExtensions.LogWarning(SelectTagWorker.LOGGER, "Option groups are not supported in interactive mode", Array.Empty<object>());
            return true;
          }
          break;
      }
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.selectElement;

    public virtual string GetDisplay() => this.display;

    private int GetSelectSize(int? size, bool multiple)
    {
      if (size.HasValue)
      {
        int? nullable = size;
        int num = 0;
        if (nullable.GetValueOrDefault() > num & nullable.HasValue)
          return size.Value;
      }
      return !multiple ? 1 : 4;
    }
  }
}
