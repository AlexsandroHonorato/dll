﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ATagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Resolver.Resource;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ATagWorker : SpanTagWorker
  {
    public ATagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      string url = element.GetAttribute("href");
      if (url != null)
      {
        string baseUri = context.GetBaseUri();
        if (baseUri != null)
        {
          UriResolver uriResolver = new UriResolver(baseUri);
          if (!url.StartsWith("#") || !uriResolver.IsLocalBaseUri())
          {
            try
            {
              string str = uriResolver.ResolveAgainstBaseUri(url).ToExternalForm();
              if (!url.EndsWith("/") && str.EndsWith("/"))
                str = str.JSubstring(0, str.Length - 1);
              if (!str.StartsWith("file:"))
                url = str;
            }
            catch (UriFormatException ex)
            {
            }
          }
        }
        for (int index = 0; index < this.GetAllElements().Count; ++index)
        {
          if (!(this.GetAllElements()[index] is RunningElement))
          {
            if (this.GetAllElements()[index] is IBlockElement)
            {
              Div key = new Div();
              key.GetAccessibilityProperties().SetRole("Link");
              Transform property1 = this.GetAllElements()[index].GetProperty<Transform>(53);
              if (property1 != null)
              {
                this.GetAllElements()[index].DeleteOwnProperty(53);
                key.SetProperty(53, (object) property1);
              }
              FloatPropertyValue? property2 = this.GetAllElements()[index].GetProperty<FloatPropertyValue?>(99);
              if (property2.HasValue)
              {
                this.GetAllElements()[index].DeleteOwnProperty(99);
                key.SetProperty(99, (object) property2);
              }
              key.Add((IBlockElement) this.GetAllElements()[index]);
              string str = this.childrenDisplayMap.JRemove<IPropertyContainer, string>(this.GetAllElements()[index]);
              if (str != null)
                this.childrenDisplayMap.Put<IPropertyContainer, string>((IPropertyContainer) key, str);
              this.GetAllElements()[index] = (IPropertyContainer) key;
            }
            LinkHelper.ApplyLinkAnnotation(this.GetAllElements()[index], url, context, element);
          }
        }
      }
      if (this.GetAllElements().IsEmpty<IPropertyContainer>())
        return;
      string attribute = element.GetAttribute("name");
      IPropertyContainer allElement = this.GetAllElements()[0];
      allElement.SetProperty(17, (object) attribute);
      allElement.SetProperty(126, (object) attribute);
    }
  }
}
