﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.InputTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Forms.Form.Element;
using iText.Html2pdf.Html;
using iText.Kernel.Colors;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Text.RegularExpressions;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class InputTagWorker : ITagWorker, IDisplayAware
  {
    private static readonly Regex NUMBER_INPUT_ALLOWED_VALUES = StringUtil.RegexCompile("^(((-?[0-9]+)(\\.[0-9]+)?)|(-?\\.[0-9]+))$");
    private static int radioNameIdx = 0;
    private IElement formElement;
    private string display;

    public InputTagWorker(IElementNode element, ProcessorContext context)
    {
      string attribute1 = element.GetAttribute("lang");
      string inputType = element.GetAttribute("type");
      if (!AttributeConstants.INPUT_TYPE_VALUES.Contains(inputType))
      {
        if (inputType != null && inputType.Length != 0)
          LoggerExtensions.LogWarning(ITextLogManager.GetLogger(typeof (InputTagWorker)), MessageFormatUtil.Format("Input type {0} is invalid. The default text type will be used instead.", new object[1]
          {
            (object) inputType
          }), Array.Empty<object>());
        inputType = "text";
      }
      string attribute2 = element.GetAttribute("value");
      string str1 = context.GetFormFieldNameResolver().ResolveFormName(element.GetAttribute("name"));
      if (inputType == null || "text".Equals(inputType) || "email".Equals(inputType) || "password".Equals(inputType) || "number".Equals(inputType))
      {
        int? integer = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("size"));
        this.formElement = (IElement) new InputField(str1);
        this.formElement.DeleteOwnProperty(105);
        string str2 = InputTagWorker.PreprocessInputValue(attribute2, inputType);
        string attribute3 = element.GetAttribute("placeholder");
        if (attribute3 != null)
          ((InputField) this.formElement).SetPlaceholder((!string.IsNullOrEmpty(attribute3) ? (!string.IsNullOrEmpty(attribute3.Trim()) ? (BlockElement<Paragraph>) new Paragraph(attribute3) : (BlockElement<Paragraph>) new Paragraph(" ")) : (BlockElement<Paragraph>) new Paragraph()).SetMargin(0.0f));
        this.formElement.SetProperty(2097155, (object) str2);
        this.formElement.SetProperty(2097154, (object) integer);
        if ("password".Equals(inputType))
          this.formElement.SetProperty(2097156, (object) true);
      }
      else if ("submit".Equals(inputType) || "button".Equals(inputType))
        this.formElement = (IElement) new Button(str1).SetSingleLineValue(attribute2);
      else if ("checkbox".Equals(inputType))
      {
        CheckBox checkBox = new CheckBox(str1);
        string attribute4 = element.GetAttribute("checked");
        float num = 9.75f;
        float width = 0.75f;
        ((FormField<CheckBox>) checkBox).SetSize(num);
        ((ElementPropertyContainer<CheckBox>) checkBox).SetBorder((Border) new SolidBorder(ColorConstants.DARK_GRAY, width));
        ((ElementPropertyContainer<CheckBox>) checkBox).SetBackgroundColor(ColorConstants.WHITE);
        checkBox.SetChecked(attribute4 != null);
        this.formElement = (IElement) checkBox;
      }
      else if ("radio".Equals(inputType))
      {
        string radioGroupName = element.GetAttribute("name");
        if (radioGroupName == null || string.IsNullOrEmpty(radioGroupName))
        {
          ++InputTagWorker.radioNameIdx;
          radioGroupName = "radio" + InputTagWorker.radioNameIdx.ToString();
        }
        Radio checkedField = new Radio(str1, radioGroupName);
        Border border = (Border) new SolidBorder(1f);
        border.SetColor(ColorConstants.LIGHT_GRAY);
        ((ElementPropertyContainer<Radio>) checkedField).SetBorder(border);
        if (element.GetAttribute("checked") != null)
        {
          context.GetRadioCheckResolver().CheckField(radioGroupName, checkedField);
          checkedField.SetChecked(true);
        }
        this.formElement = (IElement) checkedField;
      }
      else
        LoggerExtensions.LogError(ITextLogManager.GetLogger(typeof (InputTagWorker)), MessageFormatUtil.Format("Input type {0} is not supported", new object[1]
        {
          (object) inputType
        }), Array.Empty<object>());
      if (this.formElement != null)
      {
        this.formElement.SetProperty(2097153, (object) !context.IsCreateAcroForm());
        this.formElement.SetProperty(2097163, (object) attribute1);
        if (context.GetConformanceLevel() != null)
          this.formElement.SetProperty(2097167, (object) context.GetConformanceLevel());
      }
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual string GetDisplay() => this.display;

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return childTagWorker is PlaceholderTagWorker && ((InputField) this.formElement).GetPlaceholder() != null;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.formElement;

    internal static string PreprocessInputValue(string value, string inputType)
    {
      if ("number".Equals(inputType) && value != null && !Matcher.Match(InputTagWorker.NUMBER_INPUT_ALLOWED_VALUES, value).Matches())
        value = "";
      return value;
    }
  }
}
