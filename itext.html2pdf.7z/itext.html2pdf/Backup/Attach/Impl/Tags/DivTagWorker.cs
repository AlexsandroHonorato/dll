﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.DivTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class DivTagWorker : ITagWorker, IDisplayAware
  {
    protected internal MulticolContainer multicolContainer;
    private Div div;
    private WaitingInlineElementsHelper inlineHelper;
    private string display;

    public DivTagWorker(IElementNode element, ProcessorContext context)
    {
      this.div = new Div();
      IDictionary<string, string> styles = ((IStylesContainer) element).GetStyles();
      if (styles != null && (styles.ContainsKey("column-count") || styles.ContainsKey("column-width")))
      {
        this.multicolContainer = new MulticolContainer();
        this.multicolContainer.Add((IBlockElement) this.div);
      }
      this.inlineHelper = new WaitingInlineElementsHelper(styles == null ? (string) null : styles.Get<string, string>("white-space"), styles == null ? (string) null : styles.Get<string, string>("text-transform"));
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.div, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.div);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      bool flag1 = false;
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      switch (childTagWorker)
      {
        case BrTagWorker _:
          this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
          return true;
        case IDisplayAware _ when "inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) && childTagWorker.GetElementResult() is IBlockElement:
          this.inlineHelper.Add((IBlockElement) childTagWorker.GetElementResult());
          return true;
        case SpanTagWorker _:
          bool flag2 = true;
          foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
          {
            switch (allElement)
            {
              case ILeafElement _:
                this.inlineHelper.Add((ILeafElement) allElement);
                continue;
              case IBlockElement _ when "inline-block".Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(allElement)):
                this.inlineHelper.Add((IBlockElement) allElement);
                continue;
              case IElement _:
                flag2 = this.AddBlockChild((IElement) allElement) & flag2;
                continue;
              default:
                continue;
            }
          }
          flag1 = flag2;
          break;
        default:
          if (elementResult is IFormField && (!(childTagWorker is IDisplayAware) || !"block".Equals(((IDisplayAware) childTagWorker).GetDisplay())))
          {
            this.inlineHelper.Add((IBlockElement) elementResult);
            flag1 = true;
            break;
          }
          if (elementResult is AreaBreak)
          {
            this.PostProcessInlineGroup();
            this.div.Add((AreaBreak) elementResult);
            flag1 = true;
            break;
          }
          if (childTagWorker is ImgTagWorker && elementResult is IElement && !"block".Equals(((ImgTagWorker) childTagWorker).GetDisplay()))
          {
            this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
            flag1 = true;
            break;
          }
          if (elementResult is IElement)
          {
            flag1 = this.AddBlockChild((IElement) elementResult);
            break;
          }
          break;
      }
      return flag1;
    }

    public virtual IPropertyContainer GetElementResult()
    {
      return this.multicolContainer != null ? (IPropertyContainer) this.multicolContainer : (IPropertyContainer) this.div;
    }

    public virtual string GetDisplay() => this.display;

    protected internal virtual bool AddBlockChild(IElement element)
    {
      this.PostProcessInlineGroup();
      bool flag = false;
      switch (element)
      {
        case IBlockElement _:
          this.div.Add((IBlockElement) element);
          flag = true;
          break;
        case Image _:
          this.div.Add((Image) element);
          flag = true;
          break;
      }
      return flag;
    }

    protected internal virtual void PostProcessInlineGroup()
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.div);
    }
  }
}
