﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.PageMarginBoxWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class PageMarginBoxWorker : DivTagWorker
  {
    private Div wrappedElementResult;

    public PageMarginBoxWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      this.GetElementResult().SetProperty(89, (object) true);
      if (base.GetElementResult() is IBlockElement)
      {
        this.wrappedElementResult = new Div().Add((IBlockElement) base.GetElementResult());
        this.wrappedElementResult.SetProperty(89, (object) false);
      }
      if (!(this.GetElementResult() is IAccessibleElement))
        return;
      ((IAccessibleElement) this.GetElementResult()).GetAccessibilityProperties().SetRole("Artifact");
    }

    public override IPropertyContainer GetElementResult()
    {
      return this.wrappedElementResult != null ? (IPropertyContainer) this.wrappedElementResult : base.GetElementResult();
    }
  }
}
