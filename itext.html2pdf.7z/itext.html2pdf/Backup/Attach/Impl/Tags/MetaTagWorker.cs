﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.MetaTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Pdf;
using iText.Layout;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class MetaTagWorker : ITagWorker
  {
    public MetaTagWorker(IElementNode tag, ProcessorContext context)
    {
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      string attribute1 = element.GetAttribute("name");
      if (attribute1 == null)
        return;
      string lowerInvariant = attribute1.ToLowerInvariant();
      string attribute2 = element.GetAttribute("content");
      if (attribute2 == null || context.GetPdfDocument() == null)
        return;
      PdfDocumentInfo documentInfo = context.GetPdfDocument().GetDocumentInfo();
      if ("author".Equals(lowerInvariant))
        documentInfo.SetAuthor(attribute2);
      else if ("application-name".Equals(lowerInvariant))
        documentInfo.SetCreator(attribute2);
      else if ("keywords".Equals(lowerInvariant))
        documentInfo.SetKeywords(attribute2);
      else if ("description".Equals(lowerInvariant))
        documentInfo.SetSubject(attribute2);
      else
        documentInfo.SetMoreInfo(lowerInvariant, attribute2);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) null;
  }
}
