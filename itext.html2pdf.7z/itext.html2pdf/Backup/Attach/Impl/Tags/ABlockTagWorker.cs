﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ABlockTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Resolver.Resource;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ABlockTagWorker : DivTagWorker
  {
    public ABlockTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      string url = element.GetAttribute("href");
      if (url != null)
      {
        string baseUri = context.GetBaseUri();
        if (baseUri != null)
        {
          UriResolver uriResolver = new UriResolver(baseUri);
          if (!url.StartsWith("#") || !uriResolver.IsLocalBaseUri())
          {
            try
            {
              string str = uriResolver.ResolveAgainstBaseUri(url).ToExternalForm();
              if (!url.EndsWith("/") && str.EndsWith("/"))
                str = str.JSubstring(0, str.Length - 1);
              if (!str.StartsWith("file:"))
                url = str;
            }
            catch (UriFormatException ex)
            {
            }
          }
        }
        ((BlockElement<Div>) this.GetElementResult()).GetAccessibilityProperties().SetRole("Link");
        LinkHelper.ApplyLinkAnnotation(this.GetElementResult(), url, context, element);
      }
      if (this.GetElementResult() == null)
        return;
      string attribute = element.GetAttribute("name");
      this.GetElementResult().SetProperty(17, (object) attribute);
    }
  }
}
