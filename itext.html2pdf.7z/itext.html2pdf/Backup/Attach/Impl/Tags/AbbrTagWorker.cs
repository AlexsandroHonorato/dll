﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.AbbrTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class AbbrTagWorker : SpanTagWorker
  {
    public AbbrTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
    }

    public override bool ProcessContent(string content, ProcessorContext context)
    {
      return base.ProcessContent(content, context);
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      base.ProcessEnd(element, context);
      this.EnrichSpan(element.GetAttribute("title"));
    }

    private void EnrichSpan(string expansionText)
    {
      foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) this.GetAllElements())
      {
        if (allElement is Text)
        {
          Text text = (Text) allElement;
          if (expansionText != null)
          {
            text.GetAccessibilityProperties().SetExpansion(expansionText);
            break;
          }
        }
      }
    }
  }
}
