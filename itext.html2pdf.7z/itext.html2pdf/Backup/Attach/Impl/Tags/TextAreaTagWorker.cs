﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.TextAreaTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Forms.Form.Element;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class TextAreaTagWorker : ITagWorker, IDisplayAware
  {
    private const string DEFAULT_TEXTAREA_NAME = "TextArea";
    private TextArea textArea;
    private string display;

    public TextAreaTagWorker(IElementNode element, ProcessorContext context)
    {
      string name = element.GetAttribute("id") ?? "TextArea";
      this.textArea = new TextArea(context.GetFormFieldNameResolver().ResolveFormName(name));
      int? integer1 = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("rows"));
      int? integer2 = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("cols"));
      ((ElementPropertyContainer<TextArea>) this.textArea).SetProperty(2097158, (object) integer1);
      ((ElementPropertyContainer<TextArea>) this.textArea).SetProperty(2097157, (object) integer2);
      ((ElementPropertyContainer<TextArea>) this.textArea).SetProperty(2097153, (object) !context.IsCreateAcroForm());
      ((ElementPropertyContainer<TextArea>) this.textArea).SetProperty(2097163, (object) element.GetAttribute("lang"));
      ((ElementPropertyContainer<TextArea>) this.textArea).DeleteOwnProperty(105);
      string attribute = element.GetAttribute("placeholder");
      if (attribute != null)
        this.textArea.SetPlaceholder((!string.IsNullOrEmpty(attribute) ? (!string.IsNullOrEmpty(attribute.Trim()) ? (BlockElement<Paragraph>) new Paragraph(attribute) : (BlockElement<Paragraph>) new Paragraph(" ")) : (BlockElement<Paragraph>) new Paragraph()).SetMargin(0.0f));
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      if (content.StartsWith("\r\n"))
        content = content.Substring(2);
      else if (content.StartsWith("\r") || content.StartsWith("\n"))
        content = content.Substring(1);
      ((ElementPropertyContainer<TextArea>) this.textArea).SetProperty(2097155, (object) content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return childTagWorker is PlaceholderTagWorker && this.textArea.GetPlaceholder() != null;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.textArea;

    public virtual string GetDisplay() => this.display;
  }
}
