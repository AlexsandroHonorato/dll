﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ObjectTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Resolver.Resource;
using iText.Svg.Converter;
using iText.Svg.Exceptions;
using iText.Svg.Processors;
using iText.Svg.Processors.Impl;
using Microsoft.Extensions.Logging;
using System;
using System.IO;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ObjectTagWorker : ITagWorker
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (ObjectTagWorker));
    private readonly SvgProcessingUtil processUtil;
    private Image image;
    private ISvgProcessorResult res;

    public ObjectTagWorker(IElementNode element, ProcessorContext context)
    {
      this.processUtil = new SvgProcessingUtil(context.GetResourceResolver());
      if (!this.IsSvgImage(element.GetAttribute("type")))
        return;
      string attribute = element.GetAttribute("data");
      try
      {
        using (Stream stream = context.GetResourceResolver().RetrieveResourceAsInputStream(attribute))
        {
          if (stream == null)
            return;
          SvgConverterProperties converterProperties = ContextMappingHelper.MapToSvgConverterProperties(context);
          if (!ResourceResolver.IsDataSrc(attribute))
          {
            string str = FileUtil.ParentDirectory(context.GetResourceResolver().ResolveAgainstBaseUri(attribute));
            converterProperties.SetBaseUri(str);
          }
          this.res = SvgConverter.ParseAndProcess(stream, (ISvgConverterProperties) converterProperties);
        }
      }
      catch (SvgProcessingException ex)
      {
        LoggerExtensions.LogError(ObjectTagWorker.LOGGER, ((Exception) ex).Message, Array.Empty<object>());
      }
      catch (IOException ex)
      {
        LoggerExtensions.LogError(ObjectTagWorker.LOGGER, MessageFormatUtil.Format("Unable to retrieve stream with given base URI ({0}) and source path ({1})", new object[3]
        {
          (object) context.GetBaseUri(),
          (object) element.GetAttribute("data"),
          (object) ex
        }), Array.Empty<object>());
      }
      catch (UriFormatException ex)
      {
        LoggerExtensions.LogError(ObjectTagWorker.LOGGER, MessageFormatUtil.Format("Unable to retrieve stream with given base URI ({0}) and source path ({1})", new object[3]
        {
          (object) context.GetBaseUri(),
          (object) element.GetAttribute("data"),
          (object) ex
        }), Array.Empty<object>());
      }
    }

    private bool IsSvgImage(string typeAttribute) => "image/svg+xml".Equals(typeAttribute);

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      if (this.res == null)
        return;
      this.image = this.processUtil.CreateSvgImageFromProcessingResult(this.res);
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.image, element);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.image;
  }
}
