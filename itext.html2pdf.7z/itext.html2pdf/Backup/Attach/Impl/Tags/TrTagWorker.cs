﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.TrTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class TrTagWorker : ITagWorker
  {
    private TableRowWrapper rowWrapper;
    private ITagWorker parentTagWorker;
    private string lang;

    public TrTagWorker(IElementNode element, ProcessorContext context)
    {
      this.rowWrapper = new TableRowWrapper();
      this.parentTagWorker = context.GetState().Empty() ? (ITagWorker) null : context.GetState().Top();
      if (this.parentTagWorker is TableTagWorker)
        ((TableTagWorker) this.parentTagWorker).ApplyColStyles();
      this.lang = element.GetAttribute(nameof (lang));
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      return this.parentTagWorker != null && this.parentTagWorker.ProcessContent(content, context);
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      if (!(childTagWorker.GetElementResult() is Cell))
        return false;
      Cell elementResult = (Cell) childTagWorker.GetElementResult();
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) elementResult, this.lang);
      this.rowWrapper.AddCell(elementResult);
      return true;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) null;

    internal virtual TableRowWrapper GetTableRowWrapper() => this.rowWrapper;
  }
}
