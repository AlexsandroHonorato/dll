﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.PageCountWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Css.Resolve.Func.Counter;
using iText.Layout;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class PageCountWorker : SpanTagWorker
  {
    private IPropertyContainer pageCountElement;

    public PageCountWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
      if (!(element is PageCountElementNode))
        return;
      CounterDigitsGlyphStyle digitsGlyphStyle = ((PageCountElementNode) element).GetDigitsGlyphStyle();
      if (element is PageTargetCountElementNode)
      {
        this.pageCountElement = (IPropertyContainer) new PageTargetCountElement(((PageTargetCountElementNode) element).GetTarget(), digitsGlyphStyle);
      }
      else
      {
        bool flag = ((PageCountElementNode) element).IsTotalPageCount();
        this.pageCountElement = (IPropertyContainer) new PageCountElement(digitsGlyphStyle);
        this.pageCountElement.SetProperty(1048578, (object) (PageCountType) (flag ? 1 : 0));
      }
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.ProcessTagChild((ITagWorker) this, context);
      base.ProcessEnd(element, context);
    }

    public override IPropertyContainer GetElementResult() => this.pageCountElement;
  }
}
