﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.BrTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class BrTagWorker : ITagWorker
  {
    private Text newLine = new Text("\n");

    public BrTagWorker(IElementNode element, ProcessorContext context)
    {
      IList<string> col = FontFamilySplitterUtil.SplitFontFamily(((IStylesContainer) element).GetStyles().Get<string, string>("font-family"));
      this.newLine.SetFontFamily(col.ToArray<string>(new string[col.Count]));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.newLine, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.newLine;
  }
}
