﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.DisplayFlexTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Renderer;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;
using System.Text.RegularExpressions;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class DisplayFlexTagWorker : ITagWorker, IDisplayAware
  {
    private static readonly Regex ANY_SYMBOL_PATTERN = StringUtil.RegexCompile("\\S+");
    private readonly Div flexContainer;
    private readonly WaitingInlineElementsHelper inlineHelper;

    public DisplayFlexTagWorker(IElementNode element, ProcessorContext context)
    {
      this.flexContainer = new Div();
      this.flexContainer.SetNextRenderer((IRenderer) new FlexContainerRenderer(this.flexContainer));
      IDictionary<string, string> styles = ((IStylesContainer) element).GetStyles();
      this.inlineHelper = new WaitingInlineElementsHelper(styles == null ? (string) null : styles.Get<string, string>("white-space"), styles == null ? (string) null : styles.Get<string, string>("text-transform"));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.flexContainer, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      if (!this.InlineHelperContainsText())
        return;
      this.AddInlineWaitingLeavesToFlexContainer();
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      if (Matcher.Match(DisplayFlexTagWorker.ANY_SYMBOL_PATTERN, content).Find())
        this.inlineHelper.Add(content);
      return true;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.flexContainer;

    public virtual string GetDisplay() => "flex";

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      if (childTagWorker is BrTagWorker)
      {
        this.inlineHelper.Add((ILeafElement) elementResult);
      }
      else
      {
        if (this.InlineHelperContainsText())
          this.AddInlineWaitingLeavesToFlexContainer();
        switch (elementResult)
        {
          case IBlockElement _:
            this.flexContainer.Add((IBlockElement) elementResult);
            break;
          case Image _:
            this.flexContainer.Add((Image) elementResult);
            break;
          case AreaBreak _:
            this.flexContainer.Add((AreaBreak) elementResult);
            break;
          default:
            return false;
        }
      }
      return true;
    }

    private void AddInlineWaitingLeavesToFlexContainer()
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.flexContainer);
      this.inlineHelper.ClearWaitingLeaves();
    }

    private bool InlineHelperContainsText()
    {
      bool flag = false;
      foreach (IElement waitingLeaf in (IEnumerable<IElement>) this.inlineHelper.GetWaitingLeaves())
      {
        if (waitingLeaf is iText.Layout.Element.Text && Matcher.Match(DisplayFlexTagWorker.ANY_SYMBOL_PATTERN, ((iText.Layout.Element.Text) waitingLeaf).GetText()).Find())
          flag = true;
      }
      return flag;
    }
  }
}
