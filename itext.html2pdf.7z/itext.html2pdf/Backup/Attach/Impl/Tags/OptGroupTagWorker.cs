﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.OptGroupTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class OptGroupTagWorker : DivTagWorker
  {
    public OptGroupTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
      string text = element.GetAttribute("label");
      if (text == null || string.IsNullOrEmpty(text))
        text = " ";
      this.GetElementResult().SetProperty(2097162, (object) text);
      Paragraph element1 = new Paragraph(text).SetMargin(0.0f);
      element1.SetProperty(103, (object) OverflowPropertyValue.VISIBLE);
      element1.SetProperty(104, (object) OverflowPropertyValue.VISIBLE);
      ((Div) this.GetElementResult()).Add((IBlockElement) element1);
    }

    public override bool ProcessContent(string content, ProcessorContext context)
    {
      return content == null || string.IsNullOrEmpty(content.Trim());
    }

    public override bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      if (!(childTagWorker is OptionTagWorker))
        return base.ProcessTagChild(childTagWorker, context);
      IPropertyContainer elementResult1 = childTagWorker.GetElementResult();
      IPropertyContainer elementResult2 = this.GetElementResult();
      if (elementResult2 is IAccessibleElement)
      {
        string language = ((IAccessibleElement) elementResult2).GetAccessibilityProperties().GetLanguage();
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) childTagWorker.GetElementResult(), language);
      }
      return this.AddBlockChild((IElement) elementResult1);
    }
  }
}
