﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ColTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ColTagWorker : ITagWorker
  {
    private ColWrapper col;

    public ColTagWorker(IElementNode element, ProcessorContext context)
    {
      int? integer = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("span"));
      this.col = new ColWrapper(integer.HasValue ? integer.Value : 1);
      this.col.SetLang(element.GetAttribute("lang"));
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      return content == null || string.IsNullOrEmpty(content.Trim());
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) null;

    public virtual ColWrapper GetColumn() => this.col;
  }
}
