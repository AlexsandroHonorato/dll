﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.ImgTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Utils;
using iText.Html2pdf.Attach.Util;
using iText.Kernel.Pdf.Xobject;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using iText.Svg.Element;
using iText.Svg.Xobject;
using Microsoft.Extensions.Logging;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class ImgTagWorker : ITagWorker
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (ImgTagWorker));
    private Image image;
    private string display;

    public ImgTagWorker(IElementNode element, ProcessorContext context)
    {
      string attribute1 = element.GetAttribute("src");
      PdfXObject xObject = context.GetResourceResolver().RetrieveImage(attribute1);
      switch (xObject)
      {
        case null:
          this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
          if (((IStylesContainer) element).GetStyles() != null && "absolute".Equals(((IStylesContainer) element).GetStyles().Get<string, string>("position")))
            this.display = "block";
          if (this.image != null)
          {
            string attribute2 = element.GetAttribute("alt");
            if (attribute2 != null)
              this.image.GetAccessibilityProperties().SetAlternateDescription(attribute2);
            AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.image, element);
          }
          if (this.image == null)
            break;
          this.image.SetObjectFit(this.GetObjectFitValue(((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>("object-fit") : (string) null));
          break;
        case PdfImageXObject _:
          this.image = (Image) new ImgTagWorker.HtmlImage((PdfImageXObject) xObject);
          goto case null;
        case SvgImageXObject _:
          this.image = (Image) new SvgImage((SvgImageXObject) xObject);
          goto case null;
        case PdfFormXObject _:
          this.image = (Image) new ImgTagWorker.HtmlImage((PdfFormXObject) xObject);
          goto case null;
        default:
          throw new InvalidOperationException();
      }
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
    }

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.image;

    internal virtual string GetDisplay() => this.display;

    private ObjectFit GetObjectFitValue(string objectFitValue)
    {
      switch (objectFitValue)
      {
        case null:
          return ObjectFit.FILL;
        case "contain":
          return ObjectFit.CONTAIN;
        case "cover":
          return ObjectFit.COVER;
        case "scale-down":
          return ObjectFit.SCALE_DOWN;
        case "none":
          return ObjectFit.NONE;
        case "fill":
          return ObjectFit.FILL;
        default:
          LoggerExtensions.LogWarning(ImgTagWorker.LOGGER, MessageFormatUtil.Format("Unexpected value of object-fit property: {0}. Will be processed as default", new object[1]
          {
            (object) objectFitValue
          }), Array.Empty<object>());
          return ObjectFit.FILL;
      }
    }

    private class HtmlImage : Image
    {
      private const double PX_TO_PT_MULTIPLIER = 0.75;
      private double dimensionMultiplier = 1.0;

      public HtmlImage(PdfImageXObject xObject)
        : base(xObject)
      {
        this.dimensionMultiplier = 0.75;
      }

      public HtmlImage(PdfFormXObject xObject)
        : base(xObject)
      {
      }

      public override float GetImageWidth()
      {
        return this.xObject.GetWidth() * (float) this.dimensionMultiplier;
      }

      public override float GetImageHeight()
      {
        return this.xObject.GetHeight() * (float) this.dimensionMultiplier;
      }
    }
  }
}
