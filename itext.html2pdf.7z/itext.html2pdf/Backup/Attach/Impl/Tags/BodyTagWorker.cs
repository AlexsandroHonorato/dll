﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.BodyTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class BodyTagWorker : DivTagWorker
  {
    private ITagWorker parentTagWorker;
    private string lang;

    public BodyTagWorker(IElementNode element, ProcessorContext context)
      : base(element, context)
    {
      this.parentTagWorker = context.GetState().Empty() ? (ITagWorker) null : context.GetState().Top();
      PdfDocument pdfDocument = context.GetPdfDocument();
      if (pdfDocument != null)
      {
        this.lang = element.GetAttribute(nameof (lang));
        if (this.lang == null)
          return;
        pdfDocument.GetCatalog().SetLang(new PdfString(this.lang, "UnicodeBig"));
      }
      else
        this.lang = element.GetLang();
    }

    public override void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      if (this.parentTagWorker != null)
        return;
      base.ProcessEnd(element, context);
      if (context.GetPdfDocument() != null)
        return;
      foreach (IElement child in (IEnumerable<IElement>) ((AbstractElement<Div>) base.GetElementResult()).GetChildren())
      {
        if (child is IAccessibleElement)
          AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) child, this.lang);
      }
    }

    public override bool ProcessContent(string content, ProcessorContext context)
    {
      return this.parentTagWorker == null ? base.ProcessContent(content, context) : this.parentTagWorker.ProcessContent(content, context);
    }

    public override bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return this.parentTagWorker == null ? base.ProcessTagChild(childTagWorker, context) : this.parentTagWorker.ProcessTagChild(childTagWorker, context);
    }

    public override IPropertyContainer GetElementResult()
    {
      return this.parentTagWorker != null ? this.parentTagWorker.GetElementResult() : base.GetElementResult();
    }
  }
}
