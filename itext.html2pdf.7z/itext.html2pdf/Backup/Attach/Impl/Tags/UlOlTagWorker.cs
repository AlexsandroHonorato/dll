﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.UlOlTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class UlOlTagWorker : ITagWorker
  {
    private List list;
    protected internal MulticolContainer multicolContainer;
    private WaitingInlineElementsHelper inlineHelper;

    public UlOlTagWorker(IElementNode element, ProcessorContext context)
    {
      this.list = new List().SetListSymbol("");
      if (((IStylesContainer) element).GetStyles().Get<string, string>("column-count") != null || ((IStylesContainer) element).GetStyles().ContainsKey("column-width"))
      {
        this.multicolContainer = new MulticolContainer();
        this.multicolContainer.Add((IBlockElement) this.list);
      }
      if (element.GetAttribute("start") != null)
      {
        int? integer = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("start"));
        if (integer.HasValue)
          this.list.SetItemStartIndex(integer.Value);
      }
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.list, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.ProcessUnlabeledListItem();
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      if (elementResult is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) elementResult);
        return true;
      }
      switch (childTagWorker)
      {
        case SpanTagWorker _:
          bool flag = true;
          foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
          {
            switch (allElement)
            {
              case ILeafElement _:
                this.inlineHelper.Add((ILeafElement) allElement);
                continue;
              case IBlockElement _:
                if ("inline-block".Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(allElement)))
                {
                  this.inlineHelper.Add((IBlockElement) allElement);
                  continue;
                }
                break;
            }
            flag = this.AddBlockChild(allElement) & flag;
          }
          return flag;
        case IDisplayAware _:
          if ("inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) && childTagWorker.GetElementResult() is IBlockElement)
          {
            this.inlineHelper.Add((IBlockElement) childTagWorker.GetElementResult());
            return true;
          }
          break;
      }
      return this.AddBlockChild(elementResult);
    }

    public virtual IPropertyContainer GetElementResult()
    {
      return this.multicolContainer != null ? (IPropertyContainer) this.multicolContainer : (IPropertyContainer) this.list;
    }

    private void ProcessUnlabeledListItem()
    {
      Paragraph paragraphContainer = this.inlineHelper.CreateParagraphContainer();
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) paragraphContainer);
      if (paragraphContainer.GetChildren().Count <= 0)
        return;
      this.AddUnlabeledListItem((IBlockElement) paragraphContainer);
    }

    private void AddUnlabeledListItem(IBlockElement item)
    {
      ListItem listItem = new ListItem();
      listItem.Add(item);
      listItem.SetProperty(37, (object) null);
      this.list.Add(listItem);
    }

    private bool AddBlockChild(IPropertyContainer child)
    {
      this.ProcessUnlabeledListItem();
      switch (child)
      {
        case ListItem _:
          this.list.Add((ListItem) child);
          return true;
        case IBlockElement _:
          this.AddUnlabeledListItem((IBlockElement) child);
          return true;
        default:
          return false;
      }
    }
  }
}
