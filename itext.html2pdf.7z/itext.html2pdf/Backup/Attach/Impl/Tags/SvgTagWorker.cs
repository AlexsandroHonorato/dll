﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.SvgTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using iText.Svg.Exceptions;
using iText.Svg.Processors;
using iText.Svg.Processors.Impl;
using Microsoft.Extensions.Logging;
using System;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class SvgTagWorker : ITagWorker
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (SvgTagWorker));
    private Image svgImage;
    private ISvgProcessorResult processingResult;

    public SvgTagWorker(IElementNode element, ProcessorContext context)
    {
      this.svgImage = (Image) null;
      SvgConverterProperties converterProperties = ContextMappingHelper.MapToSvgConverterProperties(context);
      try
      {
        this.processingResult = new DefaultSvgProcessor().Process((INode) element, (ISvgConverterProperties) converterProperties);
      }
      catch (SvgProcessingException ex)
      {
        LoggerExtensions.LogError(SvgTagWorker.LOGGER, (Exception) ex, "Unable to process an SVG element", Array.Empty<object>());
      }
      context.StartProcessingInlineSvg();
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      if (this.processingResult == null)
        return;
      this.svgImage = new SvgProcessingUtil(context.GetResourceResolver()).CreateSvgImageFromProcessingResult(this.processingResult);
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.svgImage, element);
      context.EndProcessingInlineSvg();
    }

    public virtual bool ProcessContent(string content, ProcessorContext context) => false;

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.svgImage;
  }
}
