﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.PTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class PTagWorker : ITagWorker, IDisplayAware
  {
    private Paragraph lastParagraph;
    private Div elementsContainer;
    protected internal MulticolContainer multicolContainer;
    private WaitingInlineElementsHelper inlineHelper;
    private string display;

    public PTagWorker(IElementNode element, ProcessorContext context)
    {
      this.lastParagraph = new Paragraph();
      if (((IStylesContainer) element).GetStyles().Get<string, string>("column-count") != null || ((IStylesContainer) element).GetStyles().Get<string, string>("column-width") != null)
      {
        this.multicolContainer = new MulticolContainer();
        this.multicolContainer.Add((IBlockElement) this.lastParagraph);
      }
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.lastParagraph);
      if (this.elementsContainer != null)
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.elementsContainer, element);
      else
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.lastParagraph, element);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      if (childTagWorker is ImgTagWorker && "block".Equals(((ImgTagWorker) childTagWorker).GetDisplay()))
      {
        this.ProcessBlockElement((IElement) childTagWorker.GetElementResult());
        return true;
      }
      if (elementResult is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) elementResult);
        return true;
      }
      if (childTagWorker is IDisplayAware && ("inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) || "inline".Equals(((IDisplayAware) childTagWorker).GetDisplay())) && elementResult is IBlockElement)
      {
        this.inlineHelper.Add((IBlockElement) elementResult);
        return true;
      }
      if (this.IsBlockWithDisplay(childTagWorker, elementResult, "inline-block", false))
      {
        this.inlineHelper.Add((IBlockElement) elementResult);
        return true;
      }
      if (this.IsBlockWithDisplay(childTagWorker, elementResult, "block", false))
      {
        this.ProcessBlockElement((IElement) childTagWorker.GetElementResult());
        return true;
      }
      if (!(childTagWorker is SpanTagWorker))
        return false;
      bool flag = true;
      foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
      {
        if (allElement is ILeafElement)
          this.inlineHelper.Add((ILeafElement) allElement);
        else if (this.IsBlockWithDisplay(childTagWorker, allElement, "inline-block", true))
          this.inlineHelper.Add((IBlockElement) allElement);
        else if (this.IsBlockWithDisplay(childTagWorker, allElement, "block", true))
          this.ProcessBlockElement((IElement) allElement);
        else
          flag = false;
      }
      return flag;
    }

    public virtual IPropertyContainer GetElementResult()
    {
      if (this.multicolContainer != null)
        return (IPropertyContainer) this.multicolContainer;
      return this.elementsContainer != null ? (IPropertyContainer) this.elementsContainer : (IPropertyContainer) this.lastParagraph;
    }

    public virtual string GetDisplay() => this.display;

    private void ProcessBlockElement(IElement propertyContainer)
    {
      if (this.elementsContainer == null)
      {
        this.elementsContainer = new Div();
        this.elementsContainer.Add((IBlockElement) this.lastParagraph);
        if (this.multicolContainer != null)
        {
          this.multicolContainer.GetChildren().Clear();
          this.multicolContainer.Add((IBlockElement) this.elementsContainer);
        }
      }
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.lastParagraph);
      if (propertyContainer is Image)
        this.elementsContainer.Add((Image) propertyContainer);
      else
        this.elementsContainer.Add((IBlockElement) propertyContainer);
      this.lastParagraph = new Paragraph();
      this.elementsContainer.Add((IBlockElement) this.lastParagraph);
    }

    private bool IsBlockWithDisplay(
      ITagWorker childTagWorker,
      IPropertyContainer element,
      string displayMode,
      bool isChild)
    {
      return isChild ? element is IBlockElement && displayMode.Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(element)) : element is IBlockElement && childTagWorker is IDisplayAware && displayMode.Equals(((IDisplayAware) childTagWorker).GetDisplay());
    }
  }
}
