﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.TdTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Css.Apply.Impl;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class TdTagWorker : ITagWorker, IDisplayAware
  {
    private readonly Cell cell;
    private Div childOfMulticolContainer;
    protected internal MulticolContainer multicolContainer;
    private readonly WaitingInlineElementsHelper inlineHelper;
    private readonly string display;

    public TdTagWorker(IElementNode element, ProcessorContext context)
    {
      int? integer = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("colspan"));
      int? nullable1 = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("rowspan"));
      int? nullable2 = integer ?? new int?(1);
      nullable1 = nullable1 ?? new int?(1);
      this.cell = new Cell(nullable1.Value, nullable2.Value);
      this.cell.SetPadding(0.0f);
      IDictionary<string, string> styles = ((IStylesContainer) element).GetStyles();
      if (styles.ContainsKey("column-count") || styles.ContainsKey("column-width"))
      {
        this.multicolContainer = new MulticolContainer();
        this.childOfMulticolContainer = new Div();
        this.multicolContainer.Add((IBlockElement) this.childOfMulticolContainer);
        MultiColumnCssApplierUtil.ApplyMultiCol(styles, context, (IPropertyContainer) this.multicolContainer);
        this.cell.Add((IBlockElement) this.multicolContainer);
      }
      this.inlineHelper = new WaitingInlineElementsHelper(styles.Get<string, string>("white-space"), styles.Get<string, string>("text-transform"));
      this.display = styles.Get<string, string>(nameof (display));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.cell, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper.FlushHangingLeaves(this.GetCellContainer());
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      bool flag1;
      if (childTagWorker is IDisplayAware && "inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) && childTagWorker.GetElementResult() is IBlockElement)
      {
        this.inlineHelper.Add((IBlockElement) childTagWorker.GetElementResult());
        flag1 = true;
      }
      else if (childTagWorker is SpanTagWorker)
      {
        bool flag2 = true;
        foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
        {
          switch (allElement)
          {
            case ILeafElement _:
              this.inlineHelper.Add((ILeafElement) allElement);
              continue;
            case IBlockElement _:
              if ("inline-block".Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(allElement)))
              {
                this.inlineHelper.Add((IBlockElement) allElement);
                continue;
              }
              break;
          }
          flag2 = this.ProcessChild(allElement) & flag2;
        }
        flag1 = flag2;
      }
      else if (childTagWorker.GetElementResult() is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
        flag1 = true;
      }
      else
        flag1 = this.ProcessChild(childTagWorker.GetElementResult());
      return flag1;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.cell;

    public virtual string GetDisplay() => this.display;

    private bool ProcessChild(IPropertyContainer propertyContainer)
    {
      bool flag = false;
      this.inlineHelper.FlushHangingLeaves(this.GetCellContainer());
      if (propertyContainer is IBlockElement)
      {
        if (this.childOfMulticolContainer == null)
          this.cell.Add((IBlockElement) propertyContainer);
        else
          this.childOfMulticolContainer.Add((IBlockElement) propertyContainer);
        flag = true;
      }
      return flag;
    }

    private IPropertyContainer GetCellContainer()
    {
      return this.childOfMulticolContainer != null ? (IPropertyContainer) this.childOfMulticolContainer : (IPropertyContainer) this.cell;
    }
  }
}
