﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.DisplayTableRowTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class DisplayTableRowTagWorker : ITagWorker
  {
    private TableRowWrapper rowWrapper = new TableRowWrapper();
    private WaitingInlineElementsHelper inlineHelper;
    private Cell waitingCell;
    private string lang;

    public DisplayTableRowTagWorker(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
      this.lang = element.GetAttribute(nameof (lang));
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.FlushWaitingCell();
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      bool displayTableCell = childTagWorker is IDisplayAware && "table-cell".Equals(((IDisplayAware) childTagWorker).GetDisplay());
      if (childTagWorker.GetElementResult() is IBlockElement)
      {
        IBlockElement elementResult = (IBlockElement) childTagWorker.GetElementResult();
        this.ProcessCell(elementResult is Cell ? (Cell) elementResult : this.CreateWrapperCell().Add(elementResult), displayTableCell);
        return true;
      }
      if (childTagWorker.GetElementResult() is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
        return true;
      }
      if (!(childTagWorker is SpanTagWorker))
        return false;
      if (displayTableCell)
        this.FlushWaitingCell();
      bool flag = true;
      foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
      {
        if (allElement is ILeafElement)
          this.inlineHelper.Add((ILeafElement) allElement);
        else
          flag = false;
      }
      if (displayTableCell)
        this.FlushWaitingCell();
      return flag;
    }

    public virtual IPropertyContainer GetElementResult()
    {
      TableWrapper tableWrapper = new TableWrapper();
      foreach (Cell cell in (IEnumerable<Cell>) this.rowWrapper.GetCells())
      {
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) cell, this.lang);
        tableWrapper.AddCell(cell);
      }
      return (IPropertyContainer) tableWrapper.ToTable((WaitingColgroupsHelper) null);
    }

    public virtual TableRowWrapper GetTableRowWrapper() => this.rowWrapper;

    private void ProcessCell(Cell cell, bool displayTableCell)
    {
      if (displayTableCell)
      {
        if (this.waitingCell != cell)
        {
          this.FlushWaitingCell();
          this.rowWrapper.AddCell(cell);
        }
        else
        {
          if (cell.IsEmpty())
            return;
          this.rowWrapper.AddCell(cell);
          this.waitingCell = (Cell) null;
        }
      }
      else
      {
        this.FlushInlineElementsToWaitingCell();
        this.waitingCell.Add((IBlockElement) cell);
      }
    }

    private void FlushInlineElementsToWaitingCell()
    {
      if (this.waitingCell == null)
        this.waitingCell = this.CreateWrapperCell();
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.waitingCell);
    }

    private void FlushWaitingCell()
    {
      this.FlushInlineElementsToWaitingCell();
      if (this.waitingCell == null)
        return;
      this.ProcessCell(this.waitingCell, true);
    }

    private Cell CreateWrapperCell() => new Cell().SetBorder(Border.NO_BORDER).SetPadding(0.0f);
  }
}
