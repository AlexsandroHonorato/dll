﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.HtmlTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Forms.Form.Element;
using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Attach.Util;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Css;
using iText.StyledXmlParser.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class HtmlTagWorker : ITagWorker
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (HtmlTagWorker));
    private Document document;
    private WaitingInlineElementsHelper inlineHelper;

    public HtmlTagWorker(IElementNode element, ProcessorContext context)
    {
      bool immediateFlush = context.IsImmediateFlush() && !context.GetCssContext().IsPagesCounterPresent() && !context.IsCreateAcroForm();
      if (context.IsImmediateFlush() && context.IsCreateAcroForm())
        LoggerExtensions.LogInformation(HtmlTagWorker.LOGGER, "Setting createAcroForm disables immediateFlush property", Array.Empty<object>());
      PdfDocument pdfDocument = context.GetPdfDocument();
      this.document = (Document) new HtmlDocument(pdfDocument, pdfDocument.GetDefaultPageSize(), immediateFlush);
      this.document.SetRenderer((DocumentRenderer) new HtmlDocumentRenderer(this.document, immediateFlush));
      DefaultHtmlProcessor.SetConvertedRootElementProperties(((IStylesContainer) element).GetStyles(), context, (IPropertyContainer) this.document);
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
      string attribute = element.GetAttribute("lang");
      if (attribute == null)
        return;
      pdfDocument.GetCatalog().SetLang(new PdfString(attribute, "UnicodeBig"));
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.document);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      bool flag1 = false;
      if (childTagWorker is SpanTagWorker)
      {
        bool flag2 = true;
        foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
        {
          switch (allElement)
          {
            case ILeafElement _:
              this.inlineHelper.Add((ILeafElement) allElement);
              continue;
            case IBlockElement _:
              if ("inline-block".Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(allElement)))
              {
                this.inlineHelper.Add((IBlockElement) allElement);
                continue;
              }
              break;
          }
          flag2 = this.ProcessBlockChild(allElement) & flag2;
        }
        flag1 = flag2;
      }
      else if (childTagWorker.GetElementResult() is IFormField && (!(childTagWorker is IDisplayAware) || !"block".Equals(((IDisplayAware) childTagWorker).GetDisplay())))
      {
        this.inlineHelper.Add((IBlockElement) childTagWorker.GetElementResult());
        flag1 = true;
      }
      else if (childTagWorker.GetElementResult() is AreaBreak)
      {
        this.PostProcessInlineGroup();
        this.document.Add((AreaBreak) childTagWorker.GetElementResult());
        flag1 = true;
      }
      else
      {
        switch (childTagWorker)
        {
          case IDisplayAware _ when "inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) && childTagWorker.GetElementResult() is IBlockElement:
            this.inlineHelper.Add((IBlockElement) childTagWorker.GetElementResult());
            flag1 = true;
            break;
          case BrTagWorker _:
            this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
            flag1 = true;
            break;
          case ImgTagWorker _ when childTagWorker.GetElementResult() is IElement && !"block".Equals(((ImgTagWorker) childTagWorker).GetDisplay()):
            this.inlineHelper.Add((ILeafElement) childTagWorker.GetElementResult());
            flag1 = true;
            break;
          default:
            if (childTagWorker.GetElementResult() != null)
            {
              flag1 = this.ProcessBlockChild(childTagWorker.GetElementResult());
              break;
            }
            break;
        }
      }
      return flag1;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.document;

    public virtual void ProcessPageRules(
      INode rootNode,
      ICssResolver cssResolver,
      ProcessorContext context)
    {
      ((HtmlDocumentRenderer) this.document.GetRenderer()).ProcessPageRules(rootNode, cssResolver, context);
    }

    private bool ProcessBlockChild(IPropertyContainer element)
    {
      this.PostProcessInlineGroup();
      switch (element)
      {
        case IBlockElement _:
          this.document.Add((IBlockElement) element);
          return true;
        case Image _:
          this.document.Add((Image) element);
          return true;
        default:
          return false;
      }
    }

    private void PostProcessInlineGroup()
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.document);
    }
  }
}
