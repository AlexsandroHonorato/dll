﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.TableTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Attach.Wrapelement;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class TableTagWorker : ITagWorker, IDisplayAware
  {
    private TableWrapper tableWrapper;
    private Table table;
    private bool footer;
    private bool header;
    private ITagWorker parentTagWorker;
    private WaitingColgroupsHelper colgroupsHelper;
    private string display;

    public TableTagWorker(IElementNode element, ProcessorContext context)
    {
      this.tableWrapper = new TableWrapper("rtl".Equals(((IStylesContainer) element).GetStyles().Get<string, string>("direction")));
      this.parentTagWorker = context.GetState().Empty() ? (ITagWorker) null : context.GetState().Top();
      if (this.parentTagWorker is TableTagWorker)
        ((TableTagWorker) this.parentTagWorker).ApplyColStyles();
      else
        this.colgroupsHelper = new WaitingColgroupsHelper(element);
      this.display = ((IStylesContainer) element).GetStyles() != null ? ((IStylesContainer) element).GetStyles().Get<string, string>(nameof (display)) : (string) null;
      string attribute = element.GetAttribute("lang");
      if (attribute == null)
        return;
      this.tableWrapper.SetLang(attribute);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.table = this.tableWrapper.ToTable(this.colgroupsHelper);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      return this.parentTagWorker != null && this.parentTagWorker.ProcessContent(content, context);
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      switch (childTagWorker)
      {
        case TrTagWorker _:
          TableRowWrapper tableRowWrapper = ((TrTagWorker) childTagWorker).GetTableRowWrapper();
          this.tableWrapper.NewRow();
          foreach (Cell cell in (IEnumerable<Cell>) tableRowWrapper.GetCells())
            this.tableWrapper.AddCell(cell);
          return true;
        case TableTagWorker _:
          if (((TableTagWorker) childTagWorker).header)
          {
            Table table = ((TableTagWorker) childTagWorker).tableWrapper.ToTable(this.colgroupsHelper);
            this.tableWrapper.SetHeaderLang(table.GetAccessibilityProperties().GetLanguage());
            for (int row = 0; row < table.GetNumberOfRows(); ++row)
            {
              this.tableWrapper.NewHeaderRow();
              for (int column = 0; column < table.GetNumberOfColumns(); ++column)
              {
                Cell cell = table.GetCell(row, column);
                if (cell != null)
                  this.tableWrapper.AddHeaderCell(cell);
              }
            }
            return true;
          }
          if (((TableTagWorker) childTagWorker).footer)
          {
            Table table = ((TableTagWorker) childTagWorker).tableWrapper.ToTable(this.colgroupsHelper);
            this.tableWrapper.SetFooterLang(table.GetAccessibilityProperties().GetLanguage());
            for (int row = 0; row < table.GetNumberOfRows(); ++row)
            {
              this.tableWrapper.NewFooterRow();
              for (int column = 0; column < table.GetNumberOfColumns(); ++column)
              {
                Cell cell = table.GetCell(row, column);
                if (cell != null)
                  this.tableWrapper.AddFooterCell(cell);
              }
            }
            return true;
          }
          break;
        case ColgroupTagWorker _:
          if (this.colgroupsHelper != null)
          {
            this.colgroupsHelper.Add(((ColgroupTagWorker) childTagWorker).GetColgroup().FinalizeCols());
            return true;
          }
          break;
        case CaptionTagWorker _:
          this.tableWrapper.SetCaption((Div) childTagWorker.GetElementResult());
          return true;
      }
      return false;
    }

    public virtual IPropertyContainer GetElementResult() => (IPropertyContainer) this.table;

    public virtual string GetDisplay() => this.display;

    public virtual void SetFooter() => this.footer = true;

    public virtual void SetHeader() => this.header = true;

    public virtual void ApplyColStyles()
    {
      if (this.colgroupsHelper == null)
        return;
      this.colgroupsHelper.ApplyColStyles();
    }
  }
}
