﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Impl.Tags.LiTagWorker
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Util;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Impl.Tags
{
  public class LiTagWorker : ITagWorker
  {
    protected internal ListItem listItem;
    protected internal List list;
    private WaitingInlineElementsHelper inlineHelper;

    public LiTagWorker(IElementNode element, ProcessorContext context)
    {
      this.listItem = new ListItem();
      if (element.GetAttribute("value") != null)
      {
        int? integer = CssDimensionParsingUtils.ParseInteger(element.GetAttribute("value"));
        if (integer.HasValue)
          this.listItem.SetListSymbolOrdinalValue(integer.Value);
      }
      if (!(context.GetState().Top() is UlOlTagWorker))
      {
        this.listItem.SetProperty(83, (object) ListSymbolPosition.INSIDE);
        float absoluteLength = CssDimensionParsingUtils.ParseAbsoluteLength(((IStylesContainer) element).GetStyles().Get<string, string>("font-size"));
        if ("li".Equals(element.Name()))
          ListStyleApplierUtil.SetDiscStyle((IPropertyContainer) this.listItem, absoluteLength);
        else
          this.listItem.SetProperty(37, (object) null);
        this.list = new List();
        this.list.Add(this.listItem);
      }
      this.inlineHelper = new WaitingInlineElementsHelper(((IStylesContainer) element).GetStyles().Get<string, string>("white-space"), ((IStylesContainer) element).GetStyles().Get<string, string>("text-transform"));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) this.listItem, element);
    }

    public virtual void ProcessEnd(IElementNode element, ProcessorContext context)
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.listItem);
    }

    public virtual bool ProcessContent(string content, ProcessorContext context)
    {
      this.inlineHelper.Add(content);
      return true;
    }

    public virtual bool ProcessTagChild(ITagWorker childTagWorker, ProcessorContext context)
    {
      IPropertyContainer elementResult = childTagWorker.GetElementResult();
      if (elementResult is ILeafElement)
      {
        this.inlineHelper.Add((ILeafElement) elementResult);
        return true;
      }
      switch (childTagWorker)
      {
        case IDisplayAware _ when ("inline-block".Equals(((IDisplayAware) childTagWorker).GetDisplay()) || "inline".Equals(((IDisplayAware) childTagWorker).GetDisplay())) && elementResult is IBlockElement:
          this.inlineHelper.Add((IBlockElement) elementResult);
          return true;
        case SpanTagWorker _:
          bool flag = true;
          foreach (IPropertyContainer allElement in (IEnumerable<IPropertyContainer>) ((SpanTagWorker) childTagWorker).GetAllElements())
          {
            switch (allElement)
            {
              case ILeafElement _:
                this.inlineHelper.Add((ILeafElement) allElement);
                continue;
              case IBlockElement _:
                if ("inline-block".Equals(((SpanTagWorker) childTagWorker).GetElementDisplay(allElement)))
                {
                  this.inlineHelper.Add((IBlockElement) allElement);
                  continue;
                }
                break;
            }
            flag = this.ProcessChild(allElement) & flag;
          }
          return flag;
        default:
          return this.ProcessChild(childTagWorker.GetElementResult());
      }
    }

    public virtual IPropertyContainer GetElementResult()
    {
      return this.list == null ? (IPropertyContainer) this.listItem : (IPropertyContainer) this.list;
    }

    private bool ProcessChild(IPropertyContainer propertyContainer)
    {
      this.inlineHelper.FlushHangingLeaves((IPropertyContainer) this.listItem);
      switch (propertyContainer)
      {
        case Image _:
          this.listItem.Add((Image) propertyContainer);
          return true;
        case IBlockElement _:
          this.listItem.Add((IBlockElement) propertyContainer);
          return true;
        default:
          return false;
      }
    }
  }
}
