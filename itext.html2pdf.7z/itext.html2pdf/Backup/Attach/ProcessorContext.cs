﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.ProcessorContext
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Actions.Contexts;
using iText.Html2pdf.Attach.Impl;
using iText.Html2pdf.Css.Apply;
using iText.Html2pdf.Css.Apply.Impl;
using iText.Html2pdf.Css.Resolve;
using iText.Html2pdf.Resolver.Font;
using iText.Html2pdf.Resolver.Form;
using iText.Html2pdf.Resolver.Resource;
using iText.IO.Font;
using iText.Kernel.Pdf;
using iText.Layout.Font;
using iText.StyledXmlParser.Css.Media;
using iText.StyledXmlParser.Resolver.Resource;

#nullable disable
namespace iText.Html2pdf.Attach
{
  public class ProcessorContext
  {
    private FontProvider fontProvider;
    private FontSet tempFonts;
    private ResourceResolver resourceResolver;
    private MediaDeviceDescription deviceDescription;
    private ITagWorkerFactory tagWorkerFactory;
    private ICssApplierFactory cssApplierFactory;
    private string baseUri;
    private bool createAcroForm;
    private FormFieldNameResolver formFieldNameResolver;
    private RadioCheckResolver radioCheckResolver;
    private OutlineHandler outlineHandler;
    private bool immediateFlush;
    private State state;
    private CssContext cssContext;
    private LinkContext linkContext;
    private PdfDocument pdfDocument;
    private readonly PdfAConformanceLevel pdfAConformanceLevelFromProperties;
    private IMetaInfo metaInfo;
    private bool processingInlineSvg;
    private readonly int limitOfLayouts;
    private bool continuousContainerEnabled;

    public ProcessorContext(ConverterProperties converterProperties)
    {
      if (converterProperties == null)
        converterProperties = new ConverterProperties();
      this.state = new State();
      this.deviceDescription = converterProperties.GetMediaDeviceDescription();
      if (this.deviceDescription == null)
        this.deviceDescription = MediaDeviceDescription.GetDefault();
      this.fontProvider = converterProperties.GetFontProvider();
      if (this.fontProvider == null)
        this.fontProvider = (FontProvider) new DefaultFontProvider();
      this.tagWorkerFactory = converterProperties.GetTagWorkerFactory();
      if (this.tagWorkerFactory == null)
        this.tagWorkerFactory = DefaultTagWorkerFactory.GetInstance();
      this.cssApplierFactory = converterProperties.GetCssApplierFactory();
      if (this.cssApplierFactory == null)
        this.cssApplierFactory = DefaultCssApplierFactory.GetInstance();
      this.baseUri = converterProperties.GetBaseUri();
      if (this.baseUri == null)
        this.baseUri = "";
      this.outlineHandler = converterProperties.GetOutlineHandler();
      if (this.outlineHandler == null)
        this.outlineHandler = new OutlineHandler();
      this.resourceResolver = (ResourceResolver) new HtmlResourceResolver(this.baseUri, this, converterProperties.GetResourceRetriever());
      this.limitOfLayouts = converterProperties.GetLimitOfLayouts();
      this.cssContext = new CssContext();
      this.linkContext = new LinkContext();
      this.createAcroForm = converterProperties.IsCreateAcroForm();
      this.formFieldNameResolver = new FormFieldNameResolver();
      this.radioCheckResolver = new RadioCheckResolver();
      this.immediateFlush = converterProperties.IsImmediateFlush();
      this.pdfAConformanceLevelFromProperties = converterProperties.GetConformanceLevel();
      this.processingInlineSvg = false;
      this.continuousContainerEnabled = converterProperties.IsContinuousContainerEnabled();
    }

    public virtual int GetLimitOfLayouts() => this.limitOfLayouts;

    public virtual void SetFontProvider(FontProvider fontProvider)
    {
      this.fontProvider = fontProvider;
    }

    public virtual State GetState() => this.state;

    public virtual PdfDocument GetPdfDocument() => this.pdfDocument;

    public virtual IConformanceLevel GetConformanceLevel()
    {
      return this.pdfDocument != null ? this.pdfDocument.GetConformanceLevel() : (IConformanceLevel) this.pdfAConformanceLevelFromProperties;
    }

    public virtual FontProvider GetFontProvider() => this.fontProvider;

    public virtual FontSet GetTempFonts() => this.tempFonts;

    public virtual ResourceResolver GetResourceResolver() => this.resourceResolver;

    public virtual MediaDeviceDescription GetDeviceDescription() => this.deviceDescription;

    public virtual ITagWorkerFactory GetTagWorkerFactory() => this.tagWorkerFactory;

    public virtual ICssApplierFactory GetCssApplierFactory() => this.cssApplierFactory;

    public virtual CssContext GetCssContext() => this.cssContext;

    public virtual LinkContext GetLinkContext() => this.linkContext;

    public virtual bool IsCreateAcroForm() => this.createAcroForm;

    public virtual FormFieldNameResolver GetFormFieldNameResolver() => this.formFieldNameResolver;

    public virtual RadioCheckResolver GetRadioCheckResolver() => this.radioCheckResolver;

    public virtual OutlineHandler GetOutlineHandler() => this.outlineHandler;

    public virtual void AddTemporaryFont(FontInfo fontInfo, string alias)
    {
      if (this.tempFonts == null)
        this.tempFonts = new FontSet();
      this.tempFonts.AddFont(fontInfo, alias);
    }

    public virtual void AddTemporaryFont(FontProgram fontProgram, string encoding, string alias)
    {
      if (this.tempFonts == null)
        this.tempFonts = new FontSet();
      this.tempFonts.AddFont(fontProgram, encoding, alias);
    }

    public virtual void AddTemporaryFont(
      FontProgram fontProgram,
      string encoding,
      string alias,
      Range unicodeRange)
    {
      if (this.tempFonts == null)
        this.tempFonts = new FontSet();
      this.tempFonts.AddFont(fontProgram, encoding, alias, unicodeRange);
    }

    public virtual bool HasFonts()
    {
      if (!this.fontProvider.GetFontSet().IsEmpty())
        return true;
      return this.tempFonts != null && !this.tempFonts.IsEmpty();
    }

    public virtual void Reset()
    {
      this.pdfDocument = (PdfDocument) null;
      this.state = new State();
      this.resourceResolver.ResetCache();
      this.cssContext = new CssContext();
      this.linkContext = new LinkContext();
      this.formFieldNameResolver.Reset();
      this.fontProvider.Reset();
      this.tempFonts = (FontSet) null;
      this.outlineHandler.Reset();
      this.processingInlineSvg = false;
    }

    public virtual void Reset(PdfDocument pdfDocument)
    {
      this.Reset();
      this.pdfDocument = pdfDocument;
    }

    public virtual string GetBaseUri() => this.baseUri;

    public virtual bool IsImmediateFlush() => this.immediateFlush;

    public virtual HtmlMetaInfoContainer GetMetaInfoContainer()
    {
      return new HtmlMetaInfoContainer(this.metaInfo);
    }

    public virtual void SetMetaInfo(IMetaInfo metaInfo) => this.metaInfo = metaInfo;

    public virtual bool IsProcessingInlineSvg() => this.processingInlineSvg;

    public virtual void StartProcessingInlineSvg() => this.processingInlineSvg = true;

    public virtual void EndProcessingInlineSvg() => this.processingInlineSvg = false;

    public virtual bool IsContinuousContainerEnabled() => this.continuousContainerEnabled;
  }
}
