﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.IHtmlProcessor
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach
{
  public interface IHtmlProcessor
  {
    Document ProcessDocument(INode root, PdfDocument pdfDocument);

    IList<IElement> ProcessElements(INode root);
  }
}
