﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Attacher
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach
{
  public class Attacher
  {
    private Attacher()
    {
    }

    public static Document Attach(
      IDocumentNode documentNode,
      PdfDocument pdfDocument,
      ConverterProperties converterProperties)
    {
      return new DefaultHtmlProcessor(converterProperties).ProcessDocument((INode) documentNode, pdfDocument);
    }

    public static IList<IElement> Attach(
      IDocumentNode documentNode,
      ConverterProperties converterProperties)
    {
      return new DefaultHtmlProcessor(converterProperties).ProcessElements((INode) documentNode);
    }
  }
}
