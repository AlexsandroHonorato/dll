﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.State
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach
{
  public class State
  {
    private Stack<ITagWorker> stack;

    public State() => this.stack = new Stack<ITagWorker>();

    public virtual Stack<ITagWorker> GetStack() => this.stack;

    public virtual void Push(ITagWorker tagWorker) => this.stack.Push(tagWorker);

    public virtual ITagWorker Pop() => this.stack.Pop();

    public virtual ITagWorker Top() => this.stack.Peek();

    public virtual bool Empty() => this.stack.Count == 0;
  }
}
