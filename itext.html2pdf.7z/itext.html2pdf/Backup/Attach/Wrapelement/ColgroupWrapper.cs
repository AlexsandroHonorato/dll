﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Wrapelement.ColgroupWrapper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Wrapelement
{
  public class ColgroupWrapper : IWrapElement
  {
    private int span;
    private string lang;
    private UnitValue width;
    private int[] indexToColMapping;
    private IDictionary<string, string> cellCssProps;
    private IDictionary<string, string> ownCssProps;
    private IList<ColWrapper> columns = (IList<ColWrapper>) new List<ColWrapper>();

    public ColgroupWrapper(int span) => this.span = span;

    public virtual int GetSpan() => this.span;

    public virtual UnitValue GetWidth() => this.width;

    public virtual ColgroupWrapper SetWidth(UnitValue width)
    {
      this.width = width;
      return this;
    }

    public virtual IDictionary<string, string> GetCellCssProps() => this.cellCssProps;

    public virtual ColgroupWrapper SetCellCssProps(IDictionary<string, string> cellCssProps)
    {
      this.cellCssProps = cellCssProps;
      return this;
    }

    public virtual IDictionary<string, string> GetOwnCssProps() => this.ownCssProps;

    public virtual ColgroupWrapper SetOwnCssProps(IDictionary<string, string> ownCssProps)
    {
      this.ownCssProps = ownCssProps;
      return this;
    }

    public virtual IList<ColWrapper> GetColumns() => this.columns;

    public virtual ColgroupWrapper FinalizeCols()
    {
      if (this.indexToColMapping != null)
        return this;
      if (this.columns.IsEmpty<ColWrapper>())
      {
        this.columns.Add(new ColWrapper(this.span).SetCellCssProps(this.cellCssProps).SetWidth(this.width));
      }
      else
      {
        if (this.cellCssProps != null)
        {
          foreach (ColWrapper column in (IEnumerable<ColWrapper>) this.columns)
          {
            IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>(this.cellCssProps);
            if (column.GetCellCssProps() != null)
              dictionary.AddAll<string, string>(column.GetCellCssProps());
            if (dictionary.Count > 0)
              column.SetCellCssProps(dictionary);
            if (column.GetWidth() == null)
              column.SetWidth(this.width);
          }
        }
        if (this.lang != null)
        {
          foreach (ColWrapper column in (IEnumerable<ColWrapper>) this.columns)
          {
            if (column.GetLang() == null)
              column.SetLang(this.lang);
          }
        }
      }
      this.columns = JavaCollectionsUtil.UnmodifiableList<ColWrapper>(this.columns);
      int length = 0;
      foreach (ColWrapper column in (IEnumerable<ColWrapper>) this.columns)
        length += column.GetSpan();
      this.indexToColMapping = new int[length];
      this.span = 0;
      for (int index1 = 0; index1 < this.columns.Count; ++index1)
      {
        int span = this.columns[index1].GetSpan();
        for (int index2 = 0; index2 < span; ++index2)
          this.indexToColMapping[this.span + index2] = index1;
        this.span += span;
      }
      return this;
    }

    public virtual ColWrapper GetColumnByIndex(int index)
    {
      return this.columns[this.indexToColMapping[index]];
    }

    public virtual void SetLang(string lang) => this.lang = lang;

    public virtual string GetLang() => this.lang;
  }
}
