﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Wrapelement.ColWrapper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout.Properties;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Wrapelement
{
  public class ColWrapper : IWrapElement
  {
    private int span;
    private string lang;
    private UnitValue width;
    private IDictionary<string, string> cellCssProps;
    private IDictionary<string, string> ownCssProps;

    public ColWrapper(int span) => this.span = span;

    public virtual int GetSpan() => this.span;

    public virtual UnitValue GetWidth() => this.width;

    public virtual ColWrapper SetWidth(UnitValue width)
    {
      this.width = width;
      return this;
    }

    public virtual IDictionary<string, string> GetCellCssProps() => this.cellCssProps;

    public virtual ColWrapper SetCellCssProps(IDictionary<string, string> cellCssProps)
    {
      this.cellCssProps = cellCssProps;
      return this;
    }

    public virtual IDictionary<string, string> GetOwnCssProps() => this.ownCssProps;

    public virtual ColWrapper SetOwnCssProps(IDictionary<string, string> ownCssProps)
    {
      this.ownCssProps = ownCssProps;
      return this;
    }

    public virtual void SetLang(string lang) => this.lang = lang;

    public virtual string GetLang() => this.lang;
  }
}
