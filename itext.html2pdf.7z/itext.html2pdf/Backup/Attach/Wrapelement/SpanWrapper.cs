﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Wrapelement.SpanWrapper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Layout;
using iText.Layout.Element;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Wrapelement
{
  public class SpanWrapper : IWrapElement
  {
    private IList<object> children = (IList<object>) new List<object>();

    public virtual void Add(SpanWrapper span) => this.children.Add((object) span);

    public virtual void Add(ILeafElement img) => this.children.Add((object) img);

    public virtual void Add(IBlockElement block) => this.children.Add((object) block);

    public virtual void AddAll(ICollection<IElement> collection)
    {
      this.children.AddAll<object>((IEnumerable<object>) collection);
    }

    public virtual IList<IPropertyContainer> GetElements()
    {
      IList<IPropertyContainer> c = (IList<IPropertyContainer>) new List<IPropertyContainer>();
      foreach (object child in (IEnumerable<object>) this.children)
      {
        if (child is IPropertyContainer)
          c.Add((IPropertyContainer) child);
        else if (child is SpanWrapper)
          c.AddAll<IPropertyContainer>((IEnumerable<IPropertyContainer>) ((SpanWrapper) child).GetElements());
      }
      return c;
    }
  }
}
