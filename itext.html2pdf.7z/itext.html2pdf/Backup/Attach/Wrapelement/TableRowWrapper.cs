﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Wrapelement.TableRowWrapper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Layout.Element;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Wrapelement
{
  public class TableRowWrapper : IWrapElement
  {
    private IList<Cell> cells = (IList<Cell>) new List<Cell>();

    public virtual void AddCell(Cell cell) => this.cells.Add(cell);

    public virtual IList<Cell> GetCells() => JavaCollectionsUtil.UnmodifiableList<Cell>(this.cells);
  }
}
