﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Wrapelement.TableWrapper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf.Attach.Util;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.Layout.Tagging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Wrapelement
{
  public class TableWrapper : IWrapElement
  {
    private IList<IList<TableWrapper.CellWrapper>> rows;
    private IList<IList<TableWrapper.CellWrapper>> headerRows;
    private IList<IList<TableWrapper.CellWrapper>> footerRows;
    private RowColHelper rowShift = new RowColHelper();
    private RowColHelper headerRowShift = new RowColHelper();
    private RowColHelper footerRowShift = new RowColHelper();
    private int numberOfColumns;
    private bool isRtl;
    private Div caption;
    private string lang;
    private string footerLang;
    private string headerLang;

    public TableWrapper()
    {
    }

    public TableWrapper(bool isRtl) => this.isRtl = isRtl;

    public virtual int GetRowsSize() => this.rows.Count;

    public virtual void NewRow()
    {
      if (this.rows == null)
        this.rows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      this.rowShift.NewRow();
      this.rows.Add((IList<TableWrapper.CellWrapper>) new List<TableWrapper.CellWrapper>());
    }

    public virtual void NewHeaderRow()
    {
      if (this.headerRows == null)
        this.headerRows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      this.headerRowShift.NewRow();
      this.headerRows.Add((IList<TableWrapper.CellWrapper>) new List<TableWrapper.CellWrapper>());
    }

    public virtual void NewFooterRow()
    {
      if (this.footerRows == null)
        this.footerRows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      this.footerRowShift.NewRow();
      this.footerRows.Add((IList<TableWrapper.CellWrapper>) new List<TableWrapper.CellWrapper>());
    }

    public virtual void AddHeaderCell(Cell cell)
    {
      if (this.headerRows == null)
        this.headerRows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      if (this.headerRows.Count == 0)
        this.NewHeaderRow();
      this.AddCellToTable(cell, this.headerRows, this.headerRowShift);
    }

    public virtual void AddFooterCell(Cell cell)
    {
      if (this.footerRows == null)
        this.footerRows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      if (this.footerRows.Count == 0)
        this.NewFooterRow();
      this.AddCellToTable(cell, this.footerRows, this.footerRowShift);
    }

    public virtual void AddCell(Cell cell)
    {
      if (this.rows == null)
        this.rows = (IList<IList<TableWrapper.CellWrapper>>) new List<IList<TableWrapper.CellWrapper>>();
      if (this.rows.Count == 0)
        this.NewRow();
      this.AddCellToTable(cell, this.rows, this.rowShift);
    }

    public virtual void SetLang(string lang) => this.lang = lang;

    public virtual void SetFooterLang(string footerLang) => this.footerLang = footerLang;

    public virtual void SetHeaderLang(string headerLang) => this.headerLang = headerLang;

    private void AddCellToTable(
      Cell cell,
      IList<IList<TableWrapper.CellWrapper>> table,
      RowColHelper tableRowShift)
    {
      int nextEmptyCol = tableRowShift.MoveToNextEmptyCol();
      tableRowShift.UpdateCurrentPosition(cell.GetColspan(), cell.GetRowspan());
      table[table.Count - 1].Add(new TableWrapper.CellWrapper(nextEmptyCol, cell));
      this.numberOfColumns = Math.Max(this.numberOfColumns, nextEmptyCol + cell.GetColspan());
    }

    public virtual void SetCaption(Div caption) => this.caption = caption;

    public virtual Table ToTable(WaitingColgroupsHelper colgroupsHelper)
    {
      Table table = this.numberOfColumns <= 0 ? new Table(1) : new Table(this.GetColWidths(colgroupsHelper));
      AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) table, this.lang);
      if (this.headerRows != null)
      {
        for (int index1 = 0; index1 < this.headerRows.Count; ++index1)
        {
          if (this.isRtl)
            JavaCollectionsUtil.Reverse<TableWrapper.CellWrapper>(this.headerRows[index1]);
          for (int index2 = 0; index2 < this.headerRows[index1].Count; ++index2)
          {
            Cell cell = this.headerRows[index1][index2].cell;
            ColWrapper colWrapper = colgroupsHelper.GetColWrapper(index2);
            if (colWrapper != null && this.headerLang == null && cell.GetAccessibilityProperties().GetLanguage() == null && colWrapper.GetLang() != null)
              cell.GetAccessibilityProperties().SetLanguage(colWrapper.GetLang());
            table.AddHeaderCell(cell);
          }
          if (index1 != this.headerRows.Count - 1)
            table.GetHeader().StartNewRow();
        }
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) table.GetHeader(), this.headerLang);
      }
      if (this.footerRows != null)
      {
        for (int index3 = 0; index3 < this.footerRows.Count; ++index3)
        {
          if (this.isRtl)
            JavaCollectionsUtil.Reverse<TableWrapper.CellWrapper>(this.footerRows[index3]);
          for (int index4 = 0; index4 < this.footerRows[index3].Count; ++index4)
          {
            Cell cell = this.footerRows[index3][index4].cell;
            ColWrapper colWrapper = colgroupsHelper.GetColWrapper(index4);
            if (colWrapper != null && this.footerLang == null && cell.GetAccessibilityProperties().GetLanguage() == null && colWrapper.GetLang() != null)
              cell.GetAccessibilityProperties().SetLanguage(colWrapper.GetLang());
            table.AddFooterCell(cell);
          }
          if (index3 != this.footerRows.Count - 1)
            table.GetFooter().StartNewRow();
        }
        AccessiblePropHelper.TrySetLangAttribute((IAccessibleElement) table.GetFooter(), this.footerLang);
      }
      if (this.rows != null)
      {
        for (int index5 = 0; index5 < this.rows.Count; ++index5)
        {
          if (this.isRtl)
            JavaCollectionsUtil.Reverse<TableWrapper.CellWrapper>(this.rows[index5]);
          for (int index6 = 0; index6 < this.rows[index5].Count; ++index6)
            table.AddCell(this.rows[index5][index6].cell);
          if (index5 != this.rows.Count - 1)
            table.StartNewRow();
        }
      }
      if (this.caption != null)
        table.SetCaption(this.caption);
      return table;
    }

    private UnitValue[] GetColWidths(WaitingColgroupsHelper colgroups)
    {
      UnitValue[] colWidths = new UnitValue[this.numberOfColumns];
      if (colgroups == null)
      {
        for (int index = 0; index < this.numberOfColumns; ++index)
          colWidths[index] = (UnitValue) null;
      }
      else
      {
        for (int index = 0; index < this.numberOfColumns; ++index)
          colWidths[index] = colgroups.GetColWrapper(index) != null ? colgroups.GetColWrapper(index).GetWidth() : (UnitValue) null;
      }
      return colWidths;
    }

    private class CellWrapper
    {
      internal int col;
      internal Cell cell;

      internal CellWrapper(int col, Cell cell)
      {
        this.col = col;
        this.cell = cell;
      }
    }
  }
}
