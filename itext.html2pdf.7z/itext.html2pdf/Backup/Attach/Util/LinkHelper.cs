﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.LinkHelper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons;
using iText.Commons.Datastructures;
using iText.Commons.Utils;
using iText.Html2pdf.Attach.Impl.Tags;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Action;
using iText.Kernel.Pdf.Annot;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;
using iText.StyledXmlParser.Node.Impl.Jsoup.Node;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public class LinkHelper
  {
    private static readonly ILogger LOGGER = ITextLogManager.GetLogger(typeof (LinkHelper));

    private LinkHelper()
    {
    }

    [Obsolete("in favour ofapplyLinkAnnotation(IPropertyContainer container, String url, ProcessorContext context)")]
    public static void ApplyLinkAnnotation(IPropertyContainer container, string url)
    {
      LinkHelper.ApplyLinkAnnotation(container, url, new ProcessorContext(new ConverterProperties()));
    }

    [Obsolete]
    public static void ApplyLinkAnnotation(
      IPropertyContainer container,
      string url,
      ProcessorContext context)
    {
      LinkHelper.ApplyLinkAnnotation(container, url, context, "");
    }

    private static string RetrieveAlternativeDescription(IElementNode element)
    {
      IList<INode> inodeList = ((INode) element).ChildNodes();
      return inodeList.Count == 1 && inodeList[0].ChildNodes().IsEmpty<INode>() && inodeList[0] is JsoupElementNode && ((JsoupElementNode) inodeList[0]).GetAttribute("alt") != null ? ((JsoupElementNode) inodeList[0]).GetAttribute("alt") : element.GetAttribute("title");
    }

    [Obsolete]
    public static void ApplyLinkAnnotation(
      IPropertyContainer container,
      string url,
      ProcessorContext context,
      string alternateDescription)
    {
      if (container == null)
        return;
      PdfLinkAnnotation annot;
      if (url.StartsWith("#"))
      {
        string id = url.Substring(1);
        annot = context.GetLinkContext().GetLinkAnnotation(id);
        if (annot == null)
        {
          annot = (PdfLinkAnnotation) ((PdfAnnotation) new PdfLinkAnnotation(new Rectangle(0.0f, 0.0f, 0.0f, 0.0f)).SetAction(PdfAction.CreateGoTo(id))).SetFlags(4);
          context.GetLinkContext().AddLinkAnnotation(id, annot);
        }
      }
      else
        annot = (PdfLinkAnnotation) ((PdfAnnotation) new PdfLinkAnnotation(new Rectangle(0.0f, 0.0f, 0.0f, 0.0f)).SetAction(PdfAction.CreateURI(url))).SetFlags(4);
      if (container is IAccessibleElement && alternateDescription != null)
        ((IAccessibleElement) container).GetAccessibilityProperties().SetAlternateDescription(alternateDescription);
      ((PdfAnnotation) annot).SetBorder(new PdfArray(new float[3]));
      container.SetProperty(88, (object) annot);
      if (!(container is ILeafElement) || !(container is IAccessibleElement))
        return;
      ((IAccessibleElement) container).GetAccessibilityProperties().SetRole("Link");
    }

    public static void ApplyLinkAnnotation(
      IPropertyContainer container,
      string url,
      ProcessorContext context,
      IElementNode element)
    {
      LinkHelper.ApplyLinkAnnotation(container, url, context, LinkHelper.RetrieveAlternativeDescription(element));
    }

    public static void CreateDestination(
      ITagWorker tagWorker,
      IElementNode element,
      ProcessorContext context)
    {
      string attribute = element.GetAttribute("id");
      if (attribute == null)
        return;
      IPropertyContainer propertyContainer = LinkHelper.GetPropertyContainer(tagWorker);
      if (context.GetLinkContext().IsUsedLinkDestination(attribute))
      {
        if (propertyContainer == null)
        {
          string str = tagWorker != null ? tagWorker.GetType().FullName : "null";
          LoggerExtensions.LogWarning(LinkHelper.LOGGER, MessageFormatUtil.Format("The anchor link was not handled. Could not create a destination for element \"{0}\" with ID \"{1}\", which is processed by \"{2}\" tag worker class.", new object[3]
          {
            (object) element.Name(),
            (object) attribute,
            (object) str
          }), Array.Empty<object>());
          return;
        }
        PdfLinkAnnotation annot = context.GetLinkContext().GetLinkAnnotation(attribute);
        if (annot == null)
        {
          annot = (PdfLinkAnnotation) ((PdfAnnotation) new PdfLinkAnnotation(new Rectangle(0.0f, 0.0f, 0.0f, 0.0f)).SetAction(PdfAction.CreateGoTo(attribute))).SetFlags(4);
          context.GetLinkContext().AddLinkAnnotation(attribute, annot);
        }
        propertyContainer.SetProperty(17, (object) new Tuple2<string, PdfDictionary>(attribute, annot.GetAction()));
      }
      propertyContainer?.SetProperty(126, (object) attribute);
    }

    private static IPropertyContainer GetPropertyContainer(ITagWorker tagWorker)
    {
      if (tagWorker != null)
      {
        if (!(tagWorker is SpanTagWorker))
          return tagWorker.GetElementResult();
        IList<IPropertyContainer> allElements = ((SpanTagWorker) tagWorker).GetAllElements();
        if (!allElements.IsEmpty<IPropertyContainer>())
          return allElements[0];
      }
      return (IPropertyContainer) null;
    }
  }
}
