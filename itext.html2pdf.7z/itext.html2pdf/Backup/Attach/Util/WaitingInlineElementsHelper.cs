﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.WaitingInlineElementsHelper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl.Layout;
using iText.Html2pdf.Css.Apply.Util;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Renderer;
using iText.StyledXmlParser.Util;
using System;
using System.Collections.Generic;
using System.Text;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public class WaitingInlineElementsHelper
  {
    private string textTransform;
    private bool keepLineBreaks;
    private bool collapseSpaces;
    private IList<IElement> waitingLeaves = (IList<IElement>) new List<IElement>();

    public WaitingInlineElementsHelper(string whiteSpace, string textTransform)
    {
      this.keepLineBreaks = "pre".Equals(whiteSpace) || "pre-wrap".Equals(whiteSpace) || "pre-line".Equals(whiteSpace);
      this.collapseSpaces = !"pre".Equals(whiteSpace) && !"pre-wrap".Equals(whiteSpace);
      this.textTransform = textTransform;
    }

    public virtual void Add(string text)
    {
      if (!this.keepLineBreaks && this.collapseSpaces)
        text = WhiteSpaceUtil.CollapseConsecutiveSpaces(text);
      else if (this.keepLineBreaks && this.collapseSpaces)
      {
        StringBuilder stringBuilder = new StringBuilder(text.Length);
        for (int index = 0; index < text.Length; ++index)
        {
          if (TrimUtil.IsNonLineBreakSpace(text[index]))
          {
            if (stringBuilder.Length == 0 || stringBuilder[stringBuilder.Length - 1] != ' ')
              stringBuilder.Append(" ");
          }
          else
            stringBuilder.Append(text[index]);
        }
        text = stringBuilder.ToString();
      }
      else
      {
        StringBuilder sb = new StringBuilder(text.Length);
        sb.Append('\u200D');
        for (int index = 0; index < text.Length; ++index)
        {
          sb.Append(text[index]);
          if ('\n' == text[index] || '\r' == text[index] && index + 1 < text.Length && '\n' != text[index + 1])
            sb.Append('\u200D');
        }
        if ('\u200D' == sb[sb.Length - 1])
          sb.Delete(sb.Length - 1, sb.Length);
        text = sb.ToString();
      }
      if ("uppercase".Equals(this.textTransform))
        text = text.ToUpperInvariant();
      else if ("lowercase".Equals(this.textTransform))
        text = text.ToLowerInvariant();
      this.waitingLeaves.Add((IElement) new iText.Layout.Element.Text(text));
    }

    public virtual void Add(ILeafElement element) => this.waitingLeaves.Add((IElement) element);

    public virtual void Add(IBlockElement element) => this.waitingLeaves.Add((IElement) element);

    public virtual void AddAll(ICollection<ILeafElement> collection)
    {
      this.waitingLeaves.AddAll<IElement>((IEnumerable<IElement>) collection);
    }

    public virtual void FlushHangingLeaves(IPropertyContainer container)
    {
      Paragraph leavesContainer = this.CreateLeavesContainer();
      if (leavesContainer == null)
        return;
      IDictionary<string, string> dictionary = (IDictionary<string, string>) new Dictionary<string, string>();
      dictionary.Put<string, string>("overflow", "visible");
      OverflowApplierUtil.ApplyOverflow(dictionary, (IPropertyContainer) leavesContainer);
      if (container is Document)
        ((RootElement<Document>) container).Add((IBlockElement) leavesContainer);
      else if (container is Paragraph)
      {
        foreach (IElement waitingLeaf in (IEnumerable<IElement>) this.waitingLeaves)
        {
          if (waitingLeaf is ILeafElement)
            ((Paragraph) container).Add((ILeafElement) waitingLeaf);
          else if (waitingLeaf is IBlockElement)
            ((Paragraph) container).Add((IBlockElement) waitingLeaf);
        }
      }
      else if (((IElement) container).GetRenderer() is FlexContainerRenderer)
      {
        Div element = new Div();
        OverflowApplierUtil.ApplyOverflow(dictionary, (IPropertyContainer) element);
        element.Add((IBlockElement) leavesContainer);
        ((Div) container).Add((IBlockElement) element);
      }
      else
      {
        switch (container)
        {
          case Div _:
            ((Div) container).Add((IBlockElement) leavesContainer);
            break;
          case Cell _:
            ((Cell) container).Add((IBlockElement) leavesContainer);
            break;
          case List _:
            ListItem listItem = new ListItem();
            listItem.Add((IBlockElement) leavesContainer);
            ((List) container).Add(listItem);
            break;
          default:
            throw new InvalidOperationException("Unable to process hanging inline content");
        }
      }
      this.waitingLeaves.Clear();
    }

    private Paragraph CreateLeavesContainer()
    {
      if (this.collapseSpaces)
        this.waitingLeaves = TrimUtil.TrimLeafElementsAndSanitize(this.waitingLeaves);
      this.Capitalize(this.waitingLeaves);
      if (this.waitingLeaves.Count <= 0)
        return (Paragraph) null;
      Paragraph paragraphContainer = this.CreateParagraphContainer();
      bool flag = true;
      foreach (IElement waitingLeaf in (IEnumerable<IElement>) this.waitingLeaves)
      {
        if (waitingLeaf is ILeafElement)
        {
          flag = false;
          paragraphContainer.Add((ILeafElement) waitingLeaf);
        }
        else if (waitingLeaf is IBlockElement)
        {
          flag = flag && waitingLeaf is RunningElement;
          paragraphContainer.Add((IBlockElement) waitingLeaf);
        }
      }
      if (flag)
        paragraphContainer.GetAccessibilityProperties().SetRole("Artifact");
      return paragraphContainer;
    }

    public virtual ICollection<IElement> GetWaitingLeaves()
    {
      return (ICollection<IElement>) this.waitingLeaves;
    }

    public virtual IList<IElement> GetSanitizedWaitingLeaves()
    {
      return this.collapseSpaces ? TrimUtil.TrimLeafElementsAndSanitize(this.waitingLeaves) : this.waitingLeaves;
    }

    public virtual void ClearWaitingLeaves() => this.waitingLeaves.Clear();

    public virtual Paragraph CreateParagraphContainer() => new Paragraph().SetMargin(0.0f);

    private void Capitalize(IList<IElement> leaves)
    {
      bool previousAlphabetic = false;
      bool flag1 = false;
      for (int index = 0; index < leaves.Count; ++index)
      {
        IElement leaf = leaves[index];
        int num = leaf.HasOwnProperty(1048581) ? 1 : 0;
        bool flag2 = num != 0 && leaf.GetOwnProperty<bool?>(1048581).Value;
        if (num != 0 && !flag2)
          flag1 = false;
        else if (leaf is iText.Layout.Element.Text && "capitalize".Equals(this.textTransform) | flag2)
        {
          string text = ((iText.Layout.Element.Text) leaf).GetText();
          if (!flag1 && index > 0)
            previousAlphabetic = this.IsLastCharAlphabetic(leaves[index - 1]);
          previousAlphabetic = this.CapitalizeAndReturnIsLastAlphabetic((iText.Layout.Element.Text) leaf, text, previousAlphabetic);
          flag1 = true;
        }
        else
        {
          flag1 = false;
          previousAlphabetic = false;
        }
      }
    }

    private bool IsLastCharAlphabetic(IElement element)
    {
      if (!(element is iText.Layout.Element.Text))
        return false;
      string text = ((iText.Layout.Element.Text) element).GetText();
      return text.Length > 0 && char.IsLetter(text[text.Length - 1]);
    }

    private bool CapitalizeAndReturnIsLastAlphabetic(
      iText.Layout.Element.Text element,
      string text,
      bool previousAlphabetic)
    {
      StringBuilder stringBuilder = new StringBuilder();
      bool flag = previousAlphabetic;
      for (int index = 0; index < text.Length; ++index)
      {
        if (char.IsLower(text[index]) && !flag)
        {
          stringBuilder.Append(char.ToUpper(text[index]));
          flag = true;
        }
        else if (char.IsLetter(text[index]))
        {
          stringBuilder.Append(text[index]);
          flag = true;
        }
        else
        {
          stringBuilder.Append(text[index]);
          flag = false;
        }
      }
      element.SetText(stringBuilder.ToString());
      return flag;
    }
  }
}
