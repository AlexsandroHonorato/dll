﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.RowColHelper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public class RowColHelper
  {
    private List<int> lastEmptyRow = new List<int>();
    private int currRow = -1;
    private int currCol;

    public virtual void NewRow()
    {
      ++this.currRow;
      this.currCol = 0;
    }

    public virtual void UpdateCurrentPosition(int colspan, int rowspan)
    {
      this.EnsureRowIsStarted();
      while (this.lastEmptyRow.Count < this.currCol)
        this.lastEmptyRow.Add(this.currRow);
      int val1 = this.currRow + rowspan;
      int val2 = this.currCol + colspan;
      int num = Math.Min(this.lastEmptyRow.Count, val2);
      for (int currCol = this.currCol; currCol < num; ++currCol)
        this.lastEmptyRow[currCol] = Math.Max(val1, this.lastEmptyRow[currCol]);
      while (this.lastEmptyRow.Count < val2)
        this.lastEmptyRow.Add(val1);
      this.currCol = val2;
    }

    public virtual int MoveToNextEmptyCol()
    {
      this.EnsureRowIsStarted();
      while (!this.CanPutCell(this.currCol))
        ++this.currCol;
      return this.currCol;
    }

    private bool CanPutCell(int col)
    {
      this.EnsureRowIsStarted();
      return col >= this.lastEmptyRow.Count || this.lastEmptyRow[col] <= this.currRow;
    }

    private void EnsureRowIsStarted()
    {
      if (this.currRow != -1)
        return;
      this.NewRow();
    }
  }
}
