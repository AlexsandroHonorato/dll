﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.TrimUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Impl.Layout;
using iText.Layout.Borders;
using iText.Layout.Element;
using iText.Layout.Properties;
using iText.StyledXmlParser.Util;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public sealed class TrimUtil
  {
    private TrimUtil()
    {
    }

    internal static IList<IElement> TrimLeafElementsAndSanitize(IList<IElement> leafElements)
    {
      List<IElement> list = new List<IElement>((IEnumerable<IElement>) leafElements);
      TrimUtil.TrimSubList(list, 0, list.Count, false);
      TrimUtil.TrimSubList(list, 0, list.Count, true);
      for (int index = 0; index < list.Count - 1; ++index)
      {
        if (list[index] is Text)
        {
          Text text = (Text) list[index];
          if (TrimUtil.IsElementFloating((IElement) text))
          {
            TrimUtil.TrimTextElement(text, false);
            TrimUtil.TrimTextElement(text, true);
          }
          else
          {
            int afterLastNonSpace = TrimUtil.GetIndexAfterLastNonSpace(text);
            if (afterLastNonSpace < text.GetText().Length)
            {
              TrimUtil.TrimSubList(list, index + 1, list.Count, false);
              text.SetText(text.GetText().JSubstring(0, afterLastNonSpace + 1));
            }
          }
        }
      }
      return (IList<IElement>) list;
    }

    internal static bool IsNonLineBreakSpace(char ch)
    {
      return WhiteSpaceUtil.IsNonEmSpace(ch) && ch != '\n';
    }

    private static void TrimSubList(List<IElement> list, int begin, int end, bool last)
    {
      while (end > begin)
      {
        int index = last ? end - 1 : begin;
        IElement leafElement = list[index];
        if (!TrimUtil.IsElementFloating(leafElement))
        {
          switch (leafElement)
          {
            case RunningElement _:
              break;
            case Text _:
              Text text = (Text) leafElement;
              TrimUtil.TrimTextElement(text, last);
              if (text.GetText().Length != 0)
                return;
              if (TrimUtil.HasZeroWidth((IElement) text))
                list.JRemoveAt<IElement>(index);
              --end;
              continue;
            default:
              return;
          }
        }
        if (last)
          --end;
        else
          ++begin;
      }
    }

    private static void TrimTextElement(Text text, bool last)
    {
      int indexOfFirstNonSpace = last ? 0 : TrimUtil.GetIndexOfFirstNonSpace(text);
      int endIndex = last ? TrimUtil.GetIndexAfterLastNonSpace(text) : text.GetText().Length;
      text.SetText(text.GetText().JSubstring(indexOfFirstNonSpace, endIndex));
    }

    private static int GetIndexOfFirstNonSpace(Text text)
    {
      int index = 0;
      while (index < text.GetText().Length && TrimUtil.IsNonLineBreakSpace(text.GetText()[index]))
        ++index;
      return index;
    }

    private static int GetIndexAfterLastNonSpace(Text text)
    {
      int length = text.GetText().Length;
      while (length > 0 && TrimUtil.IsNonLineBreakSpace(text.GetText()[length - 1]))
        --length;
      return length;
    }

    private static bool IsElementFloating(IElement leafElement)
    {
      FloatPropertyValue? property1 = leafElement.GetProperty<FloatPropertyValue?>(99);
      int? property2 = leafElement.GetProperty<int?>(52);
      if (property2.HasValue)
      {
        int? nullable = property2;
        int num = 3;
        if (nullable.GetValueOrDefault() == num & nullable.HasValue)
          goto label_4;
      }
      if (property1.HasValue)
        return !property1.Equals((object) FloatPropertyValue.NONE);
label_4:
      return false;
    }

    private static bool HasZeroWidth(IElement leafElement)
    {
      if (leafElement.GetProperty<Border>(12) != null && 0.0 != (double) leafElement.GetProperty<Border>(12).GetWidth() || leafElement.GetProperty<Border>(11) != null && 0.0 != (double) leafElement.GetProperty<Border>(11).GetWidth() || leafElement.GetProperty<UnitValue>(49) != null && 0.0 != (double) leafElement.GetProperty<UnitValue>(49).GetValue() || leafElement.GetProperty<UnitValue>(48) != null && 0.0 != (double) leafElement.GetProperty<UnitValue>(48).GetValue() || leafElement.GetProperty<UnitValue>(45) != null && 0.0 != (double) leafElement.GetProperty<UnitValue>(45).GetValue())
        return false;
      return leafElement.GetProperty<UnitValue>(44) == null || 0.0 == (double) leafElement.GetProperty<UnitValue>(44).GetValue();
    }
  }
}
