﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.WaitingColgroupsHelper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Html2pdf.Attach.Wrapelement;
using iText.StyledXmlParser.Css.Util;
using iText.StyledXmlParser.Node;
using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public class WaitingColgroupsHelper
  {
    private IElementNode tableElement;
    private List<ColgroupWrapper> colgroups = new List<ColgroupWrapper>();
    private int maxIndex = -1;
    private int[] indexToColgroupMapping;
    private int[] shiftCol;

    public WaitingColgroupsHelper(IElementNode tableElement) => this.tableElement = tableElement;

    public virtual void Add(ColgroupWrapper colgroup) => this.colgroups.Add(colgroup);

    public virtual void ApplyColStyles()
    {
      if (this.colgroups.IsEmpty<ColgroupWrapper>() || this.maxIndex != -1)
        return;
      this.FinalizeColgroups();
      RowColHelper rowColHelper1 = new RowColHelper();
      RowColHelper rowColHelper2 = new RowColHelper();
      RowColHelper rowColHelper3 = new RowColHelper();
      foreach (INode childNode in (IEnumerable<INode>) ((INode) this.tableElement).ChildNodes())
      {
        if (childNode is IElementNode)
        {
          IElementNode node = (IElementNode) childNode;
          if ("thead".Equals(node.Name()))
            this.ApplyColStyles((INode) node, rowColHelper2);
          else if ("tfoot".Equals(node.Name()))
            this.ApplyColStyles((INode) node, rowColHelper3);
          else
            this.ApplyColStyles((INode) node, rowColHelper1);
        }
      }
    }

    public virtual ColWrapper GetColWrapper(int index)
    {
      return index > this.maxIndex ? (ColWrapper) null : this.colgroups[this.indexToColgroupMapping[index]].GetColumnByIndex(index - this.shiftCol[this.indexToColgroupMapping[index]]);
    }

    private void ApplyColStyles(INode node, RowColHelper rowColHelper)
    {
      foreach (INode childNode in (IEnumerable<INode>) node.ChildNodes())
      {
        if (childNode is IElementNode)
        {
          IElementNode node1 = (IElementNode) childNode;
          if ("tr".Equals(node1.Name()))
          {
            this.ApplyColStyles((INode) node1, rowColHelper);
            rowColHelper.NewRow();
          }
          else if ("th".Equals(node1.Name()) || "td".Equals(node1.Name()))
          {
            int? nullable1 = CssDimensionParsingUtils.ParseInteger(node1.GetAttribute("colspan"));
            int? nullable2 = CssDimensionParsingUtils.ParseInteger(node1.GetAttribute("rowspan"));
            nullable1 = nullable1 ?? new int?(1);
            nullable2 = nullable2 ?? new int?(1);
            int nextEmptyCol = rowColHelper.MoveToNextEmptyCol();
            if (this.GetColWrapper(nextEmptyCol) != null)
            {
              ColWrapper colWrapper = this.GetColWrapper(nextEmptyCol);
              if (colWrapper.GetCellCssProps() != null)
                node1.AddAdditionalHtmlStyles(colWrapper.GetCellCssProps());
              string attribute = node1.GetAttribute("lang");
              string str = (string) null;
              if (node is IElementNode)
                str = ((IElementNode) node).GetAttribute("lang");
              if (str == null && colWrapper.GetLang() != null && attribute == null)
                node1.GetAttributes().SetAttribute("lang", colWrapper.GetLang());
            }
            rowColHelper.UpdateCurrentPosition(nullable1.Value, nullable2.Value);
          }
          else
            this.ApplyColStyles(childNode, rowColHelper);
        }
      }
    }

    private void FinalizeColgroups()
    {
      int length = 0;
      this.shiftCol = new int[this.colgroups.Count];
      for (int index = 0; index < this.colgroups.Count; ++index)
      {
        this.shiftCol[index] = length;
        length += this.colgroups[index].GetSpan();
      }
      this.maxIndex = length - 1;
      this.indexToColgroupMapping = new int[length];
      for (int index1 = 0; index1 < this.colgroups.Count; ++index1)
      {
        for (int index2 = 0; index2 < this.colgroups[index1].GetSpan(); ++index2)
          this.indexToColgroupMapping[index2 + this.shiftCol[index1]] = index1;
      }
      this.colgroups.TrimExcess();
    }
  }
}
