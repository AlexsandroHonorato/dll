﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Attach.Util.AccessiblePropHelper
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Pdf.Tagutils;
using iText.Layout.Tagging;
using iText.StyledXmlParser.Node;

#nullable disable
namespace iText.Html2pdf.Attach.Util
{
  public class AccessiblePropHelper
  {
    public static void TrySetLangAttribute(
      IAccessibleElement accessibleElement,
      IElementNode element)
    {
      string attribute = element.GetAttribute("lang");
      AccessiblePropHelper.TrySetLangAttribute(accessibleElement, attribute);
    }

    public static void TrySetLangAttribute(IAccessibleElement accessibleElement, string lang)
    {
      if (lang == null)
        return;
      AccessibilityProperties accessibilityProperties = accessibleElement.GetAccessibilityProperties();
      if (accessibilityProperties.GetLanguage() != null)
        return;
      accessibilityProperties.SetLanguage(lang);
    }
  }
}
