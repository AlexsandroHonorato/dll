﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Actions.Events.PdfHtmlProductEvent
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Actions;
using iText.Commons.Actions.Confirmations;
using iText.Commons.Actions.Contexts;
using iText.Commons.Actions.Sequence;
using iText.Html2pdf.Actions.Data;

#nullable disable
namespace iText.Html2pdf.Actions.Events
{
  public sealed class PdfHtmlProductEvent : AbstractProductProcessITextEvent
  {
    public const string CONVERT_HTML = "convert-html";
    private readonly string eventType;

    private PdfHtmlProductEvent(SequenceId sequenceId, IMetaInfo metaInfo, string eventType)
      : base(sequenceId, PdfHtmlProductData.GetInstance(), metaInfo, (EventConfirmationType) 1)
    {
      this.eventType = eventType;
    }

    public static PdfHtmlProductEvent CreateConvertHtmlEvent(
      SequenceId sequenceId,
      IMetaInfo metaInfo)
    {
      return new PdfHtmlProductEvent(sequenceId, metaInfo, "convert-html");
    }

    public virtual string GetEventType() => this.eventType;
  }
}
