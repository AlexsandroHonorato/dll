﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Actions.Data.PdfHtmlProductData
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Actions.Data;

#nullable disable
namespace iText.Html2pdf.Actions.Data
{
  public sealed class PdfHtmlProductData
  {
    private const string PDF_HTML_PUBLIC_PRODUCT_NAME = "pdfHTML";
    private const string PDF_HTML_VERSION = "5.0.3";
    private const int PDF_HTML_COPYRIGHT_SINCE = 2000;
    private const int PDF_HTML_COPYRIGHT_TO = 2024;
    private static readonly ProductData PDF_HTML_PRODUCT_DATA = new ProductData("pdfHTML", "pdfHtml", "5.0.3", 2000, 2024);

    private PdfHtmlProductData()
    {
    }

    public static ProductData GetInstance() => PdfHtmlProductData.PDF_HTML_PRODUCT_DATA;
  }
}
