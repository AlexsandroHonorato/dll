﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Util.SvgProcessingUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Xobject;
using iText.Layout.Element;
using iText.StyledXmlParser.Resolver.Resource;
using iText.Svg.Converter;
using iText.Svg.Element;
using iText.Svg.Processors;
using iText.Svg.Xobject;

#nullable disable
namespace iText.Html2pdf.Util
{
  public class SvgProcessingUtil
  {
    private ResourceResolver resourceResolver;

    public SvgProcessingUtil(ResourceResolver resourceResolver)
    {
      this.resourceResolver = resourceResolver;
    }

    public virtual Image CreateImageFromProcessingResult(
      ISvgProcessorResult result,
      PdfDocument pdfDocument)
    {
      return (Image) new SvgImage((SvgImageXObject) this.CreateXObjectFromProcessingResult(result, pdfDocument));
    }

    public virtual Image CreateSvgImageFromProcessingResult(ISvgProcessorResult result)
    {
      return this.CreateImageFromProcessingResult(result, (PdfDocument) null);
    }

    public virtual PdfFormXObject CreateXObjectFromProcessingResult(
      ISvgProcessorResult result,
      PdfDocument pdfDocument)
    {
      float[] widthAndHeight = SvgConverter.ExtractWidthAndHeight(result.GetRootRenderer());
      SvgImageXObject processingResult = new SvgImageXObject(new Rectangle(0.0f, 0.0f, widthAndHeight[0], widthAndHeight[1]), result, this.resourceResolver);
      if (pdfDocument != null)
        processingResult.Generate(pdfDocument);
      return (PdfFormXObject) processingResult;
    }
  }
}
