﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.Util.TagProcessorMapping`1
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System.Collections.Generic;

#nullable disable
namespace iText.Html2pdf.Util
{
  public class TagProcessorMapping<T>
  {
    private static string DEFAULT_DISPLAY_KEY = "defaultKey";
    private IDictionary<string, IDictionary<string, T>> mapping;

    public TagProcessorMapping()
    {
      this.mapping = (IDictionary<string, IDictionary<string, T>>) new Dictionary<string, IDictionary<string, T>>();
    }

    public virtual void PutMapping(string tag, T mapping)
    {
      this.EnsureMappingExists(tag).Put<string, T>(TagProcessorMapping<T>.DEFAULT_DISPLAY_KEY, mapping);
    }

    public virtual void PutMapping(string tag, string display, T mapping)
    {
      this.EnsureMappingExists(tag).Put<string, T>(display, mapping);
    }

    public virtual object GetMapping(string tag)
    {
      return this.GetMapping(tag, TagProcessorMapping<T>.DEFAULT_DISPLAY_KEY);
    }

    public virtual object GetMapping(string tag, string display)
    {
      IDictionary<string, T> col = this.mapping.Get<string, IDictionary<string, T>>(tag);
      return col == null ? (object) null : (object) col.Get<string, T>(display);
    }

    private IDictionary<string, T> EnsureMappingExists(string tag)
    {
      if (this.mapping.ContainsKey(tag))
        return this.mapping.Get<string, IDictionary<string, T>>(tag);
      IDictionary<string, T> dictionary = (IDictionary<string, T>) new Dictionary<string, T>();
      this.mapping.Put<string, IDictionary<string, T>>(tag, dictionary);
      return dictionary;
    }
  }
}
