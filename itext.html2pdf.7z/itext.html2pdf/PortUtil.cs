﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.PortUtil
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using System.IO;

#nullable disable
namespace iText.Html2pdf
{
  public class PortUtil
  {
    private PortUtil()
    {
    }

    public static TextReader WrapInBufferedReader(TextReader inputStreamReader)
    {
      return inputStreamReader;
    }
  }
}
