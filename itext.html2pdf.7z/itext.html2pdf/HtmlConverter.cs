﻿// Decompiled with JetBrains decompiler
// Type: iText.Html2pdf.HtmlConverter
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Actions.Contexts;
using iText.Commons.Utils;
using iText.Html2pdf.Attach;
using iText.Html2pdf.Exceptions;
using iText.Html2pdf.Resolver.Font;
using iText.Kernel.Pdf;
using iText.Layout;
using iText.Layout.Element;
using iText.Layout.Font;
using iText.Layout.Renderer;
using iText.Pdfa;
using iText.StyledXmlParser;
using iText.StyledXmlParser.Node.Impl.Jsoup;
using System.Collections.Generic;
using System.IO;

#nullable disable
namespace iText.Html2pdf
{
  public class HtmlConverter
  {
    private static readonly IList<PdfAConformanceLevel> pdf2ConformanceLevels = (IList<PdfAConformanceLevel>) new List<PdfAConformanceLevel>((IEnumerable<PdfAConformanceLevel>) JavaUtil.ArraysAsList<PdfAConformanceLevel>(new PdfAConformanceLevel[3]
    {
      PdfAConformanceLevel.PDF_A_4,
      PdfAConformanceLevel.PDF_A_4E,
      PdfAConformanceLevel.PDF_A_4F
    }));

    private HtmlConverter()
    {
    }

    public static void ConvertToPdf(string html, Stream pdfStream)
    {
      HtmlConverter.ConvertToPdf(html, pdfStream, (ConverterProperties) null);
    }

    public static void ConvertToPdf(
      string html,
      Stream pdfStream,
      ConverterProperties converterProperties)
    {
      if (converterProperties != null && HtmlConverter.pdf2ConformanceLevels.Contains(converterProperties.GetConformanceLevel()))
        HtmlConverter.ConvertToPdf(html, new PdfWriter(pdfStream, new WriterProperties().SetPdfVersion(PdfVersion.PDF_2_0)), converterProperties);
      else
        HtmlConverter.ConvertToPdf(html, new PdfWriter(pdfStream), converterProperties);
    }

    public static void ConvertToPdf(string html, PdfWriter pdfWriter)
    {
      HtmlConverter.ConvertToPdf(html, pdfWriter, (ConverterProperties) null);
    }

    public static void ConvertToPdf(
      string html,
      PdfWriter pdfWriter,
      ConverterProperties converterProperties)
    {
      if (converterProperties == null || converterProperties.GetConformanceLevel() == null)
      {
        HtmlConverter.ConvertToPdf(html, new PdfDocument(pdfWriter, new DocumentProperties().SetEventCountingMetaInfo(HtmlConverter.ResolveMetaInfo(converterProperties))), converterProperties);
      }
      else
      {
        PdfDocument pdfDocument = (PdfDocument) new PdfADocument(pdfWriter, converterProperties.GetConformanceLevel(), converterProperties.GetDocumentOutputIntent(), new DocumentProperties().SetEventCountingMetaInfo(HtmlConverter.ResolveMetaInfo(converterProperties)));
        converterProperties = HtmlConverter.SetDefaultFontProviderForPdfA(pdfDocument, converterProperties);
        if ("A".Equals(converterProperties.GetConformanceLevel().GetConformance()))
          pdfDocument.SetTagged();
        HtmlConverter.ConvertToPdf(html, pdfDocument, converterProperties);
      }
    }

    public static void ConvertToPdf(
      string html,
      PdfDocument pdfDocument,
      ConverterProperties converterProperties)
    {
      Document document = HtmlConverter.ConvertToDocument(html, pdfDocument, converterProperties);
      document.SetProperty(135, (object) new MetaInfoContainer(HtmlConverter.ResolveMetaInfo(converterProperties)));
      document.Close();
    }

    public static void ConvertToPdf(FileInfo htmlFile, FileInfo pdfFile)
    {
      HtmlConverter.ConvertToPdf(htmlFile, pdfFile, (ConverterProperties) null);
    }

    public static void ConvertToPdf(
      FileInfo htmlFile,
      FileInfo pdfFile,
      ConverterProperties converterProperties)
    {
      if (converterProperties == null)
        converterProperties = new ConverterProperties().SetBaseUri(FileUtil.GetParentDirectoryUri(htmlFile));
      else if (converterProperties.GetBaseUri() == null)
      {
        string parentDirectoryUri = FileUtil.GetParentDirectoryUri(htmlFile);
        converterProperties = new ConverterProperties(converterProperties).SetBaseUri(parentDirectoryUri);
      }
      using (FileStream htmlStream = new FileStream(htmlFile.FullName, FileMode.Open, FileAccess.Read))
      {
        using (FileStream pdfStream = new FileStream(pdfFile.FullName, FileMode.Create))
          HtmlConverter.ConvertToPdf((Stream) htmlStream, (Stream) pdfStream, converterProperties);
      }
    }

    public static void ConvertToPdf(Stream htmlStream, Stream pdfStream)
    {
      HtmlConverter.ConvertToPdf(htmlStream, pdfStream, (ConverterProperties) null);
    }

    public static void ConvertToPdf(
      Stream htmlStream,
      Stream pdfStream,
      ConverterProperties converterProperties)
    {
      if (converterProperties != null && HtmlConverter.pdf2ConformanceLevels.Contains(converterProperties.GetConformanceLevel()))
        HtmlConverter.ConvertToPdf(htmlStream, new PdfWriter(pdfStream, new WriterProperties().SetPdfVersion(PdfVersion.PDF_2_0)), converterProperties);
      else
        HtmlConverter.ConvertToPdf(htmlStream, new PdfWriter(pdfStream), converterProperties);
    }

    public static void ConvertToPdf(Stream htmlStream, PdfDocument pdfDocument)
    {
      HtmlConverter.ConvertToPdf(htmlStream, pdfDocument, (ConverterProperties) null);
    }

    public static void ConvertToPdf(Stream htmlStream, PdfWriter pdfWriter)
    {
      HtmlConverter.ConvertToPdf(htmlStream, new PdfDocument(pdfWriter, new DocumentProperties().SetEventCountingMetaInfo(HtmlConverter.CreatePdf2HtmlMetaInfo())));
    }

    public static void ConvertToPdf(
      Stream htmlStream,
      PdfWriter pdfWriter,
      ConverterProperties converterProperties)
    {
      if (converterProperties == null || converterProperties.GetConformanceLevel() == null)
      {
        HtmlConverter.ConvertToPdf(htmlStream, new PdfDocument(pdfWriter, new DocumentProperties().SetEventCountingMetaInfo(HtmlConverter.ResolveMetaInfo(converterProperties))), converterProperties);
      }
      else
      {
        PdfDocument pdfDocument = (PdfDocument) new PdfADocument(pdfWriter, converterProperties.GetConformanceLevel(), converterProperties.GetDocumentOutputIntent(), new DocumentProperties().SetEventCountingMetaInfo(HtmlConverter.ResolveMetaInfo(converterProperties)));
        converterProperties = HtmlConverter.SetDefaultFontProviderForPdfA(pdfDocument, converterProperties);
        if ("A".Equals(converterProperties.GetConformanceLevel().GetConformance()))
          pdfDocument.SetTagged();
        HtmlConverter.ConvertToPdf(htmlStream, pdfDocument, converterProperties);
      }
    }

    public static void ConvertToPdf(
      Stream htmlStream,
      PdfDocument pdfDocument,
      ConverterProperties converterProperties)
    {
      converterProperties = HtmlConverter.SetDefaultFontProviderForPdfA(pdfDocument, converterProperties);
      Document document = HtmlConverter.ConvertToDocument(htmlStream, pdfDocument, converterProperties);
      document.SetProperty(135, (object) new MetaInfoContainer(HtmlConverter.ResolveMetaInfo(converterProperties)));
      document.Close();
    }

    public static Document ConvertToDocument(string html, PdfWriter pdfWriter)
    {
      return HtmlConverter.ConvertToDocument(html, pdfWriter, (ConverterProperties) null);
    }

    public static Document ConvertToDocument(Stream htmlStream, PdfWriter pdfWriter)
    {
      return HtmlConverter.ConvertToDocument(htmlStream, pdfWriter, (ConverterProperties) null);
    }

    public static Document ConvertToDocument(
      string html,
      PdfWriter pdfWriter,
      ConverterProperties converterProperties)
    {
      return HtmlConverter.ConvertToDocument(html, new PdfDocument(pdfWriter), converterProperties);
    }

    public static Document ConvertToDocument(
      Stream htmlStream,
      PdfWriter pdfWriter,
      ConverterProperties converterProperties)
    {
      return HtmlConverter.ConvertToDocument(htmlStream, new PdfDocument(pdfWriter), converterProperties);
    }

    public static Document ConvertToDocument(
      string html,
      PdfDocument pdfDocument,
      ConverterProperties converterProperties)
    {
      converterProperties = pdfDocument.GetReader() == null ? HtmlConverter.SetDefaultFontProviderForPdfA(pdfDocument, converterProperties) : throw new Html2PdfException("PdfDocument should be created in writing mode. Reading and stamping is not allowed");
      return Attacher.Attach(((IXmlParser) new JsoupHtmlParser()).Parse(html), pdfDocument, converterProperties);
    }

    public static Document ConvertToDocument(
      Stream htmlStream,
      PdfDocument pdfDocument,
      ConverterProperties converterProperties)
    {
      converterProperties = pdfDocument.GetReader() == null ? HtmlConverter.SetDefaultFontProviderForPdfA(pdfDocument, converterProperties) : throw new Html2PdfException("PdfDocument should be created in writing mode. Reading and stamping is not allowed");
      return Attacher.Attach(((IXmlParser) new JsoupHtmlParser()).Parse(htmlStream, converterProperties?.GetCharset()), pdfDocument, converterProperties);
    }

    public static IList<IElement> ConvertToElements(string html)
    {
      return HtmlConverter.ConvertToElements(html, (ConverterProperties) null);
    }

    public static IList<IElement> ConvertToElements(Stream htmlStream)
    {
      return HtmlConverter.ConvertToElements(htmlStream, (ConverterProperties) null);
    }

    public static IList<IElement> ConvertToElements(
      string html,
      ConverterProperties converterProperties)
    {
      converterProperties = HtmlConverter.SetDefaultFontProviderForPdfA((PdfDocument) null, converterProperties);
      return Attacher.Attach(((IXmlParser) new JsoupHtmlParser()).Parse(html), converterProperties);
    }

    public static IList<IElement> ConvertToElements(
      Stream htmlStream,
      ConverterProperties converterProperties)
    {
      converterProperties = HtmlConverter.SetDefaultFontProviderForPdfA((PdfDocument) null, converterProperties);
      return Attacher.Attach(((IXmlParser) new JsoupHtmlParser()).Parse(htmlStream, converterProperties?.GetCharset()), converterProperties);
    }

    internal static IMetaInfo CreatePdf2HtmlMetaInfo()
    {
      return (IMetaInfo) new HtmlConverter.HtmlMetaInfo();
    }

    private static IMetaInfo ResolveMetaInfo(ConverterProperties converterProperties)
    {
      return converterProperties != null ? converterProperties.GetEventMetaInfo() : HtmlConverter.CreatePdf2HtmlMetaInfo();
    }

    private static ConverterProperties SetDefaultFontProviderForPdfA(
      PdfDocument document,
      ConverterProperties properties)
    {
      if (document is PdfADocument)
      {
        if (properties == null)
          properties = new ConverterProperties();
        if (properties.GetFontProvider() == null)
          properties.SetFontProvider((FontProvider) new DefaultFontProvider(false, true, false));
      }
      else if (document == null && properties != null && properties.GetConformanceLevel() != null && properties.GetFontProvider() == null)
        properties.SetFontProvider((FontProvider) new DefaultFontProvider(false, true, false));
      return properties;
    }

    private class HtmlMetaInfo : IMetaInfo
    {
    }
  }
}
