﻿// Decompiled with JetBrains decompiler
// Type: Html2PdfExtensions
// Assembly: itext.html2pdf, Version=5.0.3.0, Culture=neutral, PublicKeyToken=8354ae6d2174ddca
// MVID: 496E412A-50A1-45A1-B5A3-8E1074BF7F8B
// Assembly location: C:\Users\Rev\Desktop\dll\itext.html2pdf.dll

using iText.Commons.Utils;
using iText.Html2pdf;
using iText.IO.Util;
using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;

#nullable disable
internal static class Html2PdfExtensions
{
  public static string Name(this Encoding e) => e.WebName.ToUpperInvariant();

  public static string DisplayName(this Encoding e) => e.WebName.ToUpperInvariant();

  public static bool RegionMatches(
    this string s,
    bool ignoreCase,
    int toffset,
    string other,
    int ooffset,
    int len)
  {
    return string.Compare(s, toffset, other, ooffset, len, ignoreCase ? StringComparison.OrdinalIgnoreCase : StringComparison.Ordinal) == 0;
  }

  public static bool StartsWith(this string s, string prefix, int pos)
  {
    int num1 = pos;
    int num2 = 0;
    int length = prefix.Length;
    if (pos < 0 || pos > s.Length - length)
      return false;
    while (--length >= 0)
    {
      if ((int) s[num1++] != (int) prefix[num2++])
        return false;
    }
    return true;
  }

  public static void ReadFully(this FileStream stream, byte[] bytes)
  {
    stream.Read(bytes, 0, bytes.Length);
  }

  public static string Decode(this Encoding encoding, ByteBuffer byteBuffer)
  {
    int num = 0;
    Encoding encoding1 = (Encoding) null;
    if (encoding.CodePage == Encoding.Unicode.CodePage && byteBuffer.Remaining() >= 2)
    {
      byte[] dest = new byte[2];
      byteBuffer.Peek(dest);
      if (dest[0] == (byte) 254 && dest[1] == byte.MaxValue)
      {
        encoding1 = Encoding.BigEndianUnicode;
        num = 2;
      }
      if (dest[0] == byte.MaxValue && dest[1] == (byte) 254)
        num = 2;
    }
    if (encoding.CodePage == Encoding.UTF32.CodePage && byteBuffer.Remaining() >= 4)
    {
      byte[] dest = new byte[4];
      byteBuffer.Peek(dest);
      if (dest[0] == (byte) 0 && dest[1] == (byte) 0 && dest[2] == (byte) 254 && dest[3] == byte.MaxValue)
      {
        encoding1 = EncodingUtil.GetEncoding("utf-32be");
        num = 4;
      }
      if (dest[0] == byte.MaxValue && dest[1] == (byte) 254 && dest[2] == (byte) 0 && dest[3] == (byte) 0)
        num = 4;
    }
    if (encoding1 == null)
      encoding1 = EncodingUtil.GetEncoding(encoding.CodePage, EncoderFallback.ReplacementFallback, DecoderFallback.ReplacementFallback);
    string str = encoding1.GetString(byteBuffer.buffer, byteBuffer.position + num, byteBuffer.Remaining() - num);
    byteBuffer.Position(byteBuffer.buffer.Length - 1);
    return str;
  }

  public static string ToExternalForm(this Uri u) => u.AbsoluteUri;

  public static bool CanEncode(this Encoding encoding, char c) => encoding.CanEncode(c.ToString());

  public static bool CanEncode(this Encoding encoding, string chars)
  {
    byte[] bytes = Encoding.Unicode.GetBytes(chars);
    return encoding.CanEncode(bytes);
  }

  public static bool CanEncode(this Encoding encoding, byte[] src)
  {
    try
    {
      Encoding.Convert(Encoding.Unicode, EncodingUtil.GetEncoding(encoding.CodePage, (EncoderFallback) new EncoderExceptionFallback(), (DecoderFallback) new DecoderExceptionFallback()), src);
    }
    catch (EncoderFallbackException ex)
    {
      return false;
    }
    return true;
  }

  public static Stream GetResourceAsStream(this Type type, string filename)
  {
    return ResourceUtil.GetResourceStream(type.Namespace.ToLowerInvariant() + "." + filename, type) ?? throw new IOException();
  }

  public static int CodePointAt(this string str, int index) => char.ConvertToUtf32(str, index);

  public static StringBuilder AppendCodePoint(this StringBuilder sb, int codePoint)
  {
    return sb.Append(char.ConvertFromUtf32(codePoint));
  }

  public static string JSubstring(this string str, int beginIndex, int endIndex)
  {
    return str.Substring(beginIndex, endIndex - beginIndex);
  }

  public static void JReset(this MemoryStream stream) => stream.Position = 0L;

  public static StringBuilder Delete(this StringBuilder sb, int beginIndex, int endIndex)
  {
    return sb.Remove(beginIndex, endIndex - beginIndex);
  }

  public static void Write(this Stream stream, int value) => stream.WriteByte((byte) value);

  public static int Read(this Stream stream) => stream.ReadByte();

  public static int Read(this Stream stream, byte[] buffer)
  {
    int num = stream.Read(buffer, 0, buffer.Length);
    return num != 0 ? num : -1;
  }

  public static int JRead(this Stream stream, byte[] buffer, int offset, int count)
  {
    int num = stream.Read(buffer, offset, count);
    return num != 0 ? num : -1;
  }

  public static void Write(this Stream stream, byte[] buffer)
  {
    stream.Write(buffer, 0, buffer.Length);
  }

  public static byte[] GetBytes(this string str) => Encoding.UTF8.GetBytes(str);

  public static byte[] GetBytes(this string str, Encoding encoding) => encoding.GetBytes(str);

  public static byte[] GetBytes(this string str, string encodingName)
  {
    return EncodingUtil.GetEncoding(encodingName).GetBytes(str);
  }

  public static ByteBuffer Encode(this Encoding encoding, string str)
  {
    return ByteBuffer.Wrap(encoding.GetBytes(str));
  }

  public static long Seek(this FileStream fs, long offset) => fs.Seek(offset, SeekOrigin.Begin);

  public static long Skip(this Stream s, long n)
  {
    s.Seek(n, SeekOrigin.Current);
    return n;
  }

  public static List<T> SubList<T>(this IList<T> list, int fromIndex, int toIndex)
  {
    return ((List<T>) list).GetRange(fromIndex, toIndex - fromIndex);
  }

  public static int LastIndexOf<T>(this IList<T> list, T item)
  {
    if (list is List<T>)
      return ((List<T>) list).LastIndexOf(item);
    for (int index = list.Count - 1; index >= 0; --index)
    {
      if (object.Equals((object) list[index], (object) item))
        return index;
    }
    return -1;
  }

  public static void GetChars(
    this StringBuilder sb,
    int srcBegin,
    int srcEnd,
    char[] dst,
    int dstBegin)
  {
    sb.CopyTo(srcBegin, dst, dstBegin, srcEnd - srcBegin);
  }

  public static string[] Split(this string str, string regex) => str.Split(regex.ToCharArray());

  public static void AddAll<T>(this ICollection<T> c, IEnumerable<T> collectionToAdd)
  {
    foreach (T obj in collectionToAdd)
      c.Add(obj);
  }

  public static void AddAll<T>(this Stack<T> c, IEnumerable<T> collectionToAdd)
  {
    foreach (T obj in collectionToAdd)
      c.Push(obj);
  }

  public static T[] ToArray<T>(this ICollection<T> col)
  {
    T[] toArray = new T[col.Count];
    return col.ToArray<T>(toArray);
  }

  public static T[] ToArray<T>(this ICollection<T> col, T[] toArray)
  {
    int count = col.Count;
    T[] array;
    if (count <= toArray.Length)
    {
      col.CopyTo(toArray, 0);
      if (count != toArray.Length)
        toArray[count] = default (T);
      array = toArray;
    }
    else
    {
      array = new T[count];
      col.CopyTo(array, 0);
    }
    return array;
  }

  public static bool RemoveAll<T>(this ICollection<T> set, ICollection<T> c)
  {
    bool flag = false;
    foreach (T obj in (IEnumerable<T>) c)
    {
      if (set.Remove(obj))
        flag = true;
    }
    return flag;
  }

  public static TValue JRemove<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key)
  {
    TValue obj;
    dictionary.TryGetValue(key, out obj);
    dictionary.Remove(key);
    return obj;
  }

  public static T JRemoveFirst<T>(this LinkedList<T> list)
  {
    T obj = list.First.Value;
    list.RemoveFirst();
    return obj;
  }

  public static bool Matches(this string str, string regex)
  {
    return Regex.IsMatch(str, "^" + regex + "$");
  }

  public static string ReplaceFirst(this string input, string pattern, string replacement)
  {
    return new Regex(pattern).Replace(input, replacement, 1);
  }

  public static bool EqualsIgnoreCase(this string str, string anotherString)
  {
    return string.Equals(str, anotherString, StringComparison.OrdinalIgnoreCase);
  }

  public static void AddAll<TKey, TValue>(
    this IDictionary<TKey, TValue> c,
    IDictionary<TKey, TValue> collectionToAdd)
  {
    foreach (KeyValuePair<TKey, TValue> keyValuePair in (IEnumerable<KeyValuePair<TKey, TValue>>) collectionToAdd)
      c[keyValuePair.Key] = keyValuePair.Value;
  }

  public static void AddAll<T>(this IList<T> list, int index, IList<T> c)
  {
    for (int index1 = c.Count - 1; index1 >= 0; --index1)
      list.Insert(index, c[index1]);
  }

  public static bool IsEmpty<T>(this Stack<T> c) => c.Count == 0;

  public static bool IsEmpty<T>(this ICollection<T> c) => c.Count == 0;

  public static bool IsEmpty<T>(this IList<T> l) => l.Count == 0;

  public static void Add<T>(this IList<T> list, int index, T elem) => list.Insert(index, elem);

  public static bool Add<T>(this LinkedList<T> list, T elem)
  {
    list.AddLast(elem);
    return true;
  }

  public static T JRemove<T>(this LinkedList<T> list)
  {
    T obj = list.First.Value;
    list.RemoveFirst();
    return obj;
  }

  public static T JRemoveAt<T>(this IList<T> list, int index)
  {
    T obj = list[index];
    list.RemoveAt(index);
    return obj;
  }

  public static TValue Get<TKey, TValue>(this IDictionary<TKey, TValue> col, TKey key)
  {
    TValue obj = default (TValue);
    if ((object) key != null)
      col.TryGetValue(key, out obj);
    return obj;
  }

  public static TValue Put<TKey, TValue>(
    this IDictionary<TKey, TValue> col,
    TKey key,
    TValue value)
  {
    TValue obj = col.Get<TKey, TValue>(key);
    col[key] = value;
    return obj;
  }

  public static bool Contains<TKey, TValue>(this IDictionary<TKey, TValue> dictionary, TKey key)
  {
    return dictionary.ContainsKey(key);
  }

  public static T JGetFirst<T>(this LinkedList<T> list) => list.First.Value;

  public static T JGetLast<T>(this LinkedList<T> list) => list.Last.Value;

  public static void EnsureCapacity<T>(this List<T> list, int capacity)
  {
    if (capacity <= list.Count)
      return;
    list.Capacity = capacity;
  }

  public static StringBuilder JAppend(this StringBuilder sb, string str, int begin, int end)
  {
    return sb.Append(str, begin, end - begin);
  }

  public static StringBuilder Reverse(this StringBuilder sb)
  {
    char ch1 = '\uD800';
    char ch2 = '\uDFFF';
    bool flag = false;
    int num = sb.Length - 1;
    for (int index = num - 1 >> 1; index >= 0; --index)
    {
      char ch3 = sb[index];
      char ch4 = sb[num - index];
      if (!flag)
        flag = (int) ch3 >= (int) ch1 && (int) ch3 <= (int) ch2 || (int) ch4 >= (int) ch1 && (int) ch4 <= (int) ch2;
      sb[index] = ch4;
      sb[num - index] = ch3;
    }
    if (flag)
    {
      for (int index = 0; index < sb.Length - 1; ++index)
      {
        char c1 = sb[index];
        if (char.IsLowSurrogate(c1))
        {
          char c2 = sb[index + 1];
          if (char.IsHighSurrogate(c2))
          {
            sb[index++] = c2;
            sb[index] = c1;
          }
        }
      }
    }
    return sb;
  }

  public static Assembly GetAssembly(this Type type) => type.GetTypeInfo().Assembly;

  public static MethodInfo GetMethod(this Type type, string methodName, Type[] parameterTypes)
  {
    return type.GetTypeInfo().GetMethod(methodName, parameterTypes);
  }

  public static MethodInfo GetMethod(this Type type, string methodName)
  {
    return type.GetTypeInfo().GetMethod(methodName);
  }

  public static ConstructorInfo GetConstructor(this Type type, Type[] parameterTypes)
  {
    return type.GetTypeInfo().GetConstructor(parameterTypes);
  }

  public static bool IsInstanceOfType(this Type type, object objToCheck)
  {
    return type.GetTypeInfo().IsInstanceOfType(objToCheck);
  }

  public static FieldInfo[] GetFields(this Type type, BindingFlags flags)
  {
    return type.GetTypeInfo().GetFields(flags);
  }

  public static byte[] GetBuffer(this MemoryStream memoryStream)
  {
    ArraySegment<byte> buffer;
    memoryStream.TryGetBuffer(out buffer);
    return buffer.Array;
  }
}
