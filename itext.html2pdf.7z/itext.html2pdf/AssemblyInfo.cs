﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: Extension]
[assembly: AssemblyTitle("iText.Html2Pdf")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Apryse Group NV")]
[assembly: AssemblyProduct("iText")]
[assembly: AssemblyCopyright("Copyright (c) 1998-2024 Apryse Group NV")]
[assembly: AssemblyTrademark("")]
[assembly: InternalsVisibleTo("itext.html2pdf.tests,PublicKey=00240000048000009400000006020000002400005253413100040000010001008b21ed5b3fc1c11996390981fe22bbe71a39a9e11d3c2cefddd6ee92920fa871f9666ae0fa941af0280d0653df048ae2d93f8c5e2d820dba3c8df9ed468c8be40a6fffeb32aa481a254f0fb9f37aa7c3ec1c0acd2c009746bbdafcb75bcdbcecb7caf1f0f4b6e7d013906ba60b66eb1c8298e4efb052caf6cece4bf1816902cc")]
[assembly: InternalsVisibleTo("itext.html2pdf.tests.private,PublicKey=00240000048000009400000006020000002400005253413100040000010001008b21ed5b3fc1c11996390981fe22bbe71a39a9e11d3c2cefddd6ee92920fa871f9666ae0fa941af0280d0653df048ae2d93f8c5e2d820dba3c8df9ed468c8be40a6fffeb32aa481a254f0fb9f37aa7c3ec1c0acd2c009746bbdafcb75bcdbcecb7caf1f0f4b6e7d013906ba60b66eb1c8298e4efb052caf6cece4bf1816902cc")]
[assembly: ComVisible(false)]
[assembly: Guid("ff6ba09d-3655-466a-8c17-a7bfd3479ca1")]
[assembly: AssemblyFileVersion("5.0.3.0")]
[assembly: AssemblyInformationalVersion("5.0.3")]
[assembly: AssemblyVersion("5.0.3.0")]
